#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# NewConfiguration configuration
CND_ARTIFACT_DIR_NewConfiguration=dist/NewConfiguration/production
CND_ARTIFACT_NAME_NewConfiguration=HandPICd242.X.production.hex
CND_ARTIFACT_PATH_NewConfiguration=dist/NewConfiguration/production/HandPICd242.X.production.hex
