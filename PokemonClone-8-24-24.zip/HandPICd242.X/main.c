
/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__PIC24E__)
    	#include <p24Exxxx.h>
    #elif defined (__PIC24F__)||defined (__PIC24FK__)
	#include <p24Fxxxx.h>
    #elif defined(__PIC24H__)
	#include <p24Hxxxx.h>
    #endif
#endif

#include <stdint.h>        /* Includes uint16_t definition                    */
#include <stdbool.h>       /* Includes true/false definition                  */

/* Microcontroller MIPs (FCY) */
#define SYS_FREQ        10000000L
#define FCY             SYS_FREQ/2


/*
// PIC24EP512GP204 Configuration Bit Settings

// 'C' source line config statements

// FICD
#pragma config ICS = PGD1               // ICD Communication Channel Select bits (Communicate on PGEC1 and PGED1)
#pragma config JTAGEN = OFF             // JTAG Enable bit (JTAG is disabled)

// FPOR
#pragma config ALTI2C1 = OFF            // Alternate I2C1 pins (I2C1 mapped to SDA1/SCL1 pins)
#pragma config ALTI2C2 = OFF            // Alternate I2C2 pins (I2C2 mapped to SDA2/SCL2 pins)
#pragma config WDTWIN = WIN25           // Watchdog Window Select bits (WDT Window is 25% of WDT period)

// FWDT
#pragma config WDTPOST = PS32768        // Watchdog Timer Postscaler bits (1:32,768)
#pragma config WDTPRE = PR128           // Watchdog Timer Prescaler bit (1:128)
#pragma config PLLKEN = ON              // PLL Lock Enable bit (Clock switch to PLL source will wait until the PLL lock signal is valid.)
#pragma config WINDIS = OFF             // Watchdog Timer Window Enable bit (Watchdog Timer in Non-Window mode)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable bit (Watchdog timer enabled/disabled by user software)

// FOSC
#pragma config POSCMD = EC              // Primary Oscillator Mode Select bits (EC (External Clock) Mode)
#pragma config OSCIOFNC = ON            // OSC2 Pin Function bit (OSC2 is general purpose digital I/O pin)
#pragma config IOL1WAY = OFF            // Peripheral pin select configuration (Allow multiple reconfigurations)
#pragma config FCKSM = CSECMD           // Clock Switching Mode bits (Clock switching is enabled,Fail-safe Clock Monitor is disabled)

// FOSCSEL
#pragma config FNOSC = FRC              // Oscillator Source Selection (Internal Fast RC (FRC))
#pragma config IESO = OFF               // Two-speed Oscillator Start-up Enable bit (Start up with user-selected oscillator source)

// FGS
#pragma config GWRP = OFF               // General Segment Write-Protect bit (General Segment may be written)
#pragma config GCP = OFF                // General Segment Code-Protect bit (General Segment Code protect is Disabled)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
*/



// PIC24EP512GP204 Configuration Bit Settings

// 'C' source line config statements

// FICD
#pragma config ICS = PGD1               // ICD Communication Channel Select bits (Communicate on PGEC1 and PGED1)
#pragma config JTAGEN = OFF             // JTAG Enable bit (JTAG is disabled)

// FPOR
#pragma config ALTI2C1 = OFF            // Alternate I2C1 pins (I2C1 mapped to SDA1/SCL1 pins)
#pragma config ALTI2C2 = OFF            // Alternate I2C2 pins (I2C2 mapped to SDA2/SCL2 pins)
#pragma config WDTWIN = WIN25           // Watchdog Window Select bits (WDT Window is 25% of WDT period)

// FWDT
#pragma config WDTPOST = PS32768        // Watchdog Timer Postscaler bits (1:32,768)
#pragma config WDTPRE = PR128           // Watchdog Timer Prescaler bit (1:128)
#pragma config PLLKEN = ON              // PLL Lock Enable bit (Clock switch to PLL source will wait until the PLL lock signal is valid.)
#pragma config WINDIS = OFF             // Watchdog Timer Window Enable bit (Watchdog Timer in Non-Window mode)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable bit (Watchdog timer enabled/disabled by user software)

// FOSC
#pragma config POSCMD = XT              // Primary Oscillator Mode Select bits (XT Crystal Oscillator Mode)
#pragma config OSCIOFNC = OFF           // OSC2 Pin Function bit (OSC2 is clock output)
#pragma config IOL1WAY = OFF            // Peripheral pin select configuration (Allow multiple reconfigurations)
#pragma config FCKSM = CSECMD           // Clock Switching Mode bits (Clock switching is enabled,Fail-safe Clock Monitor is disabled)

// FOSCSEL
#pragma config FNOSC = PRIPLL           // Oscillator Source Selection (Primary Oscillator with PLL module (XT + PLL, HS + PLL, EC + PLL))
#pragma config IESO = ON                // Two-speed Oscillator Start-up Enable bit (Start up device with FRC, then switch to user-selected oscillator source)

// FGS
#pragma config GWRP = OFF               // General Segment Write-Protect bit (General Segment may be written)
#pragma config GCP = OFF                // General Segment Code-Protect bit (General Segment Code protect is Disabled)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>



/******************************************************************************/
/* Trap Function Prototypes                                                   */
/******************************************************************************/

/* <Other function prototypes for debugging trap code may be inserted here>   */

/* Use if INTCON2 ALTIVT=1 */
void __attribute__((interrupt,no_auto_psv)) _OscillatorFail(void);
void __attribute__((interrupt,no_auto_psv)) _AddressError(void);
void __attribute__((interrupt,no_auto_psv)) _StackError(void);
void __attribute__((interrupt,no_auto_psv)) _MathError(void);

#if defined(__PIC24F__)||defined(__PIC24H__)

/* Use if INTCON2 ALTIVT=0 */
void __attribute__((interrupt,no_auto_psv)) _AltOscillatorFail(void);
void __attribute__((interrupt,no_auto_psv)) _AltAddressError(void);
void __attribute__((interrupt,no_auto_psv)) _AltStackError(void);
void __attribute__((interrupt,no_auto_psv)) _AltMathError(void);

#endif

/* Default interrupt handler */
void __attribute__((interrupt,no_auto_psv)) _DefaultInterrupt(void);

#if defined(__PIC24E__)

/* These are additional traps in the 24E family.  Refer to the PIC24E
migration guide.  There are no Alternate Vectors in the 24E family. */
void __attribute__((interrupt,no_auto_psv)) _HardTrapError(void);
void __attribute__((interrupt,no_auto_psv)) _DMACError(void);
void __attribute__((interrupt,no_auto_psv)) _SoftTrapError(void);

#endif

/******************************************************************************/
/* Trap Handling                                                              */
/*                                                                            */
/* These trap routines simply ensure that the device continuously loops       */
/* within each routine.  Users who actually experience one of these traps     */
/* can add code to handle the error.  Some basic examples for trap code,      */
/* including assembly routines that process trap sources, are available at    */
/* www.microchip.com/codeexamples                                             */
/******************************************************************************/

/* Primary (non-alternate) address error trap function declarations */
void __attribute__((interrupt,no_auto_psv)) _OscillatorFail(void)
{
        INTCON1bits.OSCFAIL = 0;        /* Clear the trap flag */
        while(1);
}

void __attribute__((interrupt,no_auto_psv)) _AddressError(void)
{
        INTCON1bits.ADDRERR = 0;        /* Clear the trap flag */
        while (1);
}
void __attribute__((interrupt,no_auto_psv)) _StackError(void)
{
        INTCON1bits.STKERR = 0;         /* Clear the trap flag */
        while (1);
}

void __attribute__((interrupt,no_auto_psv)) _MathError(void)
{
        INTCON1bits.MATHERR = 0;        /* Clear the trap flag */
        while (1);
}

#if defined(__PIC24F__)||defined(__PIC24H__)

/* Alternate address error trap function declarations */
void __attribute__((interrupt,no_auto_psv)) _AltOscillatorFail(void)
{
        INTCON1bits.OSCFAIL = 0;        /* Clear the trap flag */
        while (1);
}

void __attribute__((interrupt,no_auto_psv)) _AltAddressError(void)
{
        INTCON1bits.ADDRERR = 0;        /* Clear the trap flag */
        while (1);
}

void __attribute__((interrupt,no_auto_psv)) _AltStackError(void)
{
        INTCON1bits.STKERR = 0;         /* Clear the trap flag */
        while (1);
}

void __attribute__((interrupt,no_auto_psv)) _AltMathError(void)
{
        INTCON1bits.MATHERR = 0;        /* Clear the trap flag */
        while (1);
}

#endif

/******************************************************************************/
/* Default Interrupt Handler                                                  */
/*                                                                            */
/* This executes when an interrupt occurs for an interrupt source with an     */
/* improperly defined or undefined interrupt handling routine.                */
/******************************************************************************/
void __attribute__((interrupt,no_auto_psv)) _DefaultInterrupt(void)
{
        while(1);
}

#if defined(__PIC24E__)

/* These traps are new to the PIC24E family.  Refer to the device Interrupt
chapter of the FRM to understand trap priority. */
void __attribute__((interrupt,no_auto_psv)) _HardTrapError(void)
{
    while(1);
}
void __attribute__((interrupt,no_auto_psv)) _DMACError(void)
{
    while(1);
}
void __attribute__((interrupt,no_auto_psv)) _SoftTrapError(void)
{
    while(1);
}

#endif

// basic absolute value function without needing the math library
int abs(int a)
{
  if (a >= 0) return a;
  else return -a;
};

/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/


// only 80 used, but last 2 needed for other reasons
unsigned int line[96] __at(0x1000) = {
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000,
  0x0000, 0x0000, 0x0000, 0x0000
};


// 40 * 160 * 2-byte word = 12800 bytes
// buffer to draw on top of half the screen at once
unsigned int buffer[40*160] __at(0x2000);

// 80 * 160 * 2-byte word = 25600 bytes
// 80 words * 4 pixels per word = 320 pixels horizontal
// 160 pixels vertically
// result: 320x160 with 16 colors
// split down the middle for multiplayer
unsigned int screen[80*160] __at(0x5200);


// interrupt latency is 10 cycles
// for some reason, having auto_psv instead of no_auto_psv makes this work?!
void __attribute__((__interrupt__, auto_psv, address(0x002000))) _T1Interrupt(void)
{
	// C always includes:
	// lnk #0
  
	drawScanline();
	
	// C always includes:
	// ulnk
	// retfie
};




const __prog__ unsigned int __attribute__((space(prog))) character_bitmap[1536] = 
//const unsigned int character_bitmap[1536] =
{
	0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000, // 32
	0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x00FF,0x0000,0x0FFF,0xF000,0x0FFF,0xF000,0x0FFF,0xF000,
	0x00FF,0x0000,0x0000,0x0000,0x00FF,0x0000,0x0000,0x0000,
	0x00F0,0x0F00,0x0F00,0xF000,0x0FF0,0xFF00,0x0FF0,0xFF00,
	0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x0FF0,0xFF00,0xFFFF,0xFFF0,0x0FF0,0xFF00,0x0FF0,0xFF00,
	0x0FF0,0xFF00,0xFFFF,0xFFF0,0x0FF0,0xFF00,0x0000,0x0000,
	0x000F,0x0000,0x0FFF,0xFFF0,0xFF0F,0x0000,0x0FFF,0xFF00,
	0x000F,0x0FF0,0xFFFF,0xFF00,0x000F,0x0000,0x0000,0x0000,
	0x0F00,0x00F0,0xF0F0,0x0FF0,0x0F00,0xFF00,0x000F,0xF000,
	0x00FF,0x0F00,0x0FF0,0xF0F0,0xFF00,0x0F00,0x0000,0x0000,
	0x0FFF,0x0000,0xFF0F,0xF000,0x0FFF,0x0000,0xFF0F,0xF0F0,
	0xFF00,0xFFF0,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0x00FF,0x0000,0x00FF,0x0000,0x000F,0x0000,0x00F0,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x000F,0xFF00,0x00FF,0x0000,0x0FF0,0x0000,0x0FF0,0x0000,
	0x0FF0,0x0000,0x00FF,0x0000,0x000F,0xFF00,0x0000,0x0000,
	0x0FFF,0x0000,0x000F,0xF000,0x0000,0xFF00,0x0000,0xFF00,
	0x0000,0xFF00,0x000F,0xF000,0x0FFF,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0FF0,0xFF00,0x00FF,0xF000,
	0x0FF0,0xFF00,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x000F,0x0000,0x000F,0x0000,
	0x0FFF,0xFF00,0x000F,0x0000,0x000F,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x00FF,0x0000,
	0x00FF,0x0000,0x000F,0x0000,0x00F0,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x0FFF,0xFF00,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x00FF,0x0000,0x00FF,0x0000,0x0000,0x0000,
	0x0000,0x0F00,0x0000,0xFF00,0x000F,0xF000,0x00FF,0x0000,
	0x0FF0,0x0000,0xFF00,0x0000,0xF000,0x0000,0x0000,0x0000,
	0x0FFF,0xFF00,0xFF00,0x0FF0,0xFF00,0xFFF0,0xFF0F,0x0FF0,
	0xFFF0,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0xFFFF,0xF000,0x00FF,0xF000,0x00FF,0xF000,0x00FF,0xF000,
	0x00FF,0xF000,0x00FF,0xF000,0xFFFF,0xFFF0,0x0000,0x0000,
	0x0FFF,0xFF00,0xFF00,0x0FF0,0x0000,0xFF00,0x00FF,0xF000,
	0x0FF0,0x0000,0xFF00,0x0000,0xFFFF,0xFFF0,0x0000,0x0000,
	0x0FFF,0xFF00,0xFF00,0x0FF0,0x0000,0x0FF0,0x00FF,0xFF00,
	0x0000,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0x000F,0xFFF0,0x00FF,0x0FF0,0x0FF0,0x0FF0,0xFF00,0x0FF0,
	0xFFFF,0xFFF0,0x0000,0x0FF0,0x0000,0x0FF0,0x0000,0x0000,
	0xFFFF,0xFFF0,0xFF00,0x0000,0xFFFF,0xFF00,0x0000,0x0FF0,
	0x0000,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0x0FFF,0xFF00,0xFF00,0x0FF0,0xFF00,0x0000,0xFFFF,0xFF00,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0xFFFF,0xFFF0,0xFF00,0x0FF0,0x0000,0xFF00,0x000F,0xF000,
	0x00FF,0x0000,0x0FF0,0x0000,0xFF00,0x0000,0x0000,0x0000,
	0x0FFF,0xFF00,0xFF00,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0x0FFF,0xFF00,0xFF00,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFFF0,
	0x0000,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0x0000,0x0000,0x00FF,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x00FF,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x00FF,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x00FF,0x0000,0x00FF,0x0000,0x0FF0,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x000F,0xFF00,0x00FF,0xF000,
	0x0FFF,0x0000,0x00FF,0xF000,0x000F,0xFF00,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0FFF,0xFF00,
	0x0000,0x0000,0x0FFF,0xFF00,0x0000,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0FFF,0x0000,0x00FF,0xF000,
	0x000F,0xFF00,0x00FF,0xF000,0x0FFF,0x0000,0x0000,0x0000,
	0x0FFF,0xFF00,0xFF00,0x0FF0,0x0000,0x0FF0,0x00FF,0xFF00,
	0x00FF,0x0000,0x0000,0x0000,0x00FF,0x0000,0x0000,0x0000,
	0x0FFF,0xFF00,0xFF00,0x0FF0,0xFF0F,0x0FF0,0xFF0F,0x0FF0,
	0xFF0F,0xFF00,0xFF00,0x0000,0x0FFF,0xFF00,0x0000,0x0000,
	0x00FF,0xF000,0x0FF0,0xFF00,0xFF00,0x0FF0,0xFF00,0x0FF0,
	0xFFFF,0xFFF0,0xFF00,0x0FF0,0xFF00,0x0FF0,0x0000,0x0000,
	0xFFFF,0xFF00,0xFF00,0x0FF0,0xFF00,0x0FF0,0xFFFF,0xFF00,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0xFFFF,0xFF00,0x0000,0x0000,
	0x0FFF,0xFF00,0xFF00,0x0FF0,0xFF00,0x0000,0xFF00,0x0000,
	0xFF00,0x0000,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0xFFFF,0xF000,0xFF00,0xFF00,0xFF00,0x0FF0,0xFF00,0x0FF0,
	0xFF00,0x0FF0,0xFF00,0xFF00,0xFFFF,0xF000,0x0000,0x0000,
	0xFFFF,0xFFF0,0xFF00,0x0000,0xFF00,0x0000,0xFFFF,0xF000,
	0xFF00,0x0000,0xFF00,0x0000,0xFFFF,0xFFF0,0x0000,0x0000,
	0xFFFF,0xFFF0,0xFF00,0x0000,0xFF00,0x0000,0xFFFF,0xF000,
	0xFF00,0x0000,0xFF00,0x0000,0xFF00,0x0000,0x0000,0x0000,
	0x0FFF,0xFFF0,0xFF00,0x0000,0xFF00,0x0000,0xFF0F,0xFFF0,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFFF0,0x0000,0x0000,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0xFF00,0x0FF0,0xFFFF,0xFFF0,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0xFF00,0x0FF0,0x0000,0x0000,
	0xFFFF,0xFFF0,0x00FF,0xF000,0x00FF,0xF000,0x00FF,0xF000,
	0x00FF,0xF000,0x00FF,0xF000,0xFFFF,0xFFF0,0x0000,0x0000,
	0x000F,0xFFF0,0x0000,0x0FF0,0x0000,0x0FF0,0x0000,0x0FF0,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0xFF00,0x0FF0,0xFF00,0xFF00,0xFF0F,0xF000,0xFFFF,0x0000,
	0xFF0F,0xF000,0xFF00,0xFF00,0xFF00,0x0FF0,0x0000,0x0000,
	0xFF00,0x0000,0xFF00,0x0000,0xFF00,0x0000,0xFF00,0x0000,
	0xFF00,0x0000,0xFF00,0x0000,0xFFFF,0xFFF0,0x0000,0x0000,
	0xFF00,0x0FF0,0xFFF0,0xFFF0,0xFFFF,0xFFF0,0xFF0F,0x0FF0,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0xFF00,0x0FF0,0x0000,0x0000,
	0xFF00,0x0FF0,0xFFF0,0x0FF0,0xFFFF,0x0FF0,0xFF0F,0xFFF0,
	0xFF00,0xFFF0,0xFF00,0x0FF0,0xFF00,0x0FF0,0x0000,0x0000,
	0x0FFF,0xFF00,0xFF00,0x0FF0,0xFF00,0x0FF0,0xFF00,0x0FF0,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0xFFFF,0xFF00,0xFF00,0x0FF0,0xFF00,0x0FF0,0xFFFF,0xFF00,
	0xFF00,0x0000,0xFF00,0x0000,0xFF00,0x0000,0x0000,0x0000,
	0x0FFF,0xFF00,0xFF00,0x0FF0,0xFF00,0x0FF0,0xFF00,0x0FF0,
	0xFF0F,0xFFF0,0xFF00,0xFF00,0x0FFF,0xF0F0,0x0000,0x0000,
	0xFFFF,0xFF00,0xFF00,0x0FF0,0xFF00,0x0FF0,0xFFFF,0xFF00,
	0xFF0F,0xF000,0xFF00,0xFF00,0xFF00,0x0FF0,0x0000,0x0000,
	0x0FFF,0xFF00,0xFF00,0x0FF0,0xFF00,0x0000,0x0FFF,0xFF00,
	0x0000,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0xFFFF,0xFFF0,0x00FF,0xF000,0x00FF,0xF000,0x00FF,0xF000,
	0x00FF,0xF000,0x00FF,0xF000,0x00FF,0xF000,0x0000,0x0000,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0xFF00,0x0FF0,0xFF00,0x0FF0,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0xFF00,0x0FF0,0xFF00,0x0FF0,
	0x0FF0,0xFF00,0x00FF,0xF000,0x000F,0x0000,0x0000,0x0000,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0xFF0F,0x0FF0,0xFFFF,0xFFF0,
	0xFFF0,0xFFF0,0xFF00,0x0FF0,0xFF00,0x0FF0,0x0000,0x0000,
	0xFF00,0x0FF0,0xFFF0,0xFFF0,0x0FFF,0xFF00,0x00FF,0xF000,
	0x0FFF,0xFF00,0xFFF0,0xFFF0,0xFF00,0x0FF0,0x0000,0x0000,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,
	0x00FF,0xF000,0x00FF,0xF000,0x00FF,0xF000,0x0000,0x0000,
	0xFFFF,0xFFF0,0x0000,0xFFF0,0x000F,0xFF00,0x00FF,0xF000,
	0x0FFF,0x0000,0xFFF0,0x0000,0xFFFF,0xFFF0,0x0000,0x0000,
	0x0FFF,0xFF00,0x0FF0,0x0000,0x0FF0,0x0000,0x0FF0,0x0000,
	0x0FF0,0x0000,0x0FF0,0x0000,0x0FFF,0xFF00,0x0000,0x0000,
	0x0F00,0x0000,0x0FF0,0x0000,0x00FF,0x0000,0x000F,0xF000,
	0x0000,0xFF00,0x0000,0x0FF0,0x0000,0x00F0,0x0000,0x0000,
	0x0FFF,0xFF00,0x0000,0xFF00,0x0000,0xFF00,0x0000,0xFF00,
	0x0000,0xFF00,0x0000,0xFF00,0x0FFF,0xFF00,0x0000,0x0000,
	0x000F,0x0000,0x00FF,0xF000,0x0FF0,0xFF00,0xFF00,0x0FF0,
	0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0xFFFF,0xFFF0,0x0000,0x0000,
	0x00F0,0x0000,0x000F,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0FFF,0xFF00,0x0000,0x0FF0,
	0x0FFF,0xFFF0,0xFF00,0x0FF0,0x0FFF,0xFFF0,0x0000,0x0000,
	0xFF00,0x0000,0xFF00,0x0000,0xFFFF,0xFF00,0xFF00,0x0FF0,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0xFFFF,0xFF00,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0FFF,0xFF00,0xFF00,0x0FF0,
	0xFF00,0x0000,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0x0000,0x0FF0,0x0000,0x0FF0,0x0FFF,0xFFF0,0xFF00,0x0FF0,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFFF0,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0FFF,0xFF00,0xFF00,0x0FF0,
	0xFFFF,0xFFF0,0xFF00,0x0000,0x0FFF,0xFF00,0x0000,0x0000,
	0x00FF,0xFF00,0x00FF,0x0000,0xFFFF,0xFFF0,0x00FF,0x0000,
	0x00FF,0x0000,0x00FF,0x0000,0x00FF,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0FFF,0xFFF0,0xFF00,0x0FF0,
	0x0FFF,0xFFF0,0x0000,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0xFF00,0x0000,0xFF00,0x0000,0xFFFF,0xFF00,0xFF00,0x0FF0,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0xFF00,0x0FF0,0x0000,0x0000,
	0x000F,0xF000,0x0000,0x0000,0x0FFF,0xF000,0x000F,0xF000,
	0x000F,0xF000,0x000F,0xF000,0xFFFF,0xFFF0,0x0000,0x0000,
	0x0000,0x0FF0,0x0000,0x0000,0x0000,0x0FF0,0x0000,0x0FF0,
	0x0000,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0xFF00,0x0000,0xFF00,0x0000,0xFF00,0x0FF0,0xFF00,0xFF00,
	0xFFFF,0xF000,0xFF00,0xFF00,0xFF00,0x0FF0,0x0000,0x0000,
	0xFF00,0x0000,0xFF00,0x0000,0xFF00,0x0000,0xFF00,0x0000,
	0xFF00,0x0000,0x0FFF,0x0000,0x000F,0xFFF0,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0xFFFF,0xFF00,0xFF0F,0x0FF0,
	0xFF0F,0x0FF0,0xFF0F,0x0FF0,0xFF0F,0x0FF0,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0xFFFF,0xFF00,0xFF00,0x0FF0,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0xFF00,0x0FF0,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0FFF,0xFF00,0xFF00,0x0FF0,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0xFFFF,0xFF00,0xFF00,0x0FF0,
	0xFFFF,0xFF00,0xFF00,0x0000,0xFF00,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0FFF,0xFFF0,0xFF00,0x0FF0,
	0x0FFF,0xFFF0,0x0000,0x0FF0,0x0000,0x0FF0,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0xFF0F,0xFF00,0xFFF0,0x0FF0,
	0xFF00,0x0000,0xFF00,0x0000,0xFF00,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0FFF,0xFFF0,0xFF00,0x0000,
	0xFFFF,0xFFF0,0x0000,0x0FF0,0xFFFF,0xFF00,0x0000,0x0000,
	0x00FF,0x0000,0x00FF,0x0000,0xFFFF,0xFFF0,0x00FF,0x0000,
	0x00FF,0x0000,0x00FF,0x0000,0x00FF,0xFFF0,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0xFF00,0x0FF0,0xFF00,0x0FF0,
	0xFF00,0x0FF0,0xFF00,0x0FF0,0x0FFF,0xFF00,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0xFF00,0x0FF0,0xFF00,0x0FF0,
	0x0FF0,0xFF00,0x00FF,0xF000,0x000F,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0xFF00,0x0FF0,0xFF0F,0x0FF0,
	0xFF0F,0x0FF0,0xFFFF,0xFFF0,0x0FF0,0xFF00,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0xFFF0,0xFFF0,0x0FFF,0xFF00,
	0x00FF,0xF000,0x0FFF,0xFF00,0xFFF0,0xFFF0,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0xFF00,0x0FF0,0xFF00,0x0FF0,
	0x0FF0,0xFF00,0x00FF,0xF000,0xFFFF,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0xFFFF,0xFFF0,0x000F,0xFF00,
	0x00FF,0xF000,0x0FFF,0x0000,0xFFFF,0xFFF0,0x0000,0x0000,
	0x000F,0xFF00,0x00FF,0x0000,0x00FF,0x0000,0x0FFF,0x0000,
	0x00FF,0x0000,0x00FF,0x0000,0x000F,0xFF00,0x0000,0x0000,
	0x00FF,0x0000,0x00FF,0x0000,0x00FF,0x0000,0x00FF,0x0000,
	0x00FF,0x0000,0x00FF,0x0000,0x00FF,0x0000,0x0000,0x0000,
	0x0FFF,0x0000,0x000F,0xF000,0x000F,0xF000,0x000F,0xFF00,
	0x000F,0xF000,0x000F,0xF000,0x0FFF,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0FFF,0x0FF0,
	0xFF0F,0x0FF0,0xFF0F,0xFF00,0x0000,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
	0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000
};

const __prog__ unsigned char __attribute__((space(prog))) character_conversion[256] = 
//const unsigned char character_conversion[256] =
{
  	0x00,0x16,0x0C,0x0E,0x1E,0x1C,0x1D,0x15,
	0x00,0x18,0x07,0x0F,0x1F,0x09,0x60,0x00,
	0x00,0x00,0x00,0x00,0x00,0x71,0x31,0x00,
	0x00,0x00,0x7A,0x73,0x61,0x77,0x32,0x00,
	0x00,0x63,0x78,0x64,0x65,0x34,0x33,0x00,
	0x00,0x20,0x76,0x66,0x74,0x72,0x35,0x00,
	0x00,0x6E,0x62,0x68,0x67,0x79,0x36,0x00,
	0x00,0x00,0x6D,0x6A,0x75,0x37,0x38,0x00,
	0x00,0x2C,0x6B,0x69,0x6F,0x30,0x39,0x00,
	0x00,0x2E,0x2F,0x6C,0x3B,0x70,0x2D,0x00,
	0x00,0x00,0x27,0x00,0x5B,0x3D,0x00,0x00,
	0x00,0x00,0x0D,0x5D,0x00,0x5C,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x08,0x00,
	0x00,0x31,0x00,0x34,0x37,0x00,0x00,0x00,
	0x30,0x2E,0x32,0x35,0x36,0x38,0x1B,0x00,
	0x19,0x2B,0x33,0x2D,0x2A,0x39,0x00,0x00,

	0x00,0x16,0x0C,0x0E,0x1E,0x1C,0x1D,0x15,
	0x00,0x18,0x07,0x0F,0x1F,0x09,0x7E,0x00,
	0x00,0x00,0x00,0x00,0x00,0x51,0x21,0x00,
	0x00,0x00,0x5A,0x53,0x41,0x57,0x40,0x00,
	0x00,0x43,0x58,0x44,0x45,0x24,0x23,0x00,
	0x00,0x20,0x56,0x46,0x54,0x52,0x25,0x00,
	0x00,0x4E,0x42,0x48,0x47,0x59,0x5E,0x00,
	0x00,0x00,0x4D,0x4A,0x55,0x26,0x2A,0x00,
	0x00,0x3C,0x4B,0x49,0x4F,0x29,0x28,0x00,
	0x00,0x3E,0x3F,0x4C,0x3A,0x50,0x5F,0x00,
	0x00,0x00,0x22,0x00,0x7B,0x2B,0x00,0x00,
	0x00,0x00,0x0D,0x7D,0x00,0x7C,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x08,0x00,
	0x00,0x03,0x00,0x13,0x02,0x00,0x00,0x00,
	0x1A,0x7F,0x12,0x35,0x14,0x11,0x1B,0x00,
	0x19,0x2B,0x04,0x2D,0x2A,0x01,0x00,0x00
};


void character(unsigned int x, unsigned int y, unsigned char value)
{
	unsigned int pos = (unsigned int)(value - 32) * 16;
  
	for (unsigned int i=y; i<y+8; i++)
	{		
		screen[i * 80 + x] = character_bitmap[pos];		
		screen[i * 80 + x + 1] = character_bitmap[pos+1];
		
		pos += 2;
	}
};

void hex(unsigned char x, unsigned char y, unsigned char value)
{
	volatile unsigned char temp = (unsigned char)((value & 0xF0) >> 4);
		
	if (temp < 0x0A) character(x, y, (unsigned char)(temp + '0'));
	else character(x, y, (unsigned char)(temp - 0x0A + 'A'));
		
	temp = (unsigned char)(value & 0x0F);
		
	if (temp < 0x0A) character(x + 0x02, y, (unsigned char)(temp + '0'));
	else character(x + 0x02, y, (unsigned char)(temp - 0x0A + 'A'));
};

void decimal(unsigned char x, unsigned char y, unsigned int value)
{
	volatile unsigned int temp = 0;
	volatile unsigned int next = 0;
	
	next = value;
	
	temp = next / 10000;
	character(x, y, (unsigned char)(temp + '0'));
	next = next - 10000 * temp;
	
	temp = next / 1000;
	character(x + 0x02, y, (unsigned char)(temp + '0'));
	next = next - 1000 * temp;
	
	temp = next / 100;
	character(x + 0x04, y, (unsigned char)(temp + '0'));
	next = next - 100 * temp;
	
	temp = next / 10;
	character(x + 0x06, y, (unsigned char)(temp + '0'));
	next = next - 10 * temp;
	
	temp = next;
	character(x + 0x08, y, (unsigned char)(temp + '0'));
};

void string(unsigned char x, unsigned char y, char *value)
{
	volatile unsigned char pos = 0;
	
	while (value[pos] != '\\')
	{
		character(x + pos * 2, y, value[pos]);
		
		pos++;
	}
};

void sound_high(unsigned int value, unsigned int duration)
{
	PR4 = value;
	line[92] = duration;
	line[90] = 0;
	T4CONbits.TON = 1;
}

void sound_low(unsigned int value, unsigned int duration)
{
	PR5 = value;
	line[93] = duration;
	line[91] = 0;
	T5CONbits.TON = 1;
}
  


#include "data.c"




const __prog__ unsigned int __attribute__((space(prog))) music_note[4800] = {
	0, 0, 51, 0, 39, 0, 51, 19, 39, 19, 63, 28, 39, 38, 63, 48, 61, 57, 
	39, 57, 63, 67, 51, 76, 39, 76, 51, 96, 39, 96, 63, 105, 39, 115, 63, 124, 61, 134, 
	39, 134, 63, 144, 51, 153, 39, 153, 51, 172, 39, 172, 63, 182, 39, 192, 63, 201, 61, 211, 
	39, 211, 63, 220, 51, 230, 42, 230, 51, 249, 42, 249, 54, 259, 56, 268, 44, 268, 54, 288, 
	44, 288, 56, 297, 51, 307, 39, 307, 51, 326, 39, 326, 63, 336, 39, 345, 63, 355, 61, 364, 
	39, 364, 63, 374, 51, 384, 39, 384, 51, 403, 39, 403, 63, 412, 39, 422, 63, 432, 61, 441, 
	39, 441, 63, 451, 51, 460, 39, 460, 51, 480, 39, 480, 63, 489, 39, 499, 63, 508, 61, 518, 
	39, 518, 63, 528, 56, 537, 44, 537, 54, 556, 44, 556, 56, 566, 54, 576, 42, 576, 54, 595, 
	42, 595, 56, 604, 51, 614, 39, 614, 51, 633, 39, 633, 63, 643, 39, 652, 63, 662, 61, 672, 
	39, 672, 63, 681, 51, 691, 39, 691, 51, 710, 39, 710, 63, 720, 39, 729, 63, 739, 61, 748, 
	39, 748, 63, 758, 51, 768, 39, 768, 51, 787, 39, 787, 63, 796, 39, 806, 63, 816, 61, 825, 
	39, 825, 63, 835, 51, 844, 42, 844, 51, 864, 42, 864, 54, 873, 56, 883, 44, 883, 54, 902, 
	44, 902, 56, 912, 51, 921, 39, 921, 51, 940, 39, 940, 63, 950, 39, 960, 63, 969, 61, 979, 
	39, 979, 63, 988, 51, 998, 39, 998, 51, 1017, 39, 1017, 63, 1027, 39, 1036, 63, 1046, 61, 1056, 
	39, 1056, 63, 1065, 51, 1075, 39, 1075, 51, 1094, 39, 1094, 63, 1104, 39, 1113, 63, 1123, 61, 1132, 
	39, 1132, 63, 1142, 56, 1152, 44, 1152, 54, 1166, 42, 1166, 56, 1180, 44, 1180, 54, 1190, 42, 1190, 
	51, 1204, 39, 1204, 54, 1219, 42, 1219, 39, 1228, 63, 1228, 39, 1248, 65, 1248, 51, 1257, 39, 1267, 
	66, 1267, 51, 1276, 49, 1286, 39, 1286, 68, 1286, 51, 1296, 39, 1305, 70, 1305, 39, 1324, 51, 1334, 
	39, 1344, 75, 1344, 51, 1353, 49, 1363, 39, 1363, 73, 1363, 51, 1372, 39, 1382, 70, 1382, 39, 1401, 
	51, 1411, 39, 1420, 63, 1420, 51, 1430, 49, 1440, 39, 1440, 51, 1449, 39, 1459, 70, 1459, 39, 1478, 
	68, 1478, 51, 1488, 39, 1497, 66, 1497, 51, 1507, 49, 1516, 39, 1516, 65, 1516, 51, 1526, 35, 1536, 
	63, 1536, 35, 1555, 65, 1555, 51, 1564, 35, 1574, 66, 1574, 51, 1584, 49, 1593, 35, 1593, 68, 1593, 
	51, 1603, 35, 1612, 70, 1612, 35, 1632, 51, 1641, 35, 1651, 68, 1651, 51, 1660, 49, 1670, 35, 1670, 
	66, 1670, 51, 1680, 35, 1689, 65, 1689, 35, 1708, 63, 1708, 51, 1718, 35, 1728, 65, 1728, 51, 1737, 
	49, 1747, 35, 1747, 66, 1747, 51, 1756, 37, 1766, 65, 1766, 37, 1785, 63, 1785, 51, 1795, 37, 1804, 
	62, 1804, 51, 1814, 49, 1824, 37, 1824, 65, 1824, 51, 1833, 39, 1843, 63, 1843, 39, 1862, 65, 1862, 
	51, 1872, 39, 1881, 66, 1881, 51, 1891, 49, 1900, 39, 1900, 68, 1900, 51, 1910, 39, 1920, 70, 1920, 
	39, 1939, 51, 1948, 39, 1958, 75, 1958, 51, 1968, 49, 1977, 39, 1977, 73, 1977, 51, 1987, 39, 1996, 
	70, 1996, 39, 2016, 51, 2025, 39, 2035, 63, 2035, 51, 2044, 49, 2054, 39, 2054, 51, 2064, 39, 2073, 
	70, 2073, 39, 2092, 68, 2092, 51, 2102, 39, 2112, 66, 2112, 51, 2121, 49, 2131, 39, 2131, 65, 2131, 
	51, 2140, 35, 2150, 63, 2150, 35, 2169, 65, 2169, 51, 2179, 35, 2188, 66, 2188, 51, 2198, 49, 2208, 
	35, 2208, 68, 2208, 51, 2217, 35, 2227, 70, 2227, 35, 2246, 51, 2256, 35, 2265, 68, 2265, 51, 2275, 
	49, 2284, 35, 2284, 66, 2284, 51, 2294, 35, 2304, 65, 2304, 53, 2304, 35, 2323, 35, 2342, 66, 2342, 
	54, 2342, 35, 2361, 37, 2380, 68, 2380, 56, 2380, 37, 2400, 37, 2419, 70, 2419, 58, 2419, 37, 2438, 
	39, 2457, 63, 2457, 75, 2457, 39, 2476, 65, 2476, 77, 2476, 51, 2486, 39, 2496, 66, 2496, 78, 2496, 
	51, 2505, 49, 2515, 39, 2515, 68, 2515, 80, 2515, 51, 2524, 39, 2534, 70, 2534, 82, 2534, 39, 2553, 
	51, 2563, 39, 2572, 75, 2572, 87, 2572, 51, 2582, 49, 2592, 39, 2592, 73, 2592, 85, 2592, 51, 2601, 
	39, 2611, 70, 2611, 82, 2611, 39, 2630, 51, 2640, 39, 2649, 63, 2649, 75, 2649, 51, 2659, 49, 2668, 
	39, 2668, 51, 2678, 39, 2688, 70, 2688, 82, 2688, 39, 2707, 68, 2707, 80, 2707, 51, 2716, 39, 2726, 
	66, 2726, 78, 2726, 51, 2736, 49, 2745, 39, 2745, 65, 2745, 77, 2745, 51, 2755, 35, 2764, 63, 2764, 
	75, 2764, 35, 2784, 65, 2784, 77, 2784, 51, 2793, 35, 2803, 66, 2803, 78, 2803, 51, 2812, 49, 2822, 
	35, 2822, 68, 2822, 80, 2822, 51, 2832, 35, 2841, 70, 2841, 82, 2841, 35, 2860, 51, 2870, 35, 2880, 
	68, 2880, 80, 2880, 51, 2889, 49, 2899, 35, 2899, 66, 2899, 78, 2899, 51, 2908, 35, 2918, 65, 2918, 
	77, 2918, 35, 2937, 63, 2937, 75, 2937, 51, 2947, 35, 2956, 65, 2956, 77, 2956, 51, 2966, 49, 2976, 
	35, 2976, 66, 2976, 78, 2976, 51, 2985, 37, 2995, 65, 2995, 77, 2995, 37, 3014, 63, 3014, 75, 3014, 
	51, 3024, 37, 3033, 62, 3033, 74, 3033, 51, 3043, 49, 3052, 37, 3052, 65, 3052, 77, 3052, 51, 3062, 
	39, 3072, 63, 3072, 75, 3072, 39, 3091, 65, 3091, 77, 3091, 51, 3100, 39, 3110, 66, 3110, 78, 3110, 
	51, 3120, 49, 3129, 39, 3129, 68, 3129, 80, 3129, 51, 3139, 39, 3148, 70, 3148, 82, 3148, 39, 3168, 
	51, 3177, 39, 3187, 75, 3187, 87, 3187, 51, 3196, 49, 3206, 39, 3206, 73, 3206, 85, 3206, 51, 3216, 
	39, 3225, 70, 3225, 82, 3225, 39, 3244, 51, 3254, 39, 3264, 63, 3264, 75, 3264, 51, 3273, 49, 3283, 
	39, 3283, 51, 3292, 39, 3302, 70, 3302, 82, 3302, 39, 3321, 68, 3321, 80, 3321, 51, 3331, 39, 3340, 
	66, 3340, 78, 3340, 51, 3350, 49, 3360, 39, 3360, 65, 3360, 77, 3360, 51, 3369, 35, 3379, 63, 3379, 
	75, 3379, 35, 3398, 65, 3398, 77, 3398, 51, 3408, 35, 3417, 66, 3417, 78, 3417, 51, 3427, 49, 3436, 
	35, 3436, 68, 3436, 80, 3436, 51, 3446, 35, 3456, 70, 3456, 82, 3456, 35, 3475, 51, 3484, 35, 3494, 
	68, 3494, 80, 3494, 51, 3504, 49, 3513, 35, 3513, 66, 3513, 78, 3513, 51, 3523, 35, 3532, 65, 3532, 
	53, 3532, 77, 3532, 35, 3552, 35, 3571, 66, 3571, 54, 3571, 78, 3571, 35, 3590, 37, 3609, 68, 3609, 
	56, 3609, 80, 3609, 37, 3628, 37, 3648, 70, 3648, 58, 3648, 82, 3648, 70, 3648, 35, 3686, 73, 3686, 
	75, 3705, 35, 3715, 35, 3724, 70, 3724, 35, 3744, 68, 3744, 35, 3763, 70, 3763, 35, 3792, 35, 3801, 
	68, 3801, 35, 3820, 70, 3820, 37, 3840, 73, 3840, 75, 3859, 37, 3868, 37, 3878, 70, 3878, 37, 3897, 
	68, 3897, 37, 3916, 70, 3916, 37, 3945, 37, 3955, 68, 3955, 37, 3974, 70, 3974, 39, 3993, 68, 3993, 
	66, 4012, 39, 4022, 39, 4032, 65, 4032, 39, 4051, 61, 4051, 39, 4070, 63, 4070, 39, 4099, 39, 4108, 
	61, 4108, 39, 4128, 63, 4128, 39, 4147, 65, 4147, 66, 4166, 39, 4176, 39, 4185, 68, 4185, 39, 4204, 
	70, 4204, 39, 4224, 63, 4224, 39, 4252, 39, 4262, 70, 4262, 39, 4281, 73, 4281, 35, 4300, 73, 4300, 
	75, 4320, 35, 4329, 35, 4339, 70, 4339, 35, 4358, 68, 4358, 35, 4377, 70, 4377, 35, 4406, 35, 4416, 
	68, 4416, 35, 4435, 70, 4435, 37, 4454, 73, 4454, 75, 4473, 37, 4483, 37, 4492, 70, 4492, 37, 4512, 
	68, 4512, 37, 4531, 70, 4531, 37, 4560, 37, 4569, 68, 4569, 37, 4588, 70, 4588, 39, 4608, 68, 4608, 
	66, 4627, 39, 4636, 39, 4646, 65, 4646, 39, 4665, 61, 4665, 39, 4684, 63, 4684, 39, 4713, 39, 4723, 
	61, 4723, 39, 4742, 63, 4742, 39, 4761, 65, 4761, 66, 4780, 39, 4790, 39, 4800, 68, 4800, 39, 4819, 
	70, 4819, 39, 4838, 63, 4838, 39, 4867, 39, 4876, 70, 4876, 39, 4896, 73, 4896, 35, 4915, 73, 4915, 
	75, 4934, 35, 4944, 51, 4944, 35, 4953, 70, 4953, 51, 4963, 35, 4972, 49, 4972, 68, 4972, 51, 4982, 
	35, 4992, 70, 4992, 35, 5020, 51, 5020, 35, 5030, 68, 5030, 51, 5040, 35, 5049, 49, 5049, 70, 5049, 
	51, 5059, 37, 5068, 73, 5068, 75, 5088, 37, 5097, 51, 5097, 37, 5107, 70, 5107, 51, 5116, 37, 5126, 
	49, 5126, 68, 5126, 51, 5136, 37, 5145, 70, 5145, 37, 5174, 51, 5174, 37, 5184, 68, 5184, 51, 5193, 
	37, 5203, 49, 5203, 70, 5203, 51, 5212, 39, 5222, 68, 5222, 66, 5241, 39, 5251, 51, 5251, 39, 5260, 
	65, 5260, 51, 5270, 39, 5280, 49, 5280, 61, 5280, 51, 5289, 39, 5299, 63, 5299, 39, 5328, 51, 5328, 
	39, 5337, 61, 5337, 51, 5347, 39, 5356, 49, 5356, 63, 5356, 51, 5366, 39, 5376, 65, 5376, 66, 5395, 
	39, 5404, 51, 5404, 39, 5414, 68, 5414, 51, 5424, 39, 5433, 49, 5433, 70, 5433, 51, 5443, 39, 5452, 
	56, 5452, 63, 5452, 54, 5472, 39, 5481, 56, 5481, 39, 5491, 54, 5491, 70, 5491, 39, 5510, 51, 5510, 
	73, 5510, 56, 5520, 35, 5529, 73, 5529, 75, 5548, 35, 5558, 51, 5558, 35, 5568, 70, 5568, 51, 5577, 
	35, 5587, 49, 5587, 68, 5587, 51, 5596, 35, 5606, 70, 5606, 35, 5635, 51, 5635, 35, 5644, 68, 5644, 
	51, 5654, 35, 5664, 49, 5664, 70, 5664, 51, 5673, 37, 5683, 73, 5683, 75, 5702, 37, 5712, 51, 5712, 
	37, 5721, 70, 5721, 51, 5731, 37, 5740, 49, 5740, 68, 5740, 51, 5750, 37, 5760, 70, 5760, 37, 5788, 
	51, 5788, 37, 5798, 75, 5798, 87, 5798, 51, 5808, 37, 5817, 49, 5817, 77, 5817, 89, 5817, 51, 5827, 
	39, 5836, 78, 5836, 90, 5836, 77, 5856, 89, 5856, 39, 5865, 51, 5865, 39, 5875, 75, 5875, 87, 5875, 
	51, 5884, 39, 5894, 49, 5894, 73, 5894, 85, 5894, 51, 5904, 39, 5913, 70, 5913, 82, 5913, 39, 5942, 
	51, 5942, 39, 5952, 68, 5952, 80, 5952, 51, 5961, 39, 5971, 49, 5971, 70, 5971, 82, 5971, 51, 5980, 
	39, 5990, 68, 5990, 80, 5990, 66, 6009, 78, 6009, 39, 6019, 51, 6019, 39, 6028, 65, 6028, 77, 6028, 
	51, 6038, 39, 6048, 49, 6048, 61, 6048, 73, 6048, 51, 6057, 39, 6067, 56, 6067, 63, 6067, 75, 6067, 
	54, 6086, 39, 6096, 56, 6096, 39, 6105, 54, 6105, 70, 6105, 39, 6124, 51, 6124, 73, 6124, 56, 6134, 
	35, 6144, 73, 6144, 75, 6163, 35, 6182, 70, 6182, 35, 6192, 35, 6201, 68, 6201, 35, 6220, 70, 6220, 
	82, 6220, 35, 6259, 68, 6259, 35, 6268, 35, 6278, 70, 6278, 37, 6297, 73, 6297, 75, 6316, 37, 6336, 
	70, 6336, 37, 6345, 37, 6355, 68, 6355, 37, 6374, 70, 6374, 82, 6374, 37, 6412, 68, 6412, 37, 6422, 
	37, 6432, 70, 6432, 39, 6451, 68, 6451, 66, 6470, 39, 6489, 65, 6489, 39, 6499, 39, 6508, 61, 6508, 
	39, 6528, 63, 6528, 82, 6528, 39, 6566, 61, 6566, 39, 6576, 39, 6585, 63, 6585, 39, 6604, 65, 6604, 
	66, 6624, 39, 6643, 68, 6643, 39, 6652, 75, 6652, 39, 6662, 70, 6662, 39, 6681, 63, 6681, 87, 6681, 
	82, 6691, 39, 6720, 70, 6720, 39, 6729, 39, 6739, 73, 6739, 35, 6758, 73, 6758, 75, 6777, 35, 6796, 
	70, 6796, 35, 6806, 35, 6816, 68, 6816, 35, 6835, 70, 6835, 82, 6835, 35, 6873, 68, 6873, 35, 6883, 
	35, 6892, 70, 6892, 37, 6912, 73, 6912, 75, 6931, 37, 6950, 70, 6950, 37, 6960, 37, 6969, 68, 6969, 
	37, 6988, 70, 6988, 82, 6988, 37, 7027, 68, 7027, 37, 7036, 37, 7046, 70, 7046, 39, 7065, 68, 7065, 
	66, 7084, 39, 7104, 65, 7104, 39, 7113, 39, 7123, 61, 7123, 39, 7142, 63, 7142, 82, 7142, 39, 7180, 
	61, 7180, 39, 7190, 39, 7200, 63, 7200, 39, 7219, 65, 7219, 66, 7238, 39, 7257, 68, 7257, 39, 7267, 
	75, 7267, 39, 7276, 70, 7276, 39, 7296, 63, 7296, 87, 7296, 82, 7305, 39, 7334, 70, 7334, 39, 7344, 
	39, 7353, 73, 7353, 35, 7372, 73, 7372, 47, 7372, 75, 7392, 35, 7411, 70, 7411, 47, 7411, 35, 7420, 
	35, 7430, 68, 7430, 35, 7449, 70, 7449, 47, 7449, 82, 7449, 35, 7488, 68, 7488, 47, 7488, 35, 7497, 
	35, 7507, 70, 7507, 37, 7526, 73, 7526, 49, 7526, 75, 7545, 37, 7564, 70, 7564, 49, 7564, 37, 7574, 
	37, 7584, 68, 7584, 37, 7603, 70, 7603, 49, 7603, 82, 7603, 37, 7641, 68, 7641, 49, 7641, 37, 7651, 
	37, 7660, 70, 7660, 39, 7680, 68, 7680, 51, 7680, 66, 7699, 39, 7718, 65, 7718, 51, 7718, 39, 7728, 
	39, 7737, 61, 7737, 39, 7756, 63, 7756, 51, 7756, 82, 7756, 39, 7795, 61, 7795, 51, 7795, 39, 7804, 
	39, 7814, 63, 7814, 39, 7833, 65, 7833, 51, 7833, 66, 7852, 39, 7872, 68, 7872, 51, 7872, 39, 7881, 
	75, 7881, 39, 7891, 70, 7891, 39, 7910, 63, 7910, 51, 7910, 87, 7910, 82, 7920, 39, 7948, 70, 7948, 
	51, 7948, 39, 7958, 39, 7968, 73, 7968, 35, 7987, 73, 7987, 47, 7987, 75, 8006, 47, 8006, 35, 8025, 
	70, 8025, 47, 8025, 35, 8035, 35, 8044, 68, 8044, 47, 8044, 35, 8064, 70, 8064, 47, 8064, 82, 8064, 
	47, 8083, 35, 8102, 68, 8102, 47, 8102, 35, 8112, 35, 8121, 70, 8121, 47, 8121, 37, 8140, 73, 8140, 
	49, 8140, 75, 8160, 49, 8160, 37, 8179, 70, 8179, 49, 8179, 37, 8188, 37, 8198, 68, 8198, 49, 8198, 
	37, 8217, 70, 8217, 49, 8217, 82, 8217, 49, 8236, 37, 8256, 49, 8256, 75, 8256, 37, 8265, 37, 8275, 
	49, 8275, 77, 8275, 39, 8294, 51, 8294, 78, 8294, 51, 8313, 77, 8313, 39, 8332, 51, 8332, 75, 8332, 
	39, 8342, 39, 8352, 51, 8352, 73, 8352, 39, 8371, 51, 8371, 70, 8371, 82, 8371, 51, 8390, 39, 8409, 
	51, 8409, 68, 8409, 39, 8419, 39, 8428, 51, 8428, 70, 8428, 68, 8448, 66, 8467, 65, 8486, 61, 8505, 
	63, 8524, 56, 8524, 56, 8524, 51, 8524, 44, 8524, 54, 8563, 54, 8563, 49, 8563, 42, 8563, 51, 8601, 
	39, 8601, 51, 8620, 39, 8620, 63, 8630, 39, 8640, 63, 8649, 61, 8659, 39, 8659, 63, 8668, 51, 8678, 
	39, 8678, 51, 8697, 39, 8697, 63, 8707, 39, 8716, 63, 8726, 61, 8736, 39, 8736, 63, 8745, 51, 8755, 
	39, 8755, 51, 8774, 39, 8774, 63, 8784, 39, 8793, 63, 8803, 61, 8812, 39, 8812, 63, 8822, 51, 8832, 
	42, 8832, 51, 8851, 42, 8851, 54, 8860, 56, 8870, 44, 8870, 54, 8889, 44, 8889, 56, 8899, 51, 8908, 
	39, 8908, 51, 8928, 39, 8928, 63, 8937, 39, 8947, 63, 8956, 61, 8966, 39, 8966, 63, 8976, 51, 8985, 
	39, 8985, 51, 9004, 39, 9004, 63, 9014, 39, 9024, 63, 9033, 61, 9043, 39, 9043, 63, 9052, 51, 9062, 
	39, 9062, 51, 9081, 39, 9081, 63, 9091, 39, 9100, 63, 9110, 61, 9120, 39, 9120, 63, 9129, 56, 9139, 
	44, 9139, 54, 9158, 44, 9158, 56, 9168, 54, 9177, 42, 9177, 54, 9196, 42, 9196, 56, 9206, 51, 9216, 
	39, 9216, 51, 9235, 39, 9235, 63, 9244, 39, 9254, 63, 9264, 61, 9273, 39, 9273, 63, 9283, 51, 9292, 
	39, 9292, 51, 9312, 39, 9312, 63, 9321, 39, 9331, 63, 9340, 61, 9350, 39, 9350, 63, 9360, 51, 9369, 
	39, 9369, 51, 9388, 39, 9388, 63, 9398, 39, 9408, 63, 9417, 61, 9427, 39, 9427, 63, 9436, 51, 9446, 
	42, 9446, 51, 9465, 42, 9465, 54, 9475, 56, 9484, 44, 9484, 54, 9504, 44, 9504, 56, 9513, 51, 9523, 
	39, 9523, 51, 9542, 39, 9542, 63, 9552, 39, 9561, 63, 9571, 61, 9580, 39, 9580, 63, 9590, 51, 9600, 
	39, 9600, 51, 9619, 39, 9619, 63, 9628, 39, 9638, 63, 9648, 61, 9657, 39, 9657, 63, 9667, 51, 9676, 
	39, 9676, 51, 9696, 39, 9696, 63, 9705, 39, 9715, 63, 9724, 61, 9734, 39, 9734, 63, 9744, 56, 9753, 
	44, 9753, 54, 9768, 42, 9768, 56, 9782, 44, 9782, 54, 9792, 42, 9792, 51, 9806, 39, 9806, 54, 9820, 
	42, 9820, 39, 9830, 63, 9830, 39, 9849, 65, 9849, 51, 9859, 39, 9868, 66, 9868, 51, 9878, 49, 9888, 
	39, 9888, 68, 9888, 51, 9897, 39, 9907, 70, 9907, 39, 9926, 51, 9936, 39, 9945, 75, 9945, 51, 9955, 
	49, 9964, 39, 9964, 73, 9964, 51, 9974, 39, 9984, 70, 9984, 39, 10003, 51, 10012, 39, 10022, 63, 10022, 
	51, 10032, 49, 10041, 39, 10041, 51, 10051, 39, 10060, 70, 10060, 39, 10080, 68, 10080, 51, 10089, 39, 10099, 
	66, 10099, 51, 10108, 49, 10118, 39, 10118, 65, 10118, 51, 10128, 35, 10137, 63, 10137, 35, 10156, 65, 10156, 
	51, 10166, 35, 10176, 66, 10176, 51, 10185, 49, 10195, 35, 10195, 68, 10195, 51, 10204, 35, 10214, 70, 10214, 
	35, 10233, 51, 10243, 35, 10252, 68, 10252, 51, 10262, 49, 10272, 35, 10272, 66, 10272, 51, 10281, 35, 10291, 
	65, 10291, 35, 10310, 63, 10310, 51, 10320, 35, 10329, 65, 10329, 51, 10339, 49, 10348, 35, 10348, 66, 10348, 
	51, 10358, 37, 10368, 65, 10368, 37, 10387, 63, 10387, 51, 10396, 37, 10406, 62, 10406, 51, 10416, 49, 10425, 
	37, 10425, 65, 10425, 51, 10435, 39, 10444, 63, 10444, 39, 10464, 65, 10464, 51, 10473, 39, 10483, 66, 10483, 
	51, 10492, 49, 10502, 39, 10502, 68, 10502, 51, 10512, 39, 10521, 70, 10521, 39, 10540, 51, 10550, 39, 10560, 
	75, 10560, 51, 10569, 49, 10579, 39, 10579, 73, 10579, 51, 10588, 39, 10598, 70, 10598, 39, 10617, 51, 10627, 
	39, 10636, 63, 10636, 51, 10646, 49, 10656, 39, 10656, 51, 10665, 39, 10675, 70, 10675, 39, 10694, 68, 10694, 
	51, 10704, 39, 10713, 66, 10713, 51, 10723, 49, 10732, 39, 10732, 65, 10732, 51, 10742, 35, 10752, 63, 10752, 
	35, 10771, 65, 10771, 51, 10780, 35, 10790, 66, 10790, 51, 10800, 49, 10809, 35, 10809, 68, 10809, 51, 10819, 
	35, 10828, 70, 10828, 35, 10848, 51, 10857, 35, 10867, 68, 10867, 51, 10876, 49, 10886, 35, 10886, 66, 10886, 
	51, 10896, 35, 10905, 65, 10905, 53, 10905, 35, 10924, 65, 10924, 35, 10944, 66, 10944, 54, 10944, 35, 10963, 
	66, 10963, 37, 10982, 68, 10982, 56, 10982, 37, 11001, 68, 11001, 37, 11020, 70, 11020, 58, 11020, 37, 11040, 
	70, 11040, 39, 11059, 63, 11059, 75, 11059, 39, 11078, 65, 11078, 77, 11078, 51, 11088, 39, 11097, 66, 11097, 
	78, 11097, 51, 11107, 49, 11116, 39, 11116, 68, 11116, 80, 11116, 51, 11126, 39, 11136, 70, 11136, 82, 11136, 
	39, 11155, 51, 11164, 39, 11174, 75, 11174, 87, 11174, 51, 11184, 49, 11193, 39, 11193, 73, 11193, 85, 11193, 
	51, 11203, 39, 11212, 70, 11212, 82, 11212, 39, 11232, 51, 11241, 39, 11251, 63, 11251, 75, 11251, 51, 11260, 
	49, 11270, 39, 11270, 51, 11280, 39, 11289, 70, 11289, 82, 11289, 39, 11308, 68, 11308, 80, 11308, 51, 11318, 
	39, 11328, 66, 11328, 78, 11328, 51, 11337, 49, 11347, 39, 11347, 65, 11347, 77, 11347, 51, 11356, 35, 11366, 
	63, 11366, 75, 11366, 35, 11385, 65, 11385, 77, 11385, 51, 11395, 35, 11404, 66, 11404, 78, 11404, 51, 11414, 
	49, 11424, 35, 11424, 68, 11424, 80, 11424, 51, 11433, 35, 11443, 70, 11443, 82, 11443, 35, 11462, 51, 11472, 
	35, 11481, 68, 11481, 80, 11481, 51, 11491, 49, 11500, 35, 11500, 66, 11500, 78, 11500, 51, 11510, 35, 11520, 
	65, 11520, 77, 11520, 35, 11539, 63, 11539, 75, 11539, 51, 11548, 35, 11558, 65, 11558, 77, 11558, 51, 11568, 
	49, 11577, 35, 11577, 66, 11577, 78, 11577, 51, 11587, 37, 11596, 65, 11596, 77, 11596, 37, 11616, 63, 11616, 
	75, 11616, 51, 11625, 37, 11635, 62, 11635, 74, 11635, 51, 11644, 49, 11654, 37, 11654, 65, 11654, 77, 11654, 
	51, 11664, 39, 11673, 63, 11673, 75, 11673, 39, 11692, 65, 11692, 77, 11692, 51, 11702, 39, 11712, 66, 11712, 
	78, 11712, 51, 11721, 49, 11731, 39, 11731, 68, 11731, 80, 11731, 51, 11740, 39, 11750, 70, 11750, 82, 11750, 
	39, 11769, 51, 11779, 39, 11788, 75, 11788, 87, 11788, 51, 11798, 49, 11808, 39, 11808, 73, 11808, 85, 11808, 
	51, 11817, 39, 11827, 70, 11827, 82, 11827, 39, 11846, 51, 11856, 39, 11865, 63, 11865, 75, 11865, 51, 11875, 
	49, 11884, 39, 11884, 51, 11894, 39, 11904, 70, 11904, 82, 11904, 39, 11923, 68, 11923, 80, 11923, 51, 11932, 
	39, 11942, 66, 11942, 78, 11942, 51, 11952, 49, 11961, 39, 11961, 65, 11961, 77, 11961, 51, 11971, 35, 11980, 
	63, 11980, 75, 11980, 35, 12000, 65, 12000, 77, 12000, 51, 12009, 35, 12019, 66, 12019, 78, 12019, 51, 12028, 
	49, 12038, 35, 12038, 68, 12038, 80, 12038, 51, 12048, 35, 12057, 70, 12057, 82, 12057, 35, 12076, 51, 12086, 
	35, 12096, 68, 12096, 80, 12096, 51, 12105, 49, 12115, 35, 12115, 66, 12115, 78, 12115, 51, 12124, 35, 12134, 
	65, 12134, 53, 12134, 77, 12134, 35, 12153, 35, 12172, 66, 12172, 54, 12172, 78, 12172, 35, 12192, 37, 12211, 
	68, 12211, 56, 12211, 80, 12211, 37, 12230, 37, 12249, 70, 12249, 58, 12249, 82, 12249, 70, 12249, 87, 12249, 
	35, 12288, 73, 12288, 75, 12307, 35, 12316, 35, 12326, 70, 12326, 35, 12345, 68, 12345, 35, 12364, 70, 12364, 
	35, 12393, 35, 12403, 68, 12403, 35, 12422, 70, 12422, 37, 12441, 73, 12441, 75, 12460, 37, 12470, 37, 12480, 
	70, 12480, 37, 12499, 68, 12499, 37, 12518, 70, 12518, 37, 12547, 37, 12556, 68, 12556, 37, 12576, 70, 12576, 
	39, 12595, 68, 12595, 66, 12614, 39, 12624, 39, 12633, 65, 12633, 39, 12652, 61, 12652, 39, 12672, 63, 12672, 
	39, 12700, 39, 12710, 61, 12710, 39, 12729, 63, 12729, 39, 12748, 65, 12748, 66, 12768, 39, 12777, 39, 12787, 
	68, 12787, 39, 12806, 70, 12806, 39, 12825, 63, 12825, 39, 12854, 39, 12864, 70, 12864, 39, 12883, 73, 12883, 
	35, 12902, 73, 12902, 75, 12921, 35, 12931, 35, 12940, 70, 12940, 35, 12960, 68, 12960, 35, 12979, 70, 12979, 
	35, 13008, 35, 13017, 68, 13017, 35, 13036, 70, 13036, 37, 13056, 73, 13056, 75, 13075, 37, 13084, 37, 13094, 
	70, 13094, 37, 13113, 68, 13113, 37, 13132, 70, 13132, 37, 13161, 37, 13171, 68, 13171, 37, 13190, 70, 13190, 
	39, 13209, 68, 13209, 66, 13228, 39, 13238, 39, 13248, 65, 13248, 39, 13267, 61, 13267, 39, 13286, 63, 13286, 
	39, 13315, 39, 13324, 61, 13324, 39, 13344, 63, 13344, 39, 13363, 65, 13363, 66, 13382, 39, 13392, 39, 13401, 
	68, 13401, 39, 13420, 70, 13420, 39, 13440, 63, 13440, 39, 13468, 39, 13478, 70, 13478, 39, 13497, 73, 13497, 
	35, 13516, 73, 13516, 75, 13536, 35, 13545, 51, 13545, 35, 13555, 70, 13555, 51, 13564, 35, 13574, 49, 13574, 
	68, 13574, 51, 13584, 35, 13593, 70, 13593, 35, 13622, 51, 13622, 35, 13632, 68, 13632, 51, 13641, 35, 13651, 
	49, 13651, 70, 13651, 51, 13660, 37, 13670, 73, 13670, 75, 13689, 37, 13699, 51, 13699, 37, 13708, 70, 13708, 
	51, 13718, 37, 13728, 49, 13728, 68, 13728, 51, 13737, 37, 13747, 70, 13747, 37, 13776, 51, 13776, 37, 13785, 
	68, 13785, 51, 13795, 37, 13804, 49, 13804, 70, 13804, 51, 13814, 39, 13824, 68, 13824, 66, 13843, 39, 13852, 
	51, 13852, 39, 13862, 65, 13862, 51, 13872, 39, 13881, 49, 13881, 61, 13881, 51, 13891, 39, 13900, 63, 13900, 
	39, 13929, 51, 13929, 39, 13939, 61, 13939, 51, 13948, 39, 13958, 49, 13958, 63, 13958, 51, 13968, 39, 13977, 
	65, 13977, 66, 13996, 39, 14006, 51, 14006, 39, 14016, 68, 14016, 51, 14025, 39, 14035, 49, 14035, 70, 14035, 
	51, 14044, 39, 14054, 56, 14054, 63, 14054, 54, 14073, 39, 14083, 56, 14083, 39, 14092, 54, 14092, 70, 14092, 
	39, 14112, 51, 14112, 73, 14112, 56, 14121, 35, 14131, 73, 14131, 75, 14150, 35, 14160, 51, 14160, 35, 14169, 
	70, 14169, 51, 14179, 35, 14188, 49, 14188, 68, 14188, 51, 14198, 35, 14208, 70, 14208, 35, 14236, 51, 14236, 
	35, 14246, 68, 14246, 51, 14256, 35, 14265, 49, 14265, 70, 14265, 51, 14275, 37, 14284, 73, 14284, 75, 14304, 
	37, 14313, 51, 14313, 37, 14323, 70, 14323, 51, 14332, 37, 14342, 49, 14342, 68, 14342, 51, 14352, 37, 14361, 
	70, 14361, 37, 14390, 51, 14390, 37, 14400, 75, 14400, 87, 14400, 51, 14409, 37, 14419, 49, 14419, 77, 14419, 
	89, 14419, 51, 14428, 39, 14438, 78, 14438, 90, 14438, 77, 14457, 89, 14457, 39, 14467, 51, 14467, 39, 14476, 
	75, 14476, 87, 14476, 51, 14486, 39, 14496, 49, 14496, 73, 14496, 85, 14496, 51, 14505, 39, 14515, 70, 14515, 
	82, 14515, 39, 14544, 51, 14544, 39, 14553, 68, 14553, 80, 14553, 51, 14563, 39, 14572, 49, 14572, 70, 14572, 
	82, 14572, 51, 14582, 39, 14592, 68, 14592, 80, 14592, 66, 14611, 78, 14611, 39, 14620, 51, 14620, 39, 14630, 
	65, 14630, 77, 14630, 51, 14640, 39, 14649, 49, 14649, 61, 14649, 73, 14649, 51, 14659, 39, 14668, 56, 14668, 
	63, 14668, 75, 14668, 54, 14688, 39, 14697, 56, 14697, 39, 14707, 54, 14707, 71, 14707, 39, 14726, 51, 14726, 
	74, 14726, 36, 14745, 74, 14745, 76, 14764, 36, 14774, 36, 14784, 71, 14784, 36, 14803, 69, 14803, 36, 14822, 
	71, 14822, 36, 14851, 36, 14860, 69, 14860, 36, 14880, 71, 14880, 38, 14899, 74, 14899, 76, 14918, 38, 14928, 
	38, 14937, 71, 14937, 38, 14956, 69, 14956, 38, 14976, 71, 14976, 38, 15004, 38, 15014, 69, 15014, 38, 15033, 
	71, 15033, 40, 15052, 69, 15052, 67, 15072, 40, 15081, 40, 15091, 66, 15091, 40, 15110, 62, 15110, 40, 15129, 
	64, 15129, 40, 15158, 40, 15168, 62, 15168, 40, 15187, 64, 15187, 40, 15206, 66, 15206, 67, 15225, 40, 15235, 
	40, 15244, 69, 15244, 40, 15264, 71, 15264, 40, 15283, 64, 15283, 40, 15312, 40, 15321, 71, 15321, 40, 15340, 
	74, 15340, 36, 15360, 74, 15360, 76, 15379, 36, 15388, 36, 15398, 71, 15398, 36, 15417, 69, 15417, 36, 15436, 
	71, 15436, 36, 15465, 36, 15475, 69, 15475, 36, 15494, 71, 15494, 38, 15513, 74, 15513, 76, 15532, 38, 15542, 
	38, 15552, 71, 15552, 38, 15571, 69, 15571, 38, 15590, 71, 15590, 38, 15619, 38, 15628, 69, 15628, 38, 15648, 
	71, 15648, 40, 15667, 69, 15667, 67, 15686, 40, 15696, 40, 15705, 66, 15705, 40, 15724, 62, 15724, 40, 15744, 
	64, 15744, 40, 15772, 40, 15782, 62, 15782, 40, 15801, 64, 15801, 40, 15820, 66, 15820, 67, 15840, 40, 15849, 
	40, 15859, 69, 15859, 40, 15878, 71, 15878, 40, 15897, 64, 15897, 40, 15926, 40, 15936, 71, 15936, 40, 15955, 
	74, 15955, 36, 15974, 74, 15974, 76, 15993, 36, 16003, 52, 16003, 36, 16012, 71, 16012, 52, 16022, 36, 16032, 
	50, 16032, 69, 16032, 52, 16041, 36, 16051, 71, 16051, 36, 16080, 52, 16080, 36, 16089, 69, 16089, 52, 16099, 
	36, 16108, 50, 16108, 71, 16108, 52, 16118, 38, 16128, 74, 16128, 76, 16147, 38, 16156, 52, 16156, 38, 16166, 
	71, 16166, 52, 16176, 38, 16185, 50, 16185, 69, 16185, 52, 16195, 38, 16204, 71, 16204, 38, 16233, 52, 16233, 
	38, 16243, 69, 16243, 52, 16252, 38, 16262, 50, 16262, 71, 16262, 52, 16272, 40, 16281, 69, 16281, 67, 16300, 
	40, 16310, 52, 16310, 40, 16320, 66, 16320, 52, 16329, 40, 16339, 50, 16339, 62, 16339, 52, 16348, 40, 16358, 
	64, 16358, 40, 16387, 52, 16387, 40, 16396, 62, 16396, 52, 16406, 40, 16416, 50, 16416, 64, 16416, 52, 16425, 
	40, 16435, 66, 16435, 67, 16454, 40, 16464, 52, 16464, 40, 16473, 69, 16473, 52, 16483, 40, 16492, 50, 16492, 
	71, 16492, 52, 16502, 40, 16512, 57, 16512, 64, 16512, 55, 16531, 40, 16540, 57, 16540, 40, 16550, 55, 16550, 
	71, 16550, 40, 16569, 52, 16569, 74, 16569, 57, 16579, 36, 16588, 74, 16588, 76, 16608, 36, 16617, 52, 16617, 
	36, 16627, 71, 16627, 52, 16636, 36, 16646, 50, 16646, 69, 16646, 52, 16656, 36, 16665, 71, 16665, 36, 16694, 
	52, 16694, 36, 16704, 69, 16704, 52, 16713, 36, 16723, 50, 16723, 71, 16723, 52, 16732, 38, 16742, 74, 16742, 
	76, 16761, 38, 16771, 52, 16771, 38, 16780, 71, 16780, 52, 16790, 38, 16800, 50, 16800, 69, 16800, 52, 16809, 
	38, 16819, 71, 16819, 38, 16848, 52, 16848, 38, 16857, 76, 16857, 88, 16857, 52, 16867, 38, 16876, 50, 16876, 
	78, 16876, 90, 16876, 52, 16886, 40, 16896, 79, 16896, 78, 16915, 90, 16915, 40, 16924, 52, 16924, 40, 16934, 
	76, 16934, 88, 16934, 52, 16944, 40, 16953, 50, 16953, 74, 16953, 86, 16953, 52, 16963, 40, 16972, 71, 16972, 
	83, 16972, 40, 17001, 52, 17001, 40, 17011, 69, 17011, 81, 17011, 52, 17020, 40, 17030, 50, 17030, 71, 17030, 
	83, 17030, 69, 17049, 40, 17049, 67, 17068, 40, 17078, 52, 17078, 66, 17088, 40, 17088, 52, 17097, 62, 17107, 
	40, 17107, 50, 17107, 52, 17116, 64, 17126, 40, 17126, 40, 17155, 52, 17155, 40, 17164, 52, 17174, 40, 17184, 
	50, 17184, 52, 17193, 40, 17193, 00, 17200, 00, 17300, 00, 17400, 00, 17500, 00, 17600, 00, 17700, 00, 17800
};



// SDcard commands below
// This was used for the Arduino, but has been modified to work here.

void sdcard_longdelay(void)
{
	unsigned int tally = 0x0000;

	while (tally < 0x1000) // arbitrary amount of time to delay, should be around 10ms
	{
		tally = tally + 1;
	}
}

/*
void sdcard_toggle(void)
{
	PORTCbits.RC9 = 1; // CLK is high
	//for (unsigned int i=0; i<100; i++) { }
	asm("nop");
	asm("nop");
	PORTCbits.RC9 = 0; // CLK is low
	//for (unsigned int i=0; i<100; i++) { }
	asm("nop");
	asm("nop");
}
*/

void sdcard_sendbyte(unsigned int value)
{
	unsigned int temp_value = value;
	
	temp_value = (temp_value & 0x00FF);
	
	/*
	SPI2STATbits.SPIEN = 0;

	for (unsigned int i=0; i<8; i++)
	{
		if (temp_value >= 0x0080)
		{
			PORTCbits.RC8 = 1; // MOSI is high
		}
		else
		{
			PORTCbits.RC8 = 0; // MOSI is low
		}

		temp_value = temp_value << 1;
		
		temp_value = (temp_value & 0x00FF);

		sdcard_toggle();
	}
	
	SPI2STATbits.SPIEN = 1;
	*/
	
	SPI2BUF = temp_value;
	
	while (SPI2STATbits.SPIRBF == 0) { }
	
	temp_value = SPI2BUF; // dummy read
	
};

unsigned int sdcard_receivebyte(void)
{
	unsigned int temp_value = 0x0000;

	/*
	SPI2STATbits.SPIEN = 0;
	
	for (unsigned int i=0; i<8; i++)
	{
		temp_value = temp_value << 1;

		if (PORTBbits.RB7 == 1) // if MISO is high...
		{
			temp_value += 0x0001;
		}

		sdcard_toggle();
	}
	
	SPI2STATbits.SPIEN = 1;
	*/
	
	
	SPI2BUF = 0xFFFF; // dummy write
	
	while (SPI2STATbits.SPIRBF == 0) { }
	
	temp_value = SPI2BUF;
	
	
	temp_value = (temp_value & 0x00FF);
	
	//temp_value = (unsigned int)reverse[(unsigned char)temp_value];
	
	return temp_value;
};


void sdcard_pump(void)
{	
	PORTCbits.RC2 = 1; // CS is high, must disable the device
	
	/*
	SPI2STATbits.SPIEN = 0;
	
	PORTCbits.RC8 = 1; // MOSI is high, AND leave mosi high!!!

	sdcard_longdelay();

	for (unsigned int i=0; i<1000; i++)
	{
		sdcard_toggle();
	}
	
	SPI2STATbits.SPIEN = 1;
	*/
	
	sdcard_longdelay();
	
	for (unsigned int i=0; i<125; i++)
	{
		sdcard_sendbyte(0xFFFF); // MOSI must be high!
	}
};

void sdcard_enable(void)
{
	PORTCbits.RC2 = 0; // CS is low
}

void sdcard_disable(void)
{
	PORTCbits.RC2 = 1; // CS is high
	
	sdcard_sendbyte(0xFFFF);
}

unsigned int sdcard_waitresult(void)
{
	unsigned int temp_value = 0x00FF;

	for (unsigned int i=0; i<65000; i++) // arbitrary wait time
	{
		temp_value = sdcard_receivebyte();

		if (temp_value != 0x00FF)
		{
			return temp_value;
		}
	}

	return 0xFF;
}

unsigned int sdcard_initialize(void)
{
	unsigned int temp_value = 0x0000;

	// make sure they are tri-stated correctly
	TRISC = (TRISC & 0xFCFB);
	TRISB = (TRISB | 0x0080);
	
	PORTCbits.RC2 = 1; // CS is high
	PORTCbits.RC8 = 1; // MOSI is high
	PORTCbits.RC9 = 0; // CLK is low
	
	// sets SPI to appropriate pins 
	__builtin_write_OSCCONL(OSCCON & ~(1<<6));
	RPOR6 = 0x0908; // CLKO/MOSI
	RPINR22 = 0x3927; // CLKI/MISO
	__builtin_write_OSCCONL(OSCCON | (1<<6));
	
	
	SPI2STATbits.SPIEN = 0;
	SPI2CON1bits.DISSCK = 0;
	SPI2CON1bits.DISSDO = 0;
	SPI2CON1bits.MODE16 = 0;
	SPI2CON1bits.MSTEN = 1;
	SPI2CON1bits.SSEN = 0;
	SPI2CON1bits.SMP = 0;
	SPI2CON1bits.CKE = 1;
	SPI2CON1bits.CKP = 0;
	SPI2CON1bits.SPRE = 0;
	SPI2CON1bits.PPRE = 3;
	SPI2CON2 = 0;
	SPI2STATbits.SPIEN = 1;
	
	SPI2BUF = 0xFFFF; // dummy write
	while (SPI2STATbits.SPIRBF == 0) { }
	temp_value = SPI2BUF; // dummy read	
	
	
	sdcard_disable();
	sdcard_pump();
	sdcard_longdelay();
	sdcard_enable();
	sdcard_sendbyte(0x0040); // CMD0 = 0x40 + 0x00 (0 in hex)
	sdcard_sendbyte(0x0000);
	sdcard_sendbyte(0x0000);
	sdcard_sendbyte(0x0000);
	sdcard_sendbyte(0x0000);
	sdcard_sendbyte(0x0095); // CRC for CMD0
	temp_value = sdcard_waitresult(); // command response
	if (temp_value == 0x00FF) { return 0; }	
	sdcard_disable();
	if (temp_value != 0x0001) { return 0; } // expecting 0x01	
	sdcard_longdelay();
	sdcard_pump();
	sdcard_enable();
	sdcard_sendbyte(0x0048); // CMD8 = 0x40 + 0x08 (8 in hex)
	sdcard_sendbyte(0x0000); // CMD8 needs 0x000001AA argument
	sdcard_sendbyte(0x0000);
	sdcard_sendbyte(0x0001);
	sdcard_sendbyte(0x00AA); 
	sdcard_sendbyte(0x0087); // CRC for CMD8
	temp_value = sdcard_waitresult(); // command response
	if (temp_value == 0x00FF) { return 0; }
	sdcard_disable();
	if (temp_value != 0x0001) { return 0; } // expecting 0x01
	sdcard_enable();
	temp_value = sdcard_receivebyte(); // 32-bit return value, ignore
	temp_value = sdcard_receivebyte();
	temp_value = sdcard_receivebyte();
	temp_value = sdcard_receivebyte();
	sdcard_disable();
	do {
		sdcard_pump();
		sdcard_longdelay();
		sdcard_enable();
		sdcard_sendbyte(0x0077); // CMD55 = 0x40 + 0x37 (55 in hex)
		sdcard_sendbyte(0x0000);
		sdcard_sendbyte(0x0000);
		sdcard_sendbyte(0x0000);
		sdcard_sendbyte(0x0000);
		sdcard_sendbyte(0x0001); // CRC (general)
		temp_value = sdcard_waitresult(); // command response
		if (temp_value == 0x00FF) { return 0; }
		sdcard_disable();
		if (temp_value != 0x0001) { break; } // expecting 0x01, but if not it might already be 'initialized'?
		sdcard_pump();
		sdcard_longdelay();
		sdcard_enable();
		sdcard_sendbyte(0x0069); // CMD41 = 0x40 + 0x29 (41 in hex)
		sdcard_sendbyte(0x0040); // needed for CMD41?
		sdcard_sendbyte(0x0000);
		sdcard_sendbyte(0x0000);
		sdcard_sendbyte(0x0000);
		sdcard_sendbyte(0x0001); // CRC (general)
		temp_value = sdcard_waitresult(); // command response
		if (temp_value == 0x00FF) { return 0; }
		sdcard_disable();
		if (temp_value != 0x0000 && temp_value != 0x0001) { return 0; } // expecting 0x00, if 0x01 try again
		sdcard_longdelay();
	} while (temp_value == 0x0001);

	return 1;
}

unsigned int sdcard_readinit(unsigned int high, unsigned int low)
{
	unsigned char temp_value = 0x00;

	sdcard_disable();
	sdcard_pump();
	sdcard_longdelay(); // this is probably not needed
	sdcard_enable();
	sdcard_sendbyte(0x51); // CMD17 = 0x40 + 0x11 (17 in hex)
	sdcard_sendbyte((high&0x00FF));
	sdcard_sendbyte(((low&0xFF00) >> 8));
	sdcard_sendbyte((low&0x00FE)); // only blocks of 512 bytes
	sdcard_sendbyte(0x00);
	sdcard_sendbyte(0x01); // CRC (general)
	temp_value = sdcard_waitresult(); // command response
	if (temp_value == 0xFF) { return 0; }
	else if (temp_value != 0x00) { return 0; } // expecting 0x00
	temp_value = sdcard_waitresult(); // data packet starts with 0xFE
	if (temp_value == 0xFF) { return 0; }
	else if (temp_value != 0xFE) { return 0; }
	
	// after this you read 512 bytes, then the final read
	
	return 1;
}

unsigned int sdcard_readfinal(void)
{
	unsigned char temp_value = 0x00;

	temp_value = sdcard_receivebyte(); // data packet ends with 0x55 then 0xAA
	temp_value = sdcard_receivebyte(); // ignore here
	sdcard_disable();

	return 1;
}

unsigned int sdcard_writeinit(unsigned int high, unsigned int low)
{
	unsigned char temp_value = 0x00;

	sdcard_disable();
	sdcard_pump();
	sdcard_longdelay(); // this is probably not needed
	sdcard_enable();
	sdcard_sendbyte(0x58); // CMD24 = 0x40 + 0x18 (24 in hex)
	sdcard_sendbyte((high&0x00FF));
	sdcard_sendbyte(((low&0xFF00)>>8));
	sdcard_sendbyte((low&0x00FE)); // only blocks of 512 bytes
	sdcard_sendbyte(0x00);
	sdcard_sendbyte(0x01); // CRC (general)
	temp_value = sdcard_waitresult(); // command response
	if (temp_value == 0xFF) { return 0; }
	else if (temp_value != 0x00) { return 0; } // expecting 0x00
	sdcard_sendbyte(0xFE); // data packet starts with 0xFE

	// after this you write 512 bytes, then the final write
	
	return 1;
}

unsigned int sdcard_writefinal(void)
{
	unsigned char temp_value = 0x00;
	
	sdcard_sendbyte(0x55); // data packet ends with 0x55 then 0xAA
	sdcard_sendbyte(0xAA);
	temp_value = sdcard_receivebyte(); // toggle clock 8 times
	sdcard_disable();

	return 1;
}


void Music()
{
	unsigned int pos = 0;
	
	unsigned int ticks = 0;
	
	unsigned int channel = 0;
  
	while (1)
	{
		if (ticks >= music_note[pos+1])
		{
			if (pos >= 2)
			{
				if (music_note[pos+1] == music_note[pos-1])
				{
					if (channel == 0)
					{
						sound_low(6000 - 10 * music_note[pos], 0x0FFF);
						
						channel = 1;
					}
				}
				else
				{
					sound_high(8000 -  10 * music_note[pos], 0x0FFF);
					
					channel = 0;
				}
			}
		
			pos += 2;
		
			if (pos >= 2400)
			{
				pos = 0;
				ticks = 0;
			}
		}
		
		for (unsigned int i=0; i<65000; i++) { } // delay
		
		ticks += 1;
	}
}





const __prog__ unsigned char __attribute__((space(prog))) tetra_random[224] = 
//const unsigned char random[224] =
{
	0, 4, 3, 6, 2, 5, 1,
	4, 1, 3, 5, 2, 0, 6,
	6, 5, 2, 0, 4, 1, 3,
	5, 4, 6, 0, 3, 1, 2,
	
	6, 0, 1, 5, 3, 4, 2,
	2, 4, 0, 5, 1, 6, 3,
	3, 1, 6, 2, 4, 0, 5,
	4, 5, 1, 6, 0, 2, 3,
	
	6, 5, 0, 1, 4, 3, 2,
	3, 5, 2, 6, 1, 0, 4,
	1, 3, 6, 5, 4, 2, 0,
	2, 4, 6, 0, 1, 3, 5,
	
	5, 2, 6, 0, 4, 1, 3,
	5, 0, 2, 4, 6, 1, 3,
	1, 4, 2, 6, 0, 3, 5,
	6, 0, 3, 2, 5, 4, 1,
	
	
	2, 6, 3, 5, 4, 0, 1,
	1, 3, 2, 6, 5, 0, 4,
	6, 4, 0, 3, 5, 2, 1,
	2, 5, 3, 4, 6, 0, 1,
	
	4, 5, 0, 6, 2, 1, 3,
	2, 1, 3, 0, 4, 5, 6,
	2, 0, 5, 4, 6, 1, 3,
	6, 2, 3, 0, 5, 4, 1,
	
	0, 6, 5, 3, 1, 4, 2,
	4, 5, 1, 2, 0, 6, 3,
	4, 1, 6, 3, 0, 2, 5,
	6, 0, 2, 5, 4, 3, 1,
	
	1, 3, 5, 2, 6, 0, 4,
	3, 1, 2, 6, 4, 0, 5,
	4, 2, 0, 1, 6, 3, 5,
	4, 3, 0, 5, 1, 6, 2,
};

const __prog__ char __attribute__((space(prog))) tetra_map[448] =
//const char map[448] =
{
    // I
	' ', ' ', '*', ' ',
	' ', ' ', '*', ' ',
	' ', ' ', '*', ' ',
	' ', ' ', '*', ' ',
	
	' ', ' ', ' ', ' ',
	'*', '*', '*', '*',
	' ', ' ', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	' ', ' ', '*', ' ',
	' ', ' ', '*', ' ',
	' ', ' ', '*', ' ',
	' ', ' ', '*', ' ',
	
	' ', ' ', ' ', ' ',
	'*', '*', '*', '*',
	' ', ' ', ' ', ' ',
	' ', ' ', ' ', ' ',
  
	// J
	' ', ' ', '*', ' ',
	' ', ' ', '*', ' ',
	' ', '*', '*', ' ',
	' ', ' ', ' ', ' ',
	
	' ', ' ', ' ', ' ',
	' ', '*', ' ', ' ',
	' ', '*', '*', '*',
	' ', ' ', ' ', ' ',
	
	' ', ' ', ' ', ' ',
	' ', '*', '*', ' ',
	' ', '*', ' ', ' ',
	' ', '*', ' ', ' ',
	
	' ', ' ', ' ', ' ',
	'*', '*', '*', ' ',
	' ', ' ', '*', ' ',
	' ', ' ', ' ', ' ',
	 
	// L
	' ', '*', ' ', ' ',
	' ', '*', ' ', ' ',
	' ', '*', '*', ' ',
	' ', ' ', ' ', ' ',
	
	' ', ' ', ' ', ' ',
	' ', '*', '*', '*',
	' ', '*', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	' ', ' ', ' ', ' ',
	' ', '*', '*', ' ',
	' ', ' ', '*', ' ',
	' ', ' ', '*', ' ',
	
	' ', ' ', ' ', ' ',
	' ', ' ', '*', ' ',
	'*', '*', '*', ' ',
	' ', ' ', ' ', ' ',
	
	// O
	' ', '*', '*', ' ',
	' ', '*', '*', ' ',
	' ', ' ', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	' ', '*', '*', ' ',
	' ', '*', '*', ' ',
	' ', ' ', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	' ', '*', '*', ' ',
	' ', '*', '*', ' ',
	' ', ' ', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	' ', '*', '*', ' ',
	' ', '*', '*', ' ',
	' ', ' ', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	// S
	' ', ' ', '*', '*',
	' ', '*', '*', ' ',
	' ', ' ', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	' ', '*', ' ', ' ',
	' ', '*', '*', ' ',
	' ', ' ', '*', ' ',
	' ', ' ', ' ', ' ',
	
	' ', ' ', '*', '*',
	' ', '*', '*', ' ',
	' ', ' ', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	' ', '*', ' ', ' ',
	' ', '*', '*', ' ',
	' ', ' ', '*', ' ',
	' ', ' ', ' ', ' ',
	
	// T
	' ', '*', ' ', ' ',
	'*', '*', '*', ' ',
	' ', ' ', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	' ', '*', ' ', ' ',
	' ', '*', '*', ' ',
	' ', '*', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	' ', ' ', ' ', ' ',
	'*', '*', '*', ' ',
	' ', '*', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	' ', '*', ' ', ' ',
	'*', '*', ' ', ' ',
	' ', '*', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	// Z
	'*', '*', ' ', ' ',
	' ', '*', '*', ' ',
	' ', ' ', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	' ', ' ', '*', ' ',
	' ', '*', '*', ' ',
	' ', '*', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	'*', '*', ' ', ' ',
	' ', '*', '*', ' ',
	' ', ' ', ' ', ' ',
	' ', ' ', ' ', ' ',
	
	' ', ' ', '*', ' ',
	' ', '*', '*', ' ',
	' ', '*', ' ', ' ',
	' ', ' ', ' ', ' ',
};

const __prog__ int __attribute__((space(prog))) tetra_icon[4*16] =
{
	0xEEEE,0xEEEE,0xEEEE,0xEEEE,
	0xEEFF,0xFFFF,0xFFFF,0xFFEE,
	0xEEEE,0xEEEE,0xEEEE,0xEEEE,
	0xEEEE,0xEEEE,0xEEEE,0xEEEE,
	0xEE11,0x11B1,0x1EEE,0xFFEE,
	0xEE11,0x11B1,0x11EE,0xEFEE,
	0xEE11,0x11BB,0x111E,0xEEEE,
	0xEE11,0x1111,0x1111,0xEEEE,
	0xEE11,0x1111,0x1771,0x1EEE,
	0xEE1D,0xD111,0x1177,0x11EE,
	0xEE1D,0xD111,0x1111,0x11EE,
	0xEEEE,0xEEEE,0xEEEE,0xEEEE,
	0xEEEE,0xEEEE,0xEEEE,0x5EEE,
	0x1111,0x1EEE,0xEEE1,0x1111,
	0x1111,0xEEEE,0xEEEE,0x1111,
	0x1111,0x1111,0x1111,0x1111,
};


// solid is one single value
void tetra_solid(unsigned int x, unsigned int y, unsigned int value)
{	
	for (unsigned int i=y*8; i<y*8+8; i++)
	{
		for (unsigned int j=x*2; j<x*2+2; j++)
		{
			buffer[i * 40 + j] = value;
		}
	}		
};

// block is fancy looking
void tetra_block(unsigned int x, unsigned int y, unsigned int value)
{
	for (unsigned int i=y*8; i<y*8+8; i++)
	{
		for (unsigned int j=x*2; j<x*2+2; j++)
		{
			if (i == y*8) buffer[i * 40 + j] = 0xFFFF;
			else if (j == x*2) buffer[i * 40 + j] = (value | 0xF000);
			else buffer[i * 40 + j] = value;
		}
	}	
};

void tetra_character(unsigned int x, unsigned int y, unsigned char value)
{
	unsigned int pos = (unsigned int)(value - 32) * 16;
  
	for (unsigned int i=y; i<y+8; i++)
	{		
		buffer[i * 40 + x] = character_bitmap[pos];		
		buffer[i * 40 + x + 1] = character_bitmap[pos+1];
		
		pos += 2;
	}
};

void tetra_decimal(unsigned char x, unsigned char y, unsigned int value)
{
	volatile unsigned int temp = 0;
	volatile unsigned int next = 0;
	
	next = value;
	
	temp = next / 10000;
	tetra_character(x, y, (unsigned char)(temp + '0'));
	next = next - 10000 * temp;
	
	temp = next / 1000;
	tetra_character(x + 0x02, y, (unsigned char)(temp + '0'));
	next = next - 1000 * temp;
	
	temp = next / 100;
	tetra_character(x + 0x04, y, (unsigned char)(temp + '0'));
	next = next - 100 * temp;
	
	temp = next / 10;
	tetra_character(x + 0x06, y, (unsigned char)(temp + '0'));
	next = next - 10 * temp;
	
	temp = next;
	tetra_character(x + 0x08, y, (unsigned char)(temp + '0'));
};

void tetra_string(unsigned char x, unsigned char y, char *value)
{
	volatile unsigned char pos = 0;
	
	while (value[pos] != '\\')
	{
		tetra_character(x + pos * 2, y, value[pos]);
		
		pos++;
	}
};

void tetra_copy(unsigned int side)
{
	// this assembly code allows me to read from the lower screen data!!!
  
	//asm("push DSRPAG");
	//asm("push DSWPAG");

	//asm("movpag #0x001, DSRPAG");
	//asm("movpag #0x001, DSWPAG"); 

	if (side == 0)
	{
	}
	else if (side == 1)
	{
		// then transfer buffer to screen
		for (unsigned int i=0; i<160; i++)
		{
			for (unsigned int j=0; j<40; j++)
			{
				screen[i*80+j] = buffer[i*40+j];
			}
		}
	}
	else if (side == 2)
	{
		// then transfer buffer to screen
		for (unsigned int i=0; i<160; i++)
		{
			for (unsigned int j=0; j<40; j++)
			{
				screen[i*80+j+40] = buffer[i*40+j];
			}
		}
	}

	//asm("pop DSWPAG");
	//asm("pop DSRPAG");
};

const unsigned int tetra_size_x = 10;
const unsigned int tetra_size_y = 18;
volatile unsigned char tetra_board[2*10*18];

// PUT THESE INTO A STRUCT AND RENAME EVERYTHING BELOW!
struct tetra_struct_vars
{
	volatile unsigned int pos_x[2]; // start at 4
	volatile unsigned int pos_y[2]; // start at 4
	volatile unsigned int rot[2];
	volatile unsigned int new_pos_x[2];
	volatile unsigned int new_rot[2];
	volatile unsigned int piece[2];
	volatile unsigned int new_piece[2];

	volatile unsigned int seed;

	volatile unsigned int bag[14];
	volatile unsigned int bag_pos[2];

	volatile unsigned int speed[2];

	volatile unsigned int lines[2];
	volatile unsigned int timer[2];
	
	volatile unsigned char joy_curr[2];
	volatile unsigned char joy_prev[2];
	volatile unsigned int joy_delay[2];

	volatile unsigned int game_over[2];
};

struct tetra_struct_vars tetra_vars;

void TetraInit()
{
	for (volatile unsigned int z=0; z<2; z++)
	{	
		tetra_vars.pos_x[z] = 7; // start at 4
		tetra_vars.pos_y[z] = 4; // start at 4
		tetra_vars.rot[z] = 0;
		tetra_vars.new_pos_x[z] = 7;
		tetra_vars.new_rot[z] = 0;
		tetra_vars.piece[z] = 0;
		tetra_vars.new_piece[z] = 1;
		
		for (volatile unsigned int i=0; i<7; i++)
		{
			tetra_vars.bag[i + z * 7] = i;
		}
		
		tetra_vars.bag_pos[z] = 1;
		
		tetra_vars.speed[z] = 0; // max of 13

		tetra_vars.seed = 0;
		
		tetra_vars.lines[z] = 0;
		tetra_vars.timer[z] = 0;

		tetra_vars.joy_curr[z] = 0x00;
		tetra_vars.joy_prev[z] = 0x00;
		tetra_vars.joy_delay[z] = 0;
		
		tetra_vars.game_over[z] = 0x01;

		for (volatile unsigned int i=0; i<tetra_size_y; i++)
		{
			for (volatile unsigned int j=0; j<tetra_size_x; j++)
			{
				if (i != tetra_size_y - 1)
				{
					tetra_board[j + i * tetra_size_x + z * tetra_size_x * tetra_size_y] = ' '; // empty
				}
				else
				{
					tetra_board[j + i * tetra_size_x + z * tetra_size_x * tetra_size_y] = '_'; // permanent bottom
				}
			}
		}
	}
};

unsigned char TetraCheck(unsigned char player_one, unsigned char player_two)
{
	if (player_one > 0)
	{
		if (tetra_vars.game_over[0] == 2)
		{
			tetra_vars.game_over[0] = 1;
			return 2;
		}
		else return tetra_vars.game_over[0];
	}
	else if (player_two > 0)
	{
		if (tetra_vars.game_over[1] == 2)
		{
			tetra_vars.game_over[1] = 1;
			return 2;
		}
		else return tetra_vars.game_over[1];
	}
	else return 0;
};

void TetraLoop(unsigned char player_one, unsigned char player_two)
{	
	volatile unsigned int test = 0;
	volatile unsigned int count = 0;
	
	//while (1)
	//{				
		tetra_vars.joy_prev[0] = tetra_vars.joy_curr[0];
		tetra_vars.joy_curr[0] = 0xFF; 
		
		// buttons
		if (PORTAbits.RA0 == 0) tetra_vars.joy_curr[0] = (tetra_vars.joy_curr[0] & 0x7F);
		if (PORTAbits.RA1 == 0) tetra_vars.joy_curr[0] = (tetra_vars.joy_curr[0] & 0xBF);
		if (PORTBbits.RB0 == 0) tetra_vars.joy_curr[0] = (tetra_vars.joy_curr[0] & 0xDF);
		if (PORTBbits.RB1 == 0) tetra_vars.joy_curr[0] = (tetra_vars.joy_curr[0] & 0xEF);
		if (PORTCbits.RC0 == 0) tetra_vars.joy_curr[0] = (tetra_vars.joy_curr[0] & 0xFB);
		if (PORTCbits.RC1 == 0) tetra_vars.joy_curr[0] = (tetra_vars.joy_curr[0] & 0xF7);
		if (PORTBbits.RB4 == 0) tetra_vars.joy_curr[0] = (tetra_vars.joy_curr[0] & 0xFB);
		if (PORTAbits.RA4 == 0) tetra_vars.joy_curr[0] = (tetra_vars.joy_curr[0] & 0xF7);
		
		tetra_vars.joy_prev[1] = tetra_vars.joy_curr[1];
		tetra_vars.joy_curr[1] = 0xFF;
		
		// controller
		if (PORTCbits.RC7 == 0) tetra_vars.joy_curr[1] = (tetra_vars.joy_curr[1] & 0x7F);
		if (PORTCbits.RC6 == 0) tetra_vars.joy_curr[1] = (tetra_vars.joy_curr[1] & 0xBF);
		if (PORTCbits.RC5 == 0) tetra_vars.joy_curr[1] = (tetra_vars.joy_curr[1] & 0xDF);
		if (PORTCbits.RC4 == 0) tetra_vars.joy_curr[1] = (tetra_vars.joy_curr[1] & 0xEF);
		if (PORTBbits.RB6 == 0) tetra_vars.joy_curr[1] = (tetra_vars.joy_curr[1] & 0xF7);
		if (PORTBbits.RB5 == 0) tetra_vars.joy_curr[1] = (tetra_vars.joy_curr[1] & 0xFB);
		
		tetra_vars.seed++; // random 
		
		// DELAY HERE!!!
		
		for (volatile unsigned int z=0; z<2; z++)
		{
			if (z == 0 && player_one == 0x00)
			{
				tetra_vars.game_over[0] = 1;
				continue;
			}
			
			if (z == 1 && player_two == 0x00)
			{
				tetra_vars.game_over[1] = 1;
				continue;
			}
			
			if (tetra_vars.game_over[z] == 0)
			{
				for (volatile unsigned int i=0; i<tetra_size_y; i++)
				{
					for (volatile unsigned int j=0; j<tetra_size_x; j++)
					{
						if (tetra_board[j + i * tetra_size_x + z * tetra_size_x * tetra_size_y] == '*') 
						{
							tetra_board[j + i * tetra_size_x + z * tetra_size_x * tetra_size_y] = ' ';
						}
					}
				}
			}

			tetra_vars.new_pos_x[z] = tetra_vars.pos_x[z];
			tetra_vars.new_rot[z] = tetra_vars.rot[z];

			tetra_vars.timer[z]++;

			if (tetra_vars.timer[z] > 15 - tetra_vars.speed[z]) //30 - 2 * tetra_vars.speed[z]) // determines how fast it falls
			{
				tetra_vars.timer[z] = 0;
			}

			tetra_vars.joy_delay[z]++;

			if (tetra_vars.joy_delay[z] > 1) //4) // determines button turbo speed
			{
				tetra_vars.joy_delay[z] = 0;
				tetra_vars.joy_prev[z] = tetra_vars.joy_prev[z] | 0xF0;
			}

			if (((tetra_vars.joy_curr[z] & 0x80) == 0x00) && ((tetra_vars.joy_prev[z] & 0x80) == 0x80)) // up
			{
				tetra_vars.timer[z] = 1; // not zero
				tetra_vars.joy_delay[z] = 0;
			}
			else if (((tetra_vars.joy_curr[z] & 0x40) == 0x00) && ((tetra_vars.joy_prev[z] & 0x40) == 0x40)) // down
			{
				tetra_vars.timer[z] = 0;
				tetra_vars.joy_delay[z] = 0;
			}
			else if (((tetra_vars.joy_curr[z] & 0x20) == 0x00) && ((tetra_vars.joy_prev[z] & 0x20) == 0x20)) // left
			{
				tetra_vars.new_pos_x[z]--;
				tetra_vars.joy_delay[z] = 0;
			}
			else if (((tetra_vars.joy_curr[z] & 0x10) == 0x00) && ((tetra_vars.joy_prev[z] & 0x10) == 0x10)) // right
			{
				tetra_vars.new_pos_x[z]++;
				tetra_vars.joy_delay[z] = 0;
			}
			else if (((tetra_vars.joy_curr[z] & 0x08) == 0x00) && ((tetra_vars.joy_prev[z] & 0x08) == 0x08)) // button 1
			{
				if (tetra_vars.game_over[z] != 0)
				{
					tetra_vars.game_over[z] = 2; // exit game
					
					tetra_vars.speed[z] = 0;
					
					tetra_vars.lines[z] = 0;
					
					for (volatile unsigned int i=0; i<tetra_size_y; i++)
					{
						for (volatile unsigned int j=0; j<tetra_size_x; j++)
						{
							if (i != tetra_size_y - 1)
							{
								tetra_board[j + i * tetra_size_x + z * tetra_size_x * tetra_size_y] = ' '; // empty
							}
							else
							{
								tetra_board[j + i * tetra_size_x + z * tetra_size_x * tetra_size_y] = '_'; // permanent bottom
							}
						}
					}
				}
				else
				{  
					tetra_vars.new_rot[z]++;
					if (tetra_vars.new_rot[z] == 4) tetra_vars.new_rot[z] = 0;
					tetra_vars.joy_delay[z] = 0;
				}
			}
			else if (((tetra_vars.joy_curr[z] & 0x04) == 0x00) && ((tetra_vars.joy_prev[z] & 0x04) == 0x04)) // button 2
			{
				if (tetra_vars.game_over[z] != 0)
				{
					tetra_vars.game_over[z] = 0; // play again
					
					tetra_vars.speed[z] = 0;
					
					tetra_vars.lines[z] = 0;
					
					for (volatile unsigned int i=0; i<tetra_size_y; i++)
					{
						for (volatile unsigned int j=0; j<tetra_size_x; j++)
						{
							if (i != tetra_size_y - 1)
							{
								tetra_board[j + i * tetra_size_x + z * tetra_size_x * tetra_size_y] = ' '; // empty
							}
							else
							{
								tetra_board[j + i * tetra_size_x + z * tetra_size_x * tetra_size_y] = '_'; // permanent bottom
							}
						}
					}
				}
				else
				{
					if (tetra_vars.new_rot[z] == 0) tetra_vars.new_rot[z] = 3;
					else tetra_vars.new_rot[z]--;
					tetra_vars.joy_delay[z] = 0;
				}
			}
			
			if (tetra_vars.game_over[z] != 0) continue;

			for (volatile unsigned int k=0; k<4; k++)
			{
				for (volatile unsigned int i=0; i<4; i++)
				{
					for (volatile unsigned int j=0; j<4; j++)
					{
						if (tetra_map[(unsigned int)j + (unsigned int)i*4 + (unsigned int)tetra_vars.new_rot[z]*16 + (unsigned int)tetra_vars.piece[z]*64] != ' ')
						{
							if (tetra_vars.new_pos_x[z] + j >= 0x80 || tetra_vars.new_pos_x[z] + j <= 0x03)
							{	
								tetra_vars.new_pos_x[z]++;
								i = 5;
								j = 5;
							}
							else if (tetra_vars.new_pos_x[z] + j >= tetra_size_x + 4)
							{
								tetra_vars.new_pos_x[z]--;
								i = 5;
								j = 5;
							}
						}
					}
				}
			}
			
			test = 0;

			for (volatile unsigned int i=0; i<4; i++)
			{
				for (volatile unsigned int j=0; j<4; j++)
				{
					if (tetra_map[(unsigned int)j + (unsigned int)i*4 + (unsigned int)tetra_vars.new_rot[z]*16 + (unsigned int)tetra_vars.piece[z]*64] == '*')
					{
						if (tetra_board[(tetra_vars.new_pos_x[z] + j - 4) + (tetra_vars.pos_y[z] + i - 4) * tetra_size_x + z * tetra_size_x * tetra_size_y] != ' ')
						{
							test = 1;
							i = 5;
							j = 5;
						}
					}
				}
			}

			if (test == 0)
			{
				tetra_vars.pos_x[z] = tetra_vars.new_pos_x[z];
				tetra_vars.rot[z] = tetra_vars.new_rot[z];
			}

			if (tetra_vars.timer[z] == 0)
			{
				tetra_vars.pos_y[z]++;

				test = 0;

				for (volatile unsigned int i=0; i<4; i++)
				{
					for (volatile unsigned int j=0; j<4; j++)
					{
						if (tetra_map[(unsigned int)j + (unsigned int)i*4 + (unsigned int)tetra_vars.rot[z]*16 + (unsigned int)tetra_vars.piece[z]*64] == '*')
						{
							if (tetra_board[(tetra_vars.pos_x[z] + j - 4) + (tetra_vars.pos_y[z] + i - 4) * tetra_size_x + z * tetra_size_x * tetra_size_y] != ' ')
							{
								test = 1;
								i = 5;
								j = 5;
							}
						}
					}
				}

				if (test == 1)
				{	
					tetra_vars.pos_y[z]--;

					for (volatile unsigned int i=0; i<4; i++)
					{
						for (volatile unsigned int j=0; j<4; j++)
						{
							if (tetra_map[(unsigned int)j + (unsigned int)i*4 + (unsigned int)tetra_vars.rot[z]*16 + (unsigned int)tetra_vars.piece[z]*64] == '*')
							{
								tetra_board[(tetra_vars.pos_x[z] + j - 4) + (tetra_vars.pos_y[z] + i - 4) * tetra_size_x + z * tetra_size_x * tetra_size_y] = '#';
							}
						}
					}
					
					// SOUND HERE

					if (tetra_vars.pos_y[z] == 4)
					{
						tetra_vars.game_over[z] = 1;
						
						// SOUND HERE
					}
					else
					{
						count = 0;

						for (volatile unsigned int i=tetra_size_y-1; i>=1; i--)
						{
							test = 0;

							for (volatile unsigned int j=0; j<tetra_size_x; j++)
							{
								if (tetra_board[j + (i-1) * tetra_size_x + z * tetra_size_x * tetra_size_y] == ' ') test = 1;
							}

							if (test == 0)
							{
								for (volatile unsigned int j=i; j>=2; j--)
								{
									for (volatile unsigned int k=0; k<tetra_size_x; k++)
									{
										tetra_board[k + (j-1) * tetra_size_x + z * tetra_size_x * tetra_size_y] = 
											tetra_board[k + (j-2) * tetra_size_x + z * tetra_size_x * tetra_size_y];
									}
								}

								i++; // test that row again

								tetra_vars.lines[z]++;
								count++;
								
								// SOUND HERE
							}
						}

						if (tetra_vars.game_over[1-z] != 0) count = 0;

						if (count >= 1) count--;

						for (volatile unsigned int i=0; i<count; i++)
						{
							for (volatile unsigned int j=0; j<tetra_size_y-1; j++)
							{
								for (volatile unsigned int k=0; k<tetra_size_x; k++)
								{
									if (j < tetra_size_y-2)
									{
										tetra_board[k + j * tetra_size_x + (1-z) * tetra_size_x * tetra_size_y] = 
											tetra_board[k + (j+1) * tetra_size_x + (1-z) * tetra_size_x * tetra_size_y];
									}
									else
									{
										if (k == tetra_vars.seed % 10) tetra_board[k + j * tetra_size_x + (1-z) * tetra_size_x * tetra_size_y] = ' ';
										else tetra_board[k + j * tetra_size_x + (1-z) * tetra_size_x * tetra_size_y] = '#';
									}
								}
							}
						}
						
						tetra_vars.pos_y[1-z] -= count;
						if (tetra_vars.pos_y[1-z] < 4) tetra_vars.pos_y[1-z] = 4;
					
						tetra_vars.speed[z] = (unsigned int)(tetra_vars.lines[z] / 10);
						if (tetra_vars.speed[z] > 9) tetra_vars.speed[z] = 13; // max

						tetra_vars.pos_x[z] = 7; // start at 4
						tetra_vars.pos_y[z] = 4; // start at 4
						tetra_vars.rot[z] = 0;
						tetra_vars.piece[z] = tetra_vars.new_piece[z];

						tetra_vars.bag_pos[z]++;

						if (tetra_vars.bag_pos[z] == 7)
						{
							tetra_vars.bag_pos[z] = 0;

							for (volatile unsigned int i=0; i<7; i++)
							{
								tetra_vars.bag[(i + ((tetra_vars.seed & 0xF0) >> 4)) % 7 + z * 7] = tetra_random[i + (tetra_vars.seed & 0x1F) * 7];
							}
						}

						tetra_vars.new_piece[z] = tetra_vars.bag[tetra_vars.bag_pos[z] + z * 7];
					}
				}
			}

			for (volatile unsigned int i=0; i<4; i++)
			{
				for (volatile unsigned int j=0; j<4; j++)
				{
					if (tetra_map[(unsigned int)j + (unsigned int)i*4 + (unsigned int)tetra_vars.rot[z]*16 + (unsigned int)tetra_vars.piece[z]*64] == '*')
					{
						tetra_board[(tetra_vars.pos_x[z] + j - 4) + (tetra_vars.pos_y[z] + i - 4) * tetra_size_x + z * tetra_size_x * tetra_size_y] = 
							tetra_map[(unsigned int)j + (unsigned int)i*4 + (unsigned int)tetra_vars.rot[z]*16 + (unsigned int)tetra_vars.piece[z]*64];
					}
				}
			}
		}
		
		unsigned int horz = 0x05;
		unsigned int vert = 0x00;
		
		if (player_one > 0x00)
		{
			for (unsigned int i=0; i<160; i++)
			{
				for (unsigned int j=0; j<40; j++)
				{
					if (i % 2 == 0) buffer[i * 40 + j] = 0xE1E1;
					else buffer[i * 40 + j] = 0x1E1E; // speckled grey
				}
			}

			for (volatile unsigned int i=0; i<tetra_size_y-1; i++)
			{
				for (volatile unsigned int j=0; j<tetra_size_x; j++)
				{
					switch (tetra_board[j + i * tetra_size_x])
					{
						case ' ':
						{
							tetra_solid(j + horz, i + 0x02 + vert, 0x00); // black
							break;
						}
						case '*':
						{
							if (tetra_vars.piece[0] == 0) tetra_block(j + horz, i + 0x02 + vert, 0x6666); // cyan
							else if (tetra_vars.piece[0] == 1) tetra_block(j + horz, i + 0x02 + vert, 0x3333); // blue
							else if (tetra_vars.piece[0] == 2) tetra_block(j + horz, i + 0x02 + vert, 0xEEEE); // grey
							else if (tetra_vars.piece[0] == 3) tetra_block(j + horz, i + 0x02 + vert, 0xCCCC); // yellow
							else if (tetra_vars.piece[0] == 4) tetra_block(j + horz, i + 0x02 + vert, 0x5555); // green
							else if (tetra_vars.piece[0] == 5) tetra_block(j + horz, i + 0x02 + vert, 0xAAAA); // magenta
							else if (tetra_vars.piece[0] == 6) tetra_block(j + horz, i + 0x02 + vert, 0x9999); // red
							break;
						}
						case '#':
						{
							tetra_block(j + horz, i + 0x02 + vert, 0x1111); // dark grey
							break;
						}
					}
				}
			}

			tetra_decimal(horz * 2 + 0x0A, vert * 8, tetra_vars.lines[0]);

			if (tetra_vars.new_piece[0] == 0) tetra_character(horz * 2, vert * 8, 'I');
			else if (tetra_vars.new_piece[0] == 1) tetra_character(horz * 2, vert * 8, 'J');
			else if (tetra_vars.new_piece[0] == 2) tetra_character(horz * 2, vert * 8, 'L');
			else if (tetra_vars.new_piece[0] == 3) tetra_character(horz * 2, vert * 8, 'O');
			else if (tetra_vars.new_piece[0] == 4) tetra_character(horz * 2, vert * 8, 'S');
			else if (tetra_vars.new_piece[0] == 5) tetra_character(horz * 2, vert * 8, 'T');
			else if (tetra_vars.new_piece[0] == 6) tetra_character(horz * 2, vert * 8, 'Z');

			if (tetra_vars.game_over[0] != 0x00)
			{
				tetra_string(horz * 2 + 0x04, 0x40 + vert * 8, "Press\\");
				tetra_string(horz * 2 + 0x04, 0x48 + vert * 8, "Button\\");
			}

			tetra_copy(1);
		}
		
		if (player_two > 0x00)
		{
			for (unsigned int i=0; i<160; i++)
			{
				for (unsigned int j=0; j<40; j++)
				{
					if (i % 2 == 0) buffer[i * 40 + j] = 0xE1E1;
					else buffer[i * 40 + j] = 0x1E1E; // speckled grey
				}
			}
			
			for (volatile unsigned int i=0; i<tetra_size_y-1; i++)
			{
				for (volatile unsigned int j=0; j<tetra_size_x; j++)
				{
					switch (tetra_board[j + i * tetra_size_x + tetra_size_x * tetra_size_y])
					{
						case ' ':
						{
							tetra_solid(j + horz, i + 0x02 + vert, 0x00); // black
							break;
						}
						case '*':
						{
							if (tetra_vars.piece[1] == 0) tetra_block(j + horz, i + 0x02 + vert, 0x6666); // cyan
							else if (tetra_vars.piece[1] == 1) tetra_block(j + horz, i + 0x02 + vert, 0x3333); // blue
							else if (tetra_vars.piece[1] == 2) tetra_block(j + horz, i + 0x02 + vert, 0xEEEE); // grey
							else if (tetra_vars.piece[1] == 3) tetra_block(j + horz, i + 0x02 + vert, 0xCCCC); // yellow
							else if (tetra_vars.piece[1] == 4) tetra_block(j + horz, i + 0x02 + vert, 0x5555); // green
							else if (tetra_vars.piece[1] == 5) tetra_block(j + horz, i + 0x02 + vert, 0xAAAA); // magenta
							else if (tetra_vars.piece[1] == 6) tetra_block(j + horz, i + 0x02 + vert, 0x9999); // red
							break;
						}
						case '#':
						{
							tetra_block(j + horz, i + 0x02 + vert, 0x1111); // dark grey
							break;
						}
					}
				}
			}

			tetra_decimal(horz * 2 + 0x0A, vert * 8, tetra_vars.lines[1]);

			if (tetra_vars.new_piece[1] == 0) tetra_character(horz * 2, vert * 8, 'I');
			else if (tetra_vars.new_piece[1] == 1) tetra_character(horz * 2, vert * 8, 'J');
			else if (tetra_vars.new_piece[1] == 2) tetra_character(horz * 2, vert * 8, 'L');
			else if (tetra_vars.new_piece[1] == 3) tetra_character(horz * 2, vert * 8, 'O');
			else if (tetra_vars.new_piece[1] == 4) tetra_character(horz * 2, vert * 8, 'S');
			else if (tetra_vars.new_piece[1] == 5) tetra_character(horz * 2, vert * 8, 'T');
			else if (tetra_vars.new_piece[1] == 6) tetra_character(horz * 2, vert * 8, 'Z');

			if (tetra_vars.game_over[1] != 0x00)
			{
				tetra_string(horz * 2 + 0x04, 0x40 + vert * 8, "Press\\");
				tetra_string(horz * 2 + 0x04, 0x48 + vert * 8, "Button\\");
			}

			tetra_copy(2);
		}
	//}
};


void tux_draw_clear(unsigned int color)
{
	// start with grey background
	for (unsigned int i=0; i<160; i++)
	{
		for (unsigned int j=0; j<40; j++)
		{
			buffer[i*40+j] = color;
		}
	}
};

void tux_draw_character(unsigned int x, unsigned int y, unsigned int color, unsigned char value)
{
	unsigned int pos = (unsigned int)(value - 32) * 16;
  
	unsigned int mask = 0x0000;
	
	for (unsigned int i=y; i<y+8; i++)
	{		
		mask = buffer[i * 40 + x];
		mask |= (character_bitmap[pos] & color);
		buffer[i * 40 + x] = mask;
		mask = buffer[i * 40 + x + 1];
		mask |= (character_bitmap[pos + 1] & color);
		buffer[i * 40 + x + 1] = mask;
		
		pos += 2;
	}
};

void tux_draw_character_inverse(unsigned int x, unsigned int y, unsigned int color, unsigned char value)
{
	unsigned int pos = (unsigned int)(value - 32) * 16;
  
	unsigned int mask = 0x0000;
	
	for (unsigned int i=y; i<y+8; i++)
	{		
		mask = buffer[i * 40 + x];
		mask &= ((character_bitmap[pos] & color) ^ 0xFFFF);
		buffer[i * 40 + x] = mask;
		mask = buffer[i * 40 + x + 1];
		mask &= ((character_bitmap[pos + 1] & color) ^ 0xFFFF);
		buffer[i * 40 + x + 1] = mask;
		
		pos += 2;
	}
};

// for debugging purposes
void tux_draw_hex(unsigned char x, unsigned char y, unsigned int color, unsigned char value)
{
	volatile unsigned char temp = (unsigned char)((value & 0xF0) >> 4);
		
	if (temp < 0x0A) tux_draw_character(x, y, color, (unsigned char)(temp + '0'));
	else tux_draw_character(x, y, color, (unsigned char)(temp - 0x0A + 'A'));
		
	temp = (unsigned char)(value & 0x0F);
		
	if (temp < 0x0A) tux_draw_character(x + 0x02, y, color, (unsigned char)(temp + '0'));
	else tux_draw_character(x + 0x02, y, color, (unsigned char)(temp - 0x0A + 'A'));
};

void tux_draw_decimal(unsigned char x, unsigned char y, unsigned int color, unsigned int value)
{
	unsigned int temp = 0;
	unsigned int next = 0;
	
	unsigned int zero = 0;
	
	next = value;
	
	temp = next / 10000;
	if (temp != 0) zero = 1;
	if (zero != 0) tux_draw_character(x, y, color, (unsigned char)(temp + '0'));
	next = next - 10000 * temp;
	
	temp = next / 1000;
	if (temp != 0) zero = 1;
	if (zero != 0) tux_draw_character(x + 0x02, y, color, (unsigned char)(temp + '0'));
	next = next - 1000 * temp;
	
	temp = next / 100;
	if (temp != 0) zero = 1;
	if (zero != 0) tux_draw_character(x + 0x04, y, color, (unsigned char)(temp + '0'));
	next = next - 100 * temp;
	
	temp = next / 10;
	if (temp != 0) zero = 1;
	if (zero != 0) tux_draw_character(x + 0x06, y, color, (unsigned char)(temp + '0'));
	next = next - 10 * temp;
	
	temp = next;
	tux_draw_character(x + 0x08, y, color, (unsigned char)(temp + '0'));
};

void tux_draw_battle_back(unsigned int first_color, unsigned int second_color, 
	unsigned int third_color, unsigned int fourth_color, unsigned int fifth_color)
{
	for (unsigned int i=0; i<160; i++)
	{
		for (unsigned int j=0; j<40; j++)
		{
			if (i < 48)
			{
				if ((i + j) % 2 == 0) buffer[i*40+j] = first_color;
				else buffer[i*40+j] = second_color;
			}
			else
			{
				if ((i + j) % 2 == 0) buffer[i*40+j] = third_color;
				else buffer[i*40+j] = fourth_color;
			}
		}
	}
	
    for (unsigned int i=0; i<8; i++)
	{
		for (unsigned int j=0; j<40; j++)
		{
			buffer[(i+152)*40+(j+0)] = fifth_color;
		}
	}
};

unsigned int tux_tetra_loc_x = 2;
unsigned int tux_tetra_loc_y = 3;
unsigned int tux_tetra_loc_map = 1;

void tux_draw_map(__eds__ unsigned char *map_pointer, const __prog__ unsigned int *tile_pointer, 
	unsigned int type, unsigned int map, unsigned int distx, unsigned int disty, int posx, int posy)
{ 
	int x1 = posx/4 + 0;
	int y1 = posy/4 + 0;
	int x2 = posx/4 + 11;
	int y2 = posy/4 + 11;
	
	if (x1 < 0) x1 = 0;
	if (x2 > distx) x2 = distx;
	if (y1 < 0) y1 = 0;
	if (y2 > disty) y2 = disty;
	
	// then draw tiles on bottom
	for (int x=x1; x<x2; x++)
	{
		for (int y=y1; y<y2; y++)
		{	
			for (unsigned int i=0; i<16; i++)
			{
				for (unsigned int j=0; j<4; j++)
				{
					if ((i + y * 16 - (posy)*4) >= 0 &&
						(i + y * 16 - (posy)*4) < 160 &&
						(j + x * 4 - (posx)) >= 0 &&
						(j + x * 4 - (posx)) < 40)
					{
						if (type == 0)
						{
						}
						else if (type == 1)
						{
							if (map == tux_tetra_loc_map && x == tux_tetra_loc_x && y == tux_tetra_loc_y)
							{
								buffer[(i + y * 16 - (posy)*4) * 40 + (j + x * 4 - (posx))] = 
									tetra_icon[i * 4 + j];
							}
							else
							{
								buffer[(i + y * 16 - (posy)*4) * 40 + (j + x * 4 - (posx))] = 
									tile_pointer[(unsigned int)(((map_pointer[y*distx+x]&0x3F)/4) * 16 + i) * 16 + 
										(((map_pointer[y*distx+x]&0x7F)%4) * 4 + j)];
							}
						}
					}
				}
			}
		}
	}
};

void tux_draw_sprite(__eds__ unsigned int *pointer, unsigned int frame, unsigned int dir, int posx, int posy)
{
	if (pointer == 0) return;
	
	unsigned int mask = 0;
	unsigned int sprite = 0;
	unsigned int back = 0;
	unsigned int fore = 0;
  
	// then draw sprites on top
	for (int i=0; i<24; i++)
	{
		for (int j=0; j<4; j++)
		{
			mask = 0x0000;

			if (frame == 0) sprite = 0;
			else if (frame == 1) sprite = 1;
			else if (frame == 2) sprite = 0;
			else if (frame == 3) sprite = 2;

			// this assembly code allows me to read from the lower screen data!!!
			//asm("push DSRPAG");
			//asm("push DSWPAG");

			//asm("movpag #0x001, DSRPAG");
			//asm("movpag #0x001, DSWPAG"); 
			
			if ((i + (posy*4)) >= 0 &&
				(i + (posy*4)) < 160 &&
				(j + (posx)) >= 0 &&
				(j + (posx)) < 40)
			{
				back = buffer[(i + (posy*4)) * 40 + (j + (posx))];

				//asm("pop DSWPAG");
				//asm("pop DSRPAG");

				fore = pointer[(i + (sprite * 24)) * 16 + (j + (dir * 4))];

				if ((fore & 0xF000) == 0x0000)
				{
					mask |= 0xF000;
				}
				if ((fore & 0x0F00) == 0x0000)
				{
					mask |= 0x0F00;
				}
				if ((fore & 0x00F0) == 0x0000)
				{
					mask |= 0x00F0;
				}
				if ((fore & 0x000F) == 0x0000)
				{
					mask |= 0x000F;
				}

				mask &= back;

				mask |= fore;

				buffer[(i + (posy*4)) * 40 + (j + (posx))] = mask;
			}
		}
	}
};

void tux_draw_trainer(__eds__ unsigned int *pointer, int posx, int posy)
{
	if (pointer == 0) return;
	
	unsigned int mask = 0;
	unsigned int back = 0;
	unsigned int fore = 0;
  
	// then draw sprites on top
	for (int i=0; i<64; i++)
	{
		for (int j=0; j<16; j++)
		{
			mask = 0x0000;

			// this assembly code allows me to read from the lower screen data!!!
			//asm("push DSRPAG");
			//asm("push DSWPAG");

			//asm("movpag #0x001, DSRPAG");
			//asm("movpag #0x001, DSWPAG"); 
			
			if ((i + (posy*4)) >= 0 &&
				(i + (posy*4)) < 160 &&
				(j + (posx)) >= 0 &&
				(j + (posx)) < 40)
			{
				back = buffer[(i + (posy*4)) * 40 + (j + (posx))];

				//asm("pop DSWPAG");
				//asm("pop DSRPAG");

				fore = pointer[(i + 72) * 16 + (j)];

				if ((fore & 0xF000) == 0x0000)
				{
					mask |= 0xF000;
				}
				if ((fore & 0x0F00) == 0x0000)
				{
					mask |= 0x0F00;
				}
				if ((fore & 0x00F0) == 0x0000)
				{
					mask |= 0x00F0;
				}
				if ((fore & 0x000F) == 0x0000)
				{
					mask |= 0x000F;
				}

				mask &= back;

				mask |= fore;

				buffer[(i + (posy*4)) * 40 + (j + (posx))] = mask;
			}
		}
	}
};

void tux_draw_player(__eds__ unsigned int *pointer, int posx, int posy)
{
	if (pointer == 0) return;
	
	unsigned int mask = 0;
	unsigned int back = 0;
	unsigned int fore = 0;
  
	// then draw sprites on top
	for (int i=0; i<120; i++)
	{
		for (int j=0; j<16; j++)
		{
			mask = 0x0000;

			// this assembly code allows me to read from the lower screen data!!!
			//asm("push DSRPAG");
			//asm("push DSWPAG");

			//asm("movpag #0x001, DSRPAG");
			//asm("movpag #0x001, DSWPAG"); 
			
			if ((i + (posy*4)) >= 0 &&
				(i + (posy*4)) < 160 &&
				(j + (posx)) >= 0 &&
				(j + (posx)) < 40)
			{
				back = buffer[(i + (posy*4)) * 40 + (j + (posx))];

				//asm("pop DSWPAG");
				//asm("pop DSRPAG");

				fore = pointer[(i + 138) * 16 + (j)];

				if ((fore & 0xF000) == 0x0000)
				{
					mask |= 0xF000;
				}
				if ((fore & 0x0F00) == 0x0000)
				{
					mask |= 0x0F00;
				}
				if ((fore & 0x00F0) == 0x0000)
				{
					mask |= 0x00F0;
				}
				if ((fore & 0x000F) == 0x0000)
				{
					mask |= 0x000F;
				}

				mask &= back;

				mask |= fore;

				buffer[(i + (posy*4)) * 40 + (j + (posx))] = mask;
			}
		}
	}
};

void tux_draw_mon(__eds__ unsigned int *pointer, unsigned int dir, int posx, int posy)
{
	if (pointer == 0) return;
	
	unsigned int mask = 0;
	unsigned int back = 0;
	unsigned int fore = 0;
  
	// then draw sprites on top
	for (int i=0; i<64; i++)
	{
		for (int j=0; j<16; j++)
		{
			mask = 0x0000;

			// this assembly code allows me to read from the lower screen data!!!
			//asm("push DSRPAG");
			//asm("push DSWPAG");

			//asm("movpag #0x001, DSRPAG");
			//asm("movpag #0x001, DSWPAG"); 
			
			if ((i + (posy*4)) >= 0 &&
				(i + (posy*4)) < 160 &&
				(j + (posx)) >= 0 &&
				(j + (posx)) < 40)
			{
				back = buffer[(i + (posy*4)) * 40 + (j + (posx))];

				//asm("pop DSWPAG");
				//asm("pop DSRPAG");

				fore = pointer[(i + (dir*64)) * 16 + (j)];

				if ((fore & 0xF000) == 0x0000)
				{
					mask |= 0xF000;
				}
				if ((fore & 0x0F00) == 0x0000)
				{
					mask |= 0x0F00;
				}
				if ((fore & 0x00F0) == 0x0000)
				{
					mask |= 0x00F0;
				}
				if ((fore & 0x000F) == 0x0000)
				{
					mask |= 0x000F;
				}

				mask &= back;

				mask |= fore;

				buffer[(i + (posy*4)) * 40 + (j + (posx))] = mask;
			}
		}
	}
};

void tux_draw_battle_anim(__eds__ unsigned int *mon_a, __eds__ unsigned int *mon_b, __eds__ unsigned int *trainer, 
					 int *anim_a, int *timer_a, int *anim_b, int *timer_b, char *shout_text, int speed)
{
    tux_draw_battle_back(0x3E3E, 0xE3E3, 0x4545, 0x5454, 0x1111);
	
	tux_draw_trainer(trainer, 24, 0);
	
	if (!(*anim_b == 0 || (*anim_b == 1 && *timer_b < 200)))
	{
		for (unsigned int i=7; i<16; i++)
		{
			for (unsigned int j=1; j<19; j++)
			{
				if (!((i == 7 && j == 1) ||
					(i == 7 && j == 18) ||
					(i == 15 && j == 1) ||
					(i == 15 && j == 18)))
				{
					buffer[i*40+j] = 0xFFFF;
				}
			}
		}
		
		buffer[9*40+19] = 0xFFFF;
		buffer[10*40+19] = 0xFFFF;
		buffer[11*40+19] = 0xFFFF;
		buffer[10*40+20] = 0xFFFF;
		
		for (unsigned int i=0; i<8; i++)
		{
			tux_draw_character_inverse(i*2+2, 8, 0xEEEE, shout_text[i]);
		}
	}
	
	if (*anim_b == 0)
	{
		tux_draw_mon(mon_b, 0, 20, 8);
	}
	else if (*anim_b == 1) // intro
	{
		if (*timer_b >= 400) tux_draw_mon(mon_b, 0, 40 - (signed int)(((*timer_b/10) - 40)), 8);
		
		*timer_b = *timer_b + speed;
		
		if (*timer_b >= 600)
		{
			*anim_b = 0;
			*timer_b = 0;
		}
	}
	else if (*anim_b == 2) // switch
	{
		if (*timer_b < 200) tux_draw_mon(mon_b, 0, 20 + (signed int)((*timer_b/10)), 8);
		else tux_draw_mon(mon_b, 0, 40 - (signed int)((*timer_b/10) - 20), 8);
		
		*timer_b = *timer_b + speed;
		
		if (*timer_b >= 400)
		{
			*anim_b = 0;
			*timer_b = 0;
		}
	}
	else if (*anim_b == 3) // faint
	{	
		if (*timer_b < 200) tux_draw_mon(mon_b, 0, 20 + (signed int)((*timer_b/10)), 8);
		
		*timer_b = *timer_b + speed;
		
		if (*timer_b >= 400)
		{
			*anim_b = 0;
			*timer_b = 0;
		}
	}
	else if (*anim_b == 4) // tackle
	{	
		if (*timer_b < 200) tux_draw_mon(mon_b, 0, 20 - (signed int)((*timer_b/10)/4), 8);
		else tux_draw_mon(mon_b, 0, 20 - (signed int)((40 - (*timer_b/10))/4), 8);
		
		*timer_b = *timer_b + (speed * 2);
		
		if (*timer_b >= 400)
		{
			*anim_b = 0;
			*timer_b = 0;
		}
	}
	else if (*anim_b == 5) // shake
	{	
		if (*timer_b < 100) tux_draw_mon(mon_b, 0, 20 - (signed int)((*timer_b/10)/4), 8);
		else if (*timer_b < 200) tux_draw_mon(mon_b, 0, 20 - (signed int)((20 - (*timer_b/10))/4), 8);
		else if (*timer_b < 300) tux_draw_mon(mon_b, 0, 20 - (signed int)(((*timer_b/10) - 20)/4), 8);
		else tux_draw_mon(mon_b, 0, 20 - (signed int)((40 - (*timer_b/10))/4), 8);
		
		*timer_b = *timer_b + (speed * 2);
		
		if (*timer_b >= 400)
		{
			*anim_b = 0;
			*timer_b = 0;
		}
	}
	else if (*anim_b == 6) // slam
	{	
		if (*timer_b < 200) tux_draw_mon(mon_b, 0, 20 + (signed int)((*timer_b/10)/4), 8);
		else if (*timer_b < 300) tux_draw_mon(mon_b, 0, 25 - (signed int)(((*timer_b/10) - 20)/1), 8);
		else tux_draw_mon(mon_b, 0, 20 - (signed int)((40 - (*timer_b/10))/2), 8);
		
		*timer_b = *timer_b + (speed * 2);
		
		if (*timer_b >= 400)
		{
			*anim_b = 0;
			*timer_b = 0;
		}
	}
	else if (*anim_b == 7) // hop
	{	
		if (*timer_b < 200) tux_draw_mon(mon_b, 0, 20, 8 + (signed int)((*timer_b/10)/4));
		else tux_draw_mon(mon_b, 0, 20, 8 + (signed int)((40 - (*timer_b/10))/4));
		
		*timer_b = *timer_b + (speed * 2);
		
		if (*timer_b >= 400)
		{
			*anim_b = 0;
			*timer_b = 0;
		}
	}
	else if (*anim_b == 8) // catch
	{
		tux_draw_mon(mon_b, 0, 20, 8);
		
		timer_b = *timer_b + (speed * 2);
		
		if (*timer_b >= 400)
		{
			*anim_b = 0;
			*timer_b = 0;
		}
	}
	else if (*anim_b == 9) // still
	{
		tux_draw_mon(mon_b, 0, 20, 8);
		
		timer_b = *timer_b + (speed * 2);
		
		if (*timer_b >= 400)
		{
			*anim_b = 0;
			*timer_b = 0;
		}
	}
	
	if (*anim_a == 0)
	{
		tux_draw_mon(mon_a, 1, 0, 22);
	}
	else if (*anim_a == 1) // intro
	{
		if (*timer_a >= 400) tux_draw_mon(mon_a, 1, (signed int)((*timer_a/10)) - 60, 22);
		
		*timer_a = *timer_a + speed;
		
		if (*timer_a >= 600)
		{
			*anim_a = 0;
			*timer_a = 0;
		}
	}
	else if (*anim_a == 2) // switch
	{
		if (*timer_a < 200) tux_draw_mon(mon_a, 1, 0 - (signed int)((*timer_a/10)), 22);
		else tux_draw_mon(mon_a, 1, (signed int)((*timer_a/10)) - 40, 22);
		
		*timer_a = *timer_a + speed;
		
		if (*timer_a >= 400)
		{
			*anim_a = 0;
			*timer_a = 0;
		}
	}
	else if (*anim_a == 3) // faint
	{
		if (*timer_a < 200) tux_draw_mon(mon_a, 1, 0 - (signed int)((*timer_a/10)), 22);
		
		*timer_a = *timer_a + speed;
		
		if (*timer_a >= 400)
		{
			*anim_a = 0;
			*timer_a = 0;
		}
	}
	else if (*anim_a == 4) // tackle
	{
		if (*timer_a < 200) tux_draw_mon(mon_a, 1, (signed int)((*timer_a/10)/4), 22);
		else tux_draw_mon(mon_a, 1, (signed int)((40 - (*timer_a/10))/4), 22);
		
		*timer_a = *timer_a + (speed * 2);
		
		if (*timer_a >= 400)
		{
			*anim_a = 0;
			*timer_a = 0;
		}
	}
	else if (*anim_a == 5) // shake
	{
		if (*timer_a < 100) tux_draw_mon(mon_a, 1, (signed int)((*timer_a/10)/4), 22);
		else if (*timer_a < 200) tux_draw_mon(mon_a, 1, (signed int)((20 - (*timer_a/10))/4), 22);
		else if (*timer_a < 300) tux_draw_mon(mon_a, 1, (signed int)(((*timer_a/10) - 20)/4), 22);
		else tux_draw_mon(mon_a, 1, (signed int)((40 - (*timer_a/10))/4), 22);
		
		*timer_a = *timer_a + (speed * 2);
		
		if (*timer_a >= 400)
		{
			*anim_a = 0;
			*timer_a = 0;
		}
	}
	else if (*anim_a == 6) // slam
	{
		if (*timer_a < 200) tux_draw_mon(mon_a, 1, -(signed int)((*timer_a/10)/4), 22);
		else if (*timer_a < 300) tux_draw_mon(mon_a, 1, -5 + (signed int)(((*timer_a/10) - 20)/1), 22);
		else tux_draw_mon(mon_a, 1, (signed int)((40 - (*timer_a/10))/2), 22);
		
		*timer_a = *timer_a + (speed * 2);
		
		if (*timer_a >= 400)
		{
			*anim_a = 0;
			*timer_a = 0;
		}
	}
	else if (*anim_a == 7) // hop
	{
		if (*timer_a < 200) tux_draw_mon(mon_a, 1, 0, 22 + (signed int)((*timer_a/10)/4));
		else tux_draw_mon(mon_a, 1, 0, 22 + (signed int)((40 - (*timer_a/10))/4));
		
		*timer_a = *timer_a + (speed * 2);
		
		if (*timer_a >= 400)
		{
			*anim_a = 0;
			*timer_a = 0;
		}
	}
	else if (*anim_a == 8) // catch
	{
		tux_draw_mon(mon_a, 1, 0, 22);
		
		*timer_a = *timer_a + (speed * 2);
		
		if (*timer_a >= 400)
		{
			*anim_a = 0;
			*timer_a = 0;
		}
	}
	else if (*anim_a == 9) // still
	{
		tux_draw_mon(mon_a, 1, 0, 22);
		
		*timer_a = *timer_a + (speed * 2);
		
		if (*timer_a >= 400)
		{
			*anim_a = 0;
			*timer_a = 0;
		}
	}
	
	for (unsigned int i=0; i<8; i++)
	{
		for (unsigned int j=0; j<40; j++)
		{
			buffer[(i+152)*40+(j+0)] = 0x1111;
		}
	}
};

// must be drawn before tux_draw_battle_menu()
void tux_draw_battle_health(unsigned int back_color, unsigned int good_color, unsigned int bad_color, int ally_health, int enemy_health)
{
	int ally = ally_health;
	int enemy = enemy_health;
	
	if (ally < 0) ally = 0;
	if (enemy < 0) enemy = 0;
	
	for (unsigned int i=0; i<64; i++)
	{
		for (unsigned int j=0; j<18; j++)
		{
			buffer[(i+96)*40+(j+22)] = back_color;
		}
	}
	
	for (unsigned int i=2; i<6; i++)
	{
		for (unsigned int j=0; j<18; j++)
		{
			if (j < (signed int)((enemy * 18) / 100)) buffer[(i+96)*40+(j+22)] = good_color;
			else buffer[(i+96)*40+(j+22)] = bad_color;
		}
	}
	
	// start with grey background
    for (unsigned int i=0; i<8; i++)
	{
		for (unsigned int j=0; j<22; j++)
		{
			buffer[(i+152)*40+(j+0)] = back_color;
		}
	}
	
	for (unsigned int i=2; i<6; i++)
	{
		for (unsigned int j=0; j<22; j++)
		{
			if (j < (signed int)((ally * 22) / 100)) buffer[(i+152)*40+(j+0)] = good_color;
			else buffer[(i+152)*40+(j+0)] = bad_color;
		}
	}
};

// options text always has 8 characters for each selection
// must be drawn immediately after tux_draw_battle_health()
void tux_draw_battle_menu(unsigned int select, char move_a[8], char move_b[8], char move_c[8], char move_d[8],
	char *option_text)
{ 	
	unsigned int pos = 0;
	
	tux_draw_character(22, 104 + 8*select, 0xFFFF, '>');
	
	pos = 0;
	for (unsigned int i=0; i<8; i++)
	{
		tux_draw_character(24+2*i, 104, 0xFFFF, move_a[pos]);
		pos++;
	}
	
	pos = 0;
	for (unsigned int i=0; i<8; i++)
	{
		tux_draw_character(24+2*i, 112, 0xFFFF, move_b[pos]);
		pos++;
	}
	
	pos = 0;
	for (unsigned int i=0; i<8; i++)
	{
		tux_draw_character(24+2*i, 120, 0xFFFF, move_c[pos]);
		pos++;
	}
	
	pos = 0;
	for (unsigned int i=0; i<8; i++)
	{
		tux_draw_character(24+2*i, 128, 0xFFFF, move_d[pos]);
		pos++;
	}
	
	tux_draw_character(24, 136, 0xFFFF, 'S');
	tux_draw_character(26, 136, 0xFFFF, 'W');
	tux_draw_character(28, 136, 0xFFFF, 'I');
	tux_draw_character(30, 136, 0xFFFF, 'T');
	tux_draw_character(32, 136, 0xFFFF, 'C');
	tux_draw_character(34, 136, 0xFFFF, 'H');
	
	for (unsigned int i=0; i<8; i++)
	{
		tux_draw_character(24+2*i, 144, 0xFFFF, option_text[i]);
	}
	
	tux_draw_character(24, 152, 0xFFFF, 'R');
	tux_draw_character(26, 152, 0xFFFF, 'U');
	tux_draw_character(28, 152, 0xFFFF, 'N');
};

void tux_draw_copy(unsigned int side)
{
	// this assembly code allows me to read from the lower screen data!!!
  
	//asm("push DSRPAG");
	//asm("push DSWPAG");

	//asm("movpag #0x001, DSRPAG");
	//asm("movpag #0x001, DSWPAG"); 

	if (side == 0)
	{
	}
	else if (side == 1)
	{
		// then transfer buffer to screen
		for (unsigned int i=0; i<160; i++)
		{
			for (unsigned int j=0; j<40; j++)
			{
				screen[i*80+j] = buffer[i*40+j];
			}
		}
	}
	else if (side == 2)
	{
		// then transfer buffer to screen
		for (unsigned int i=0; i<160; i++)
		{
			for (unsigned int j=0; j<40; j++)
			{
				screen[i*80+j+40] = buffer[i*40+j];
			}
		}
	}

	//asm("pop DSWPAG");
	//asm("pop DSRPAG");
};
		
unsigned int tux_buttons(unsigned int player)
{
	unsigned int buttons = 0x0000;
		
//	if (player == 1)
//	{
//		if (PORTAbits.RA0 == 0) { buttons |= 0x0001; }
//		if (PORTAbits.RA1 == 0) { buttons |= 0x0002; }
//		if (PORTBbits.RB0 == 0) { buttons |= 0x0004; }
//		if (PORTBbits.RB1 == 0) { buttons |= 0x0008; }
//	}
//	else if (player == 2)
//	{
//		if (PORTAbits.RA4 == 0) { buttons |= 0x0001; }
//		if (PORTCbits.RC1 == 0) { buttons |= 0x0002; }
//		if (PORTBbits.RB4 == 0) { buttons |= 0x0004; }
//		if (PORTCbits.RC0 == 0) { buttons |= 0x0008; }
//	}
	
	if (player == 1)
	{
		if (PORTAbits.RA0 == 0) { buttons |= 0x0001; }
		if (PORTAbits.RA1 == 0) { buttons |= 0x0002; }
		if (PORTBbits.RB0 == 0) { buttons |= 0x0004; }
		if (PORTBbits.RB1 == 0) { buttons |= 0x0008; }
		
		if (PORTCbits.RC0 == 0 || PORTBbits.RB4 == 0) { buttons |= 0x0010; }
		if (PORTCbits.RC1 == 0 || PORTAbits.RA4 == 0) { buttons |= 0x0020; }
	}
	else if (player == 2)
	{
		if (PORTCbits.RC7 == 0) { buttons |= 0x0001; }
		if (PORTCbits.RC6 == 0) { buttons |= 0x0002; }
		if (PORTCbits.RC5 == 0) { buttons |= 0x0004; }
		if (PORTCbits.RC4 == 0) { buttons |= 0x0008; }
		
		if (PORTBbits.RB5 == 0) { buttons |= 0x0010; }
		if (PORTBbits.RB6 == 0) { buttons |= 0x0020; }
	}
	
	return buttons;
};

struct tux_struct_move
{
	char name[8];
	int animation;
	int type;
	int attack;
	int critical;
	int haste;
	int accuracy;
};

struct tux_struct_mon
{
	__eds__ unsigned int *pointer;
	char name[8];
	int type;
	int strength;
	int defense;
	int speed;
	int agility;
	int max_health;
	int move[4];
};

struct tux_struct_trainer
{
	__eds__ unsigned int *pointer;
	char text[64];
	int map;
	int frame;
	int direction;
	int posx;
	int posy;
	int homex;
	int homey;
	int random;
	int layer;
	int quest[4];
	int ai_counter;
	int ai_direction;
	int ai_distance;
	int animation;
	int timer;
	int order;
	int damage;
	int quickness;
	int mon[6];
	int experience[6];
	int level[6];
	int health[6];
};

struct tux_struct_connection
{
	int source_map;
	int source_x1;
	int source_y1;
	int source_x2;
	int source_y2;
	int destination_map;
	int destination_x; // +4*PLAYER
	int destination_y;
};

__eds__ unsigned int *tux_mon_pointer(unsigned int value)
{
	switch (value)
	{
		case 0: return 0;
		case 1: return (__eds__ unsigned int *)aardart;
		case 2: return (__eds__ unsigned int *)anu;
		case 3: return (__eds__ unsigned int *)bamboon;
		case 4: return (__eds__ unsigned int *)budaye;
		case 5: return (__eds__ unsigned int *)cardinale;
		case 6: return (__eds__ unsigned int *)crankus;
		case 7: return (__eds__ unsigned int *)eruptibus;
		case 8: return (__eds__ unsigned int *)eaglace; 
		case 9: return (__eds__ unsigned int *)exclawvate;
		case 10: return (__eds__ unsigned int *)ferricran;
		case 11: return (__eds__ unsigned int *)heronquak;
		case 12: return (__eds__ unsigned int *)lucifice; 
		case 13: return (__eds__ unsigned int *)medushock;
		case 14: return (__eds__ unsigned int *)qetzlrokilus;
		case 15: return (__eds__ unsigned int *)sharpfin;
		case 16: return (__eds__ unsigned int *)tux; 
		default: return 0;
	}
	
	return 0;
};

__eds__ unsigned int *tux_trainer_pointer(unsigned int value)
{
	switch (value)
	{
		case 0: return 0;
		case 1: return (__eds__ unsigned int *)adventurer;
		case 2: return (__eds__ unsigned int *)heroine;
		case 3: return (__eds__ unsigned int *)cooldude;
		case 4: return (__eds__ unsigned int *)fashionista;
		case 5: return (__eds__ unsigned int *)florist;
		case 6: return (__eds__ unsigned int *)goth;
		case 7: return (__eds__ unsigned int *)miner;
		case 8: return (__eds__ unsigned int *)professor;
		default: return 0;
	}
	
	return 0;
};

const unsigned int tux_trainer_total = 10;

struct tux_struct_trainer tux_trainer[10];

const unsigned int tux_mon_total = 17;

struct tux_struct_mon tux_mon[17];

const unsigned int tux_move_total = 14;

struct tux_struct_move tux_move[14];

const unsigned int tux_connection_total = 6;

struct tux_struct_connection tux_connection[6];

const unsigned int tux_map_total = 4;

__eds__ unsigned char *tux_map_pointer[4];
unsigned int tux_map_width[4];
unsigned int tux_map_length[4];


int tux_random(unsigned int trainer)
{
	int rand_val = (signed int)random_value[tux_trainer[trainer].random];
	
	tux_trainer[trainer].random++;
	
	if (tux_trainer[trainer].random > 255)
	{
		tux_trainer[trainer].random = 0;
	}
	
	return rand_val;
};


void TuxemonDemo()
{	
	tux_map_pointer[0] = (__eds__ unsigned char *)map_town;
	tux_map_width[0] = (unsigned int)map_size[0][0];
	tux_map_length[0] = (unsigned int)map_size[0][1];
	tux_map_pointer[1] = (__eds__ unsigned char *)map_center;
	tux_map_width[1] = (unsigned int)map_size[1][0];
	tux_map_length[1] = (unsigned int)map_size[1][1];
	tux_map_pointer[2] = (__eds__ unsigned char *)map_cave;
	tux_map_width[2] = (unsigned int)map_size[2][0];
	tux_map_length[2] = (unsigned int)map_size[2][1];
	tux_map_pointer[3] = (__eds__ unsigned char *)map_house;
	tux_map_width[3] = (unsigned int)map_size[3][0];
	tux_map_length[3] = (unsigned int)map_size[3][1];
	
	for (unsigned int i=0; i<tux_connection_total; i++)
	{
		tux_connection[i].source_map = map_connection[i][0];
		tux_connection[i].source_x1 = map_connection[i][1];
		tux_connection[i].source_y1 = map_connection[i][2];
		tux_connection[i].source_x2 = map_connection[i][3];
		tux_connection[i].source_y2 = map_connection[i][4];
		tux_connection[i].destination_map = map_connection[i][5];
		tux_connection[i].destination_x = map_connection[i][6]; // +4*PLAYER
		tux_connection[i].destination_y = map_connection[i][7];
	}
	
	for (unsigned int i=0; i<tux_trainer_total; i++)
	{
		for (unsigned int j=0; j<64; j++) tux_trainer[i].text[j] = trainer_text[i][j];
		
		tux_trainer[i].pointer = (__eds__ unsigned int *)tux_trainer_pointer(trainer_stats[i][0]);
		 
		tux_trainer[i].map = trainer_stats[i][1];
		tux_trainer[i].frame = trainer_stats[i][2];
		tux_trainer[i].direction = trainer_stats[i][3];
		tux_trainer[i].posx = trainer_stats[i][4];
		tux_trainer[i].posy = trainer_stats[i][5];
		tux_trainer[i].homex = trainer_stats[i][6];
		tux_trainer[i].homey = trainer_stats[i][7];
		tux_trainer[i].layer = 0;
		
		tux_trainer[i].quest[0] = 0;
		tux_trainer[i].quest[1] = 0;
		tux_trainer[i].quest[2] = 0;
		tux_trainer[i].quest[3] = 0;
		
		tux_trainer[i].ai_counter = 0;
		tux_trainer[i].ai_direction = 0;
		tux_trainer[i].ai_distance = 0;
		
		tux_trainer[i].mon[0] = trainer_stats[i][8];
		tux_trainer[i].level[0] = trainer_stats[i][9];
		tux_trainer[i].experience[0] = 0;
		tux_trainer[i].health[0] = 0;
		tux_trainer[i].mon[1] = trainer_stats[i][10];
		tux_trainer[i].level[1] = trainer_stats[i][11];
		tux_trainer[i].experience[1] = 0;
		tux_trainer[i].health[1] = 0;
		
		tux_trainer[i].random = (unsigned char)i;
		
		for (unsigned int j=2; j<6; j++)
		{
			tux_trainer[i].mon[j] = 0;
			tux_trainer[i].level[j] = 0;
			tux_trainer[i].experience[j] = 0;
			tux_trainer[i].health[j] = 0;
		}
	}
	
	for (unsigned int i=0; i<tux_mon_total; i++)
	{
		for (unsigned int j=0; j<8; j++) tux_mon[i].name[j] = mon_name[i][j];
		
		tux_mon[i].pointer = (__eds__ unsigned int *)tux_mon_pointer(i);
		
		tux_mon[i].type = mon_stats[i][0];
		tux_mon[i].strength = mon_stats[i][1];
		tux_mon[i].defense = mon_stats[i][2];
		tux_mon[i].speed = mon_stats[i][3];
		tux_mon[i].agility = mon_stats[i][4];
		tux_mon[i].max_health = mon_stats[i][5];
		tux_mon[i].move[0] = mon_stats[i][6];
		tux_mon[i].move[1] = mon_stats[i][7];
		tux_mon[i].move[2] = mon_stats[i][8];
		tux_mon[i].move[3] = mon_stats[i][9];
	}
	
	for (unsigned int i=0; i<tux_move_total; i++)
	{
		for (unsigned int j=0; j<8; j++) tux_move[i].name[j] = move_name[i][j];
		
		tux_move[i].animation = move_stats[i][0];
		tux_move[i].type = move_stats[i][1];
		tux_move[i].attack = move_stats[i][2];
		tux_move[i].critical = move_stats[i][3];
		tux_move[i].haste = move_stats[i][4];
		tux_move[i].accuracy = move_stats[i][5];
	}
	
	
	
	unsigned int touch[2] = { 0, 0 };
	unsigned int buttons[2] = { 0, 0 };
	unsigned int select[2] = { 0, 0 };
	unsigned int held[2] = { 0, 0 };
	unsigned int counter[2] = { 0, 0 };
	unsigned int confirm[2] = { 0, 0 };
	unsigned int game[2] = { 0, 0 };
	unsigned int battle[2] = { 0, 0 };
	unsigned int wait[2] = { 0, 0 };
	unsigned int active[2] = { 1, 1 };
	unsigned int menu[2] = { 0, 0 };
	unsigned int leave[2] = { 0, 0 };
	unsigned int swap[4] = { 0, 0, 0, 0 };
	int temp_anim[2] = { 0, 0 };
	int temp_timer[2] = { 0, 0 };
	
	char *shout_text[2] = { "        ", "        " };
	
	const unsigned int cenx = 18;
	const unsigned int ceny = 16;
	
	const unsigned int player_speed = 250;
	const unsigned int sprite_speed = 1000;
	const unsigned int draw_speed = 250;
	const unsigned int battle_speed = 25;
	const unsigned int encounter_speed = 4;
	const unsigned int level_speed = 24;
	
	unsigned int prex = 0;
	unsigned int prey = 0;
	unsigned int miny = 0;
	unsigned int minv = 0;
	
	unsigned int rand_val = 0;
	unsigned int temp_val = 0;
	
	unsigned int drawing = 0;
	unsigned int leveling[2] = { 0, 0 };
	
	TetraInit();
	
	while (1)
	{
		if (touch[0] == 2) touch[0] = 1;
		if (touch[1] == 2) touch[1] = 1;
		
		buttons[0] = tux_buttons(1);
		buttons[1] = tux_buttons(2);
		
		for (unsigned int player=0; player<2; player++)
		{
			if (touch[player] < 2 && buttons[player] != 0x0000) touch[player] = 2;
			else if (touch[player] > 2 && buttons[player] == 0x0000)
			{
				touch[player] = touch[player] - 1;
				
				if (touch[player] == 2) touch[player] = 1;
			}
			
			if (battle[player] == 0)
			{
				if (touch[player] == 2)
				{
					if ((buttons[player] & 0x0020) == 0x0020)
					{
						if (confirm[player] == 0 && menu[player] == 0)
						{
							menu[player] = 1;
						
							select[player] = 0;
							
							counter[player] = 1000;
						}
					}
					
					if (confirm[player] == 0 && menu[player] == 0 && game[player] == 0 && leveling[player] == 0)
					{
						if ((buttons[player] & 0x0001) == 0x0001) tux_trainer[player].direction = 0;
						if ((buttons[player] & 0x0002) == 0x0002) tux_trainer[player].direction = 1;
						if ((buttons[player] & 0x0004) == 0x0004) tux_trainer[player].direction = 2;
						if ((buttons[player] & 0x0008) == 0x0008) tux_trainer[player].direction = 3;

						counter[player]++;

						if (counter[player] >= player_speed)
						{
							counter[player] = 0;

							prex = tux_trainer[player].posx;
							prey = tux_trainer[player].posy;

							if (tux_trainer[player].direction == 0) tux_trainer[player].posy--;
							else if (tux_trainer[player].direction == 1) tux_trainer[player].posy++;
							else if (tux_trainer[player].direction == 2) tux_trainer[player].posx--;
							else if (tux_trainer[player].direction == 3) tux_trainer[player].posx++;

							for (unsigned int conn=0; conn<tux_connection_total; conn++)
							{
								if (tux_trainer[player].map == tux_connection[conn].source_map &&
									tux_trainer[player].posx >= tux_connection[conn].source_x1 &&
									tux_trainer[player].posx <= tux_connection[conn].source_x2 &&
									tux_trainer[player].posy >= tux_connection[conn].source_y1 &&
									tux_trainer[player].posy <= tux_connection[conn].source_y2)
								{
									tux_trainer[player].map = tux_connection[conn].destination_map;
									tux_trainer[player].posx = tux_connection[conn].destination_x + 4 * player;
									tux_trainer[player].posy = tux_connection[conn].destination_y;
									
									prex = tux_trainer[player].posx;
									prey = tux_trainer[player].posy;
								}
							}

							if ((tux_map_pointer[tux_trainer[player].map][((tux_trainer[player].posy+5)/4) * 
									tux_map_width[tux_trainer[player].map] + 
								((tux_trainer[player].posx+1)/4)] >= 0x80) &&
								(tux_map_pointer[tux_trainer[player].map][((tux_trainer[player].posy+5)/4) * 
									tux_map_width[tux_trainer[player].map] + 
								((tux_trainer[player].posx+2)/4)] >= 0x80))
							{
								tux_trainer[player].posx = prex;
								tux_trainer[player].posy = prey;
							}
							
							if (tux_trainer[player].posx >= (unsigned int)(tux_tetra_loc_x * 4) - 2 &&
								tux_trainer[player].posx <= (unsigned int)(tux_tetra_loc_x * 4) + 2 &&
								tux_trainer[player].posy >= (unsigned int)(tux_tetra_loc_y * 4) - 5 &&
								tux_trainer[player].posy <= (unsigned int)(tux_tetra_loc_y * 4) &&
								tux_trainer[player].map == tux_tetra_loc_map) // start up tetra
							{
								tux_trainer[player].posx = prex;
								tux_trainer[player].posy = prey;
								
								if ((buttons[player] & 0x0010) == 0x0010)
								{
									game[player] = 1;
								}
							}
							
							if (tux_trainer[player+2].posx > 0 || tux_trainer[player+2].posy > 0)
							{
								tux_trainer[player+2].posx = 0;
								tux_trainer[player+2].posy = 0;
							}
							
							if ((((tux_map_pointer[tux_trainer[player].map][((tux_trainer[player].posy+5)/4) * 
									tux_map_width[tux_trainer[player].map] + 
								((tux_trainer[player].posx+1)/4)] & 0x40) == 0x40) &&
								((tux_map_pointer[tux_trainer[player].map][((tux_trainer[player].posy+5)/4) * 
									tux_map_width[tux_trainer[player].map] + 
								((tux_trainer[player].posx+2)/4)] & 0x40) == 0x40)))
							{
								if (tux_random(player) < encounter_speed)
								{
									// change this later!
									tux_trainer[player+2].posx = tux_trainer[player].posx; 
									tux_trainer[player+2].posy = tux_trainer[player].posy;
								}
							}

							if (abs(tux_trainer[0].posx - tux_trainer[1].posx) <= 2 &&
								abs(tux_trainer[0].posy - tux_trainer[1].posy) <= 3 &&
								tux_trainer[0].map == tux_trainer[1].map)
							{
								//tux_trainer[player].posx = prex;
								//tux_trainer[player].posy = prey;
								
								if (confirm[0] == 0 && confirm[1] == 0)
								{
									if ((buttons[player] & 0x0010) == 0x0010)
									{
										confirm[0] = 2;
										confirm[1] = 1;
										counter[0] = 1000;
										counter[1] = 1000;
										select[0] = 0;
										select[1] = 0;
									}
								}
							}

							for (unsigned int sprite=2; sprite<tux_trainer_total; sprite++)
							{
								if (abs(tux_trainer[player].posx - tux_trainer[sprite].posx) <= 2 &&
									abs(tux_trainer[player].posy - tux_trainer[sprite].posy) <= 3 &&
									tux_trainer[player].map == tux_trainer[sprite].map)
								{
									tux_trainer[player].posx = prex;
									tux_trainer[player].posy = prey;

									if ((player == 0 && battle[1] != sprite + 1) ||
										(player == 1 && battle[0] != sprite + 1))
									{		
										if ((player == 0 && confirm[1] != sprite + 1) ||
											(player == 1 && confirm[0] != sprite + 1))
										{
											if (((buttons[player] & 0x0010) == 0x0010 && sprite >= 4) || sprite < 4)
											{
												confirm[player] = sprite + 1;
												counter[player] = 1000;
												select[player] = 0;
											}
										}
									}
								}
							}

							tux_trainer[player].frame++;

							if (tux_trainer[player].frame >= 8) tux_trainer[player].frame = 0;
						}
					}
					else if (game[player] > 0)
					{
						// find way to exit game here
						if (player == 0 && TetraCheck(0x01, 0x00) == 2)
						{
							game[0] = 0;
							
							counter[0] = 1000;
							touch[0] = 100;
						}
						if (player == 1 && TetraCheck(0x00, 0x01) == 2)
						{
							game[1] = 0;
							
							counter[1] = 1000;
							touch[1] = 100;
						}
					}
					else if (confirm[player] > 0)
					{
						for (unsigned int i=0; i<4; i++)
						{
							for (unsigned int j=0; j<16; j++)
							{
								tux_draw_character(8+j*8, 96, 0xFFFF, tux_trainer[confirm[player]-1].text[i*16+j]);
							}	
						}
						
						if ((buttons[player] & 0x0010) == 0x0010)
						{
							if (counter[player] == 0)
							{
								counter[player] = 1000; // debounce
								
								if (tux_trainer[confirm[player]-1].level[0] > 0)
								{
									select[player] = 1;
								}
								else
								{
									confirm[player] = 0;
								}
							}
						}		
									
						if ((buttons[player] & 0x0001) == 0x0000 &&
							(buttons[player] & 0x0002) == 0x0000 &&
							(buttons[player] & 0x0010) == 0x0000 &&
							(buttons[player] & 0x0020) == 0x0000)
						{
							counter[player] = counter[player] - 1;
						}
						
						if ((buttons[player] & 0x0020) == 0x0020 &&
							counter[player] == 0)
						{
							if (confirm[0] == 2 && confirm[1] == 1)
							{
								confirm[0] = 0;
								confirm[1] = 0;
							}
							else
							{
								confirm[player] = 0;
							}
							
							counter[player] = 1000;
							touch[player] = 100;
						}
						
						
						if (confirm[0] == 2 && confirm[1] == 1 &&
							select[0] == 1 && select[1] == 1)
						{
							if (battle[0] == 0 && battle[1] == 0)
							{
								confirm[0] = 0;
								confirm[1] = 0;
								
								battle[0] = 2;
								battle[1] = 1;

								select[0] = 0;
								select[1] = 0;

								active[0] = 1;
								active[1] = 1;

								swap[0] = 0;
								swap[1] = 0;

								// make trainer sprites look normal

								tux_trainer[0].animation = 1; // intro
								tux_trainer[0].timer = 0;
								tux_trainer[0].order = 0;
								tux_trainer[0].damage = 0;
								tux_trainer[1].animation = 1;
								tux_trainer[1].timer = 0;
								tux_trainer[1].order = 0;
								tux_trainer[1].damage = 0;

								shout_text[1] = tux_mon[tux_trainer[0].mon[0]].name;
								shout_text[0] = tux_mon[tux_trainer[1].mon[0]].name;

								// TEMPORARY?
								tux_trainer[0].health[0] = tux_mon[tux_trainer[0].mon[0]].max_health;
								tux_trainer[0].health[1] = tux_mon[tux_trainer[0].mon[1]].max_health;
								tux_trainer[1].health[0] = tux_mon[tux_trainer[1].mon[0]].max_health;
								tux_trainer[1].health[1] = tux_mon[tux_trainer[1].mon[1]].max_health;
							}
						}
						else if (confirm[player] > 2 && select[player] == 1)
						{
							if ((player == 0 && confirm[player]-1 == 2) ||
								(player == 1 && confirm[player]-1 == 3)) // wild mon
							{
								// randomize mons here

								int temp = tux_random(player+2) % 16;
								tux_trainer[player+2].mon[0] = 1 + temp;
								tux_trainer[player+2].level[0] = 1;
								tux_trainer[player+2].experience[0] = 0;
							}

							if (tux_trainer[confirm[player]-1].level[0] > 0)
							{
								battle[player] = confirm[player];
								
								confirm[player] = 0;

								select[player] = 0;

								active[player] = 1;

								swap[player] = 0;
								swap[player+2] = 0;

								// make trainer sprites look normal

								tux_trainer[player].animation = 1; // intro
								tux_trainer[player].timer = 0;
								tux_trainer[player].order = 0;
								tux_trainer[player].damage = 0;
								tux_trainer[battle[player]-1].animation = 1;
								tux_trainer[battle[player]-1].timer = 0;
								tux_trainer[battle[player]-1].order = 0;
								tux_trainer[battle[player]-1].damage = 0;

								shout_text[player] = tux_mon[tux_trainer[battle[player]-1].mon[0]].name;

								// TEMPORARY?
								tux_trainer[player].health[0] = tux_mon[tux_trainer[player].mon[0]].max_health;
								tux_trainer[player].health[1] = tux_mon[tux_trainer[player].mon[1]].max_health;
								tux_trainer[battle[player]-1].health[0] = tux_mon[tux_trainer[battle[player]-1].mon[0]].max_health;
								tux_trainer[battle[player]-1].health[1] = tux_mon[tux_trainer[battle[player]-1].mon[1]].max_health;
							}
						}
					}
					else if (menu[player] > 0)
					{
						if ((buttons[player] & 0x0001) == 0x0001)
						{
							if (counter[player] == 0)
							{
								counter[player] = 1000; // debounce
								if (select[player] > 0) select[player]--;
							}
						}
						
						if ((buttons[player] & 0x0002) == 0x0002)
						{
							if (counter[player] == 0)
							{
								counter[player] = 1000; // debounce
								if (select[player] < 6) select[player]++;
							}
						}
						
						if ((buttons[player] & 0x0010) == 0x0010)
						{
							if (counter[player] == 0)
							{
								counter[player] = 1000; // debounce
								
								if (select[player] == 0)
								{
									// ???
								}
								else if (select[player] == 1)
								{
									// ???
								}
								else if (select[player] >= 2 && select[player] <= 6)
								{
									if (tux_trainer[player].level[select[player]-2] > 0)
									{
										int temp;
	
										temp = tux_trainer[player].mon[select[player]-1];
										tux_trainer[player].mon[select[player]-1] = tux_trainer[player].mon[select[player]-2];
										tux_trainer[player].mon[select[player]-2] = temp;

										temp = tux_trainer[player].level[select[player]-1];
										tux_trainer[player].level[select[player]-1] = tux_trainer[player].level[select[player]-2];
										tux_trainer[player].level[select[player]-2] = temp;

										temp = tux_trainer[player].experience[select[player]-1];
										tux_trainer[player].experience[select[player]-1] = tux_trainer[player].experience[select[player]-2];
										tux_trainer[player].experience[select[player]-2] = temp;
										
										select[player] = select[player] - 1;
									}
								}
								else if (select[player] == 7)
								{
									// ???
								}
							}
						}
						
						if ((buttons[player] & 0x0001) == 0x0000 &&
							(buttons[player] & 0x0002) == 0x0000 &&
							(buttons[player] & 0x0010) == 0x0000 &&
							(buttons[player] & 0x0020) == 0x0000)
						{
							counter[player] = counter[player] - 1;
						}
						
						if ((buttons[player] & 0x0020) == 0x0020 && counter[player] == 0)
						{
							menu[player] = 0;
							
							counter[player] = 1000;
							touch[player] = 100;
						}
					}
				}
				else if (touch[player] == 1)
				{
					touch[player] = 0;

					counter[player] = 0;

					tux_trainer[player].frame = 0;
				}
			}
			else if (active[player] == 0)
			{
				if (buttons[player] == 0x0000)
				{
					held[player] = 0;
				}
				
				if (touch[player] == 2)
				{
					//if (wait[player] == 0)
					//{	
						if ((buttons[player] & 0x0020) == 0x0020)
						{
						}
						else if ((buttons[player] & 0x0001) == 0x0001)
						{
							if (select[player] > 0 && held[player] == 0) select[player]--;
		
							held[player] = 1;
						}
						else if ((buttons[player] & 0x0002) == 0x0002)
						{
							if (select[player] < 6 && held[player] == 0) select[player]++;
							
							held[player] = 1;
						}
						else if ((buttons[player] & 0x0010) == 0x0010)
						{
							if (select[player] < 4) // attacks
							{
								if (select[player] < 2 ||
									(select[player] == 2 && tux_trainer[player].level[swap[player]%2] >= 10) ||
									(select[player] == 3 && tux_trainer[player].level[swap[player]%2] >= 20))
								{
									wait[player] = select[player]+1;
								
									if ((player == 0 && battle[0] == 2) ||
										(player == 1 && battle[1] == 1))
									{
										if (player == 0) shout_text[1] = tux_move[tux_mon[tux_trainer[0].mon[swap[0]%2]].move[wait[0]-1]].name;
										else if (player == 1) shout_text[0] = tux_move[tux_mon[tux_trainer[1].mon[swap[1]%2]].move[wait[1]-1]].name;
									}
								}
							}
							else if (select[player] == 4) // switch
							{
								wait[player] = 5;

								if (tux_trainer[player].health[1-swap[player]] > 0)
								{
									swap[player] += 2;

									if ((player == 0 && battle[0] == 2) ||
										(player == 1 && battle[1] == 1))
									{
										if (player == 0)
										{
											if (swap[0] == 2) shout_text[1] = tux_mon[tux_trainer[0].mon[1]].name;
											else if (swap[0] == 3) shout_text[1] = tux_mon[tux_trainer[0].mon[0]].name;
										}
										else if (player == 1)
										{
											if (swap[1] == 2) shout_text[0] = tux_mon[tux_trainer[1].mon[1]].name;
											else if (swap[1] == 3) shout_text[0] = tux_mon[tux_trainer[1].mon[0]].name;
										}
									}
								}
								else
								{
									if (swap[player] == 0) swap[player] = 4;
									else if (swap[player] == 1) swap[player] = 5;
								}
							}
							else if (select[player] == 5) // catch
							{
								wait[player] = 6;
								
								if ((player == 0 && battle[0] == 2) ||
									(player == 1 && battle[1] == 1))
								{
									if (player == 0) shout_text[1] = "        ";
									else if (player == 1) shout_text[0] = "        ";
								}
							}
							else if (select[player] == 6) // run away
							{
								wait[player] = 7;
								
								if ((player == 0 && battle[0] == 2) ||
									(player == 1 && battle[1] == 1))
								{
									if (player == 0) shout_text[1] = "RUN     ";
									else if (player == 1) shout_text[0] = "RUN     ";
								}
							}

							if ((player == 0 && battle[0] == 2) ||
								(player == 1 && battle[1] == 1))
							{
								if (wait[0] > 0 && wait[1] > 0)
								{
									for (unsigned int i=0; i<2; i++)
									{
										if (wait[i] < 5)
										{
											tux_trainer[i].animation = tux_move[tux_mon[tux_trainer[i].mon[swap[i]%2]].move[wait[i]-1]].animation;
											
											if (tux_move[tux_mon[tux_trainer[i].mon[swap[i]%2]].move[wait[i]-1]].type == 
												tux_mon[tux_trainer[1-i].mon[swap[1-i]%2]].type) // not very effective
											{
												tux_trainer[i].damage = (tux_mon[tux_trainer[i].mon[swap[i]%2]].strength *
													tux_trainer[i].level[swap[i]%2] + 
													tux_move[tux_mon[tux_trainer[i].mon[swap[i]%2]].move[wait[i]-1]].attack - 
													tux_mon[tux_trainer[1-i].mon[swap[1-i]%2]].defense *
													tux_trainer[1-i].level[swap[1-i]%2]) / 10;
											}
											else if ((tux_move[tux_mon[tux_trainer[i].mon[swap[i]%2]].move[wait[i]-1]].type + 1) % 5 ==
												tux_mon[tux_trainer[1-i].mon[swap[1-i]%2]].type) // super effective
											{
												tux_trainer[i].damage = ((tux_mon[tux_trainer[i].mon[swap[i]%2]].strength *
													tux_trainer[i].level[swap[i]%2] + 
													tux_move[tux_mon[tux_trainer[i].mon[swap[i]%2]].move[wait[i]-1]].attack - 
													tux_mon[tux_trainer[1-i].mon[swap[1-i]%2]].defense *
													tux_trainer[1-i].level[swap[1-i]%2]) * 5) / 2;
											}
											else // regular attack
											{
												tux_trainer[i].damage = (tux_mon[tux_trainer[i].mon[swap[i]%2]].strength *
													tux_trainer[i].level[swap[i]%2] + 
													tux_move[tux_mon[tux_trainer[i].mon[swap[i]%2]].move[wait[i]-1]].attack - 
													tux_mon[tux_trainer[1-i].mon[swap[1-i]%2]].defense *
													tux_trainer[1-i].level[swap[1-i]%2]) / 5;
											}
											
											tux_trainer[i].damage += (signed int)((tux_random(i) - 128) / 32);
											
											if (tux_trainer[i].damage <= 0) tux_trainer[i].damage = 1;
											
											if (2 * tux_move[tux_mon[tux_trainer[i].mon[swap[i]%2]].move[wait[i]-1]].accuracy -
												tux_mon[tux_trainer[1-i].mon[swap[1-i]%2]].agility *
												tux_trainer[1-i].level[swap[1-i]%2] -
												(signed int)(tux_random(1-i) / 16) <= 0)
											{
												tux_trainer[i].damage = 0; // avoided attack
											}
											
											if (tux_move[tux_mon[tux_trainer[i].mon[swap[i]%2]].move[wait[i]-1]].critical >=
												(signed int)(tux_random(i))) // critical hit
											{
												tux_trainer[i].damage = (signed int)((tux_trainer[i].damage * 3) / 2);
											}
											
											tux_trainer[i].quickness = tux_mon[tux_trainer[i].mon[swap[i]%2]].speed *
												tux_trainer[i].level[swap[i]%2] + 
												tux_move[tux_mon[tux_trainer[i].mon[swap[i]%2]].move[wait[i]-1]].haste +
												(signed int)(tux_random(i) / 32);
										}
										else if (wait[i] == 5) // switch
										{
											tux_trainer[i].animation = 2;
											tux_trainer[i].damage = 0;
										}
										else if (wait[i] == 6) // catch (isn't possible)
										{
											tux_trainer[i].animation = 9;
											tux_trainer[i].damage = 0;
										}
										else if (wait[i] == 7) // run
										{
											leave[i] = 2;
											tux_trainer[i].animation = 3;
											tux_trainer[i].damage = 0;
										}
										
										tux_trainer[i].timer = 0;
									}

									// pick by speed who goes first
									if (tux_trainer[0].quickness >= tux_trainer[1].quickness)
									{
										tux_trainer[0].order = 0;
										tux_trainer[1].order = 1;
									}
									else
									{
										tux_trainer[0].order = 1;
										tux_trainer[1].order = 0;
									}
									
									if (wait[0] == 6 && wait[1] != 6)
									{
										tux_trainer[0].order = 0;
										tux_trainer[1].order = 1;
									}
									else if (wait[0] != 6 && wait[1] == 6)
									{
										tux_trainer[0].order = 1;
										tux_trainer[1].order = 0;
									}
									
									if (swap[0] >= 2 && swap[1] >= 2)
									{
										tux_trainer[0].order = 0;
										tux_trainer[1].order = 0;
									}
									else if (swap[0] >= 2)
									{
										tux_trainer[0].order = 0;
										tux_trainer[1].order = 1;
									}
									else if (swap[1] >= 2)
									{
										tux_trainer[0].order = 1;
										tux_trainer[1].order = 0;
									}
									
									if (leave[0] > 0 && leave[1] > 0)
									{
										tux_trainer[0].animation = 3;
										tux_trainer[0].order = 0;
										tux_trainer[1].animation = 3;
										tux_trainer[1].order = 0;
									}
									else if (leave[0] > 0)
									{
										tux_trainer[0].animation = 3;
										tux_trainer[0].order = 0;
										tux_trainer[1].animation = 0;
										tux_trainer[1].order = -1;
									}
									else if (leave[1] > 0)
									{
										tux_trainer[0].animation = 0;
										tux_trainer[0].order = -1;
										tux_trainer[1].animation = 3;
										tux_trainer[1].order = 0;
									}
									
									wait[0] = 0;
									wait[1] = 0;

									active[0] = 1;
									active[1] = 1;
								}
							}
							else
							{
								if (wait[player] > 0)
								{
									if (wait[player] < 5)
									{
										tux_trainer[player].animation = tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[wait[player]-1]].animation;

										if (tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[wait[player]-1]].type == 
											tux_mon[tux_trainer[battle[player]-1].mon[swap[battle[player]-1]%2]].type) // not very effective
										{
											tux_trainer[player].damage = (tux_mon[tux_trainer[player].mon[swap[player]%2]].strength *
												tux_trainer[player].level[swap[player]%2] + 
												tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[wait[player]-1]].attack - 
												tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].defense *
												tux_trainer[battle[player]-1].level[swap[player+2]%2]) / 10;
										}
										else if ((tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[wait[player]-1]].type + 1) % 5 ==
											tux_mon[tux_trainer[battle[player]-1].mon[swap[battle[player]-1]%2]].type) // super effective
										{
											tux_trainer[player].damage = ((tux_mon[tux_trainer[player].mon[swap[player]%2]].strength *
												tux_trainer[player].level[swap[player]%2] + 
												tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[wait[player]-1]].attack - 
												tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].defense *
												tux_trainer[battle[player]-1].level[swap[player+2]%2]) * 5) / 2;
										}
										else // regular attack
										{
											tux_trainer[player].damage = (tux_mon[tux_trainer[player].mon[swap[player]%2]].strength *
												tux_trainer[player].level[swap[player]%2]+ 
												tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[wait[player]-1]].attack - 
												tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].defense *
												tux_trainer[battle[player]-1].level[swap[player+2]%2]) / 5;
										}

										tux_trainer[player].damage += (signed int)((tux_random(player) - 128) / 32);

										if (tux_trainer[player].damage <= 0) tux_trainer[player].damage = 1;

										if (2 * tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[wait[player]-1]].accuracy -
											tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].agility *
											tux_trainer[battle[player]-1].level[swap[player+2]%2] -
											(signed int)(tux_random(battle[player]-1) / 16) <= 0)
										{
											tux_trainer[player].damage = 0; // avoided attack
										}

										if (tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[wait[player]-1]].critical >=
											(signed int)(tux_random(player))) // critical hit
										{
											tux_trainer[player].damage = (signed int)((tux_trainer[player].damage * 3) / 2);
										}

										tux_trainer[player].quickness = tux_mon[tux_trainer[player].mon[swap[player]%2]].speed *
											tux_trainer[player].level[swap[player]%2] + 
											tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[wait[player]-1]].haste +
											(signed int)(tux_random(player) / 32);
									}
									else if (wait[player] == 5) // switch
									{
										tux_trainer[player].animation = 2;
										tux_trainer[player].damage = 0;
									}
									else if (wait[player] == 6) // catch
									{
										if (battle[player] > 2 && battle[player] <= 4)
										{
											tux_trainer[player].animation = 8;
											tux_trainer[player].damage = 0;
										}
										else if (battle[player] > 4)
										{
											tux_trainer[player].animation = 9;
											tux_trainer[player].damage = 0;
										}
									}
									else if (wait[player] == 7) // run
									{
										leave[player] = 2;
										tux_trainer[player].damage = 0;
									}

									if (tux_trainer[battle[player]-1].level[swap[player+2]%2] < 10)
									{
										rand_val = tux_random(battle[player]-1) % 2;
									}
									else if (tux_trainer[battle[player]-1].level[swap[player+2]%2] < 20)
									{
										rand_val = tux_random(battle[player]-1) % 3;
									}
									else
									{
										rand_val = tux_random(battle[player]-1) % 4;
									}

									tux_trainer[battle[player]-1].animation = 
										tux_move[tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].move[rand_val]].animation;


									if (tux_move[tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].move[rand_val]].type == 
										tux_mon[tux_trainer[battle[player]-1].mon[swap[player]%2]].type) // not very effective
									{
										tux_trainer[battle[player]-1].damage = (tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].strength *
											tux_trainer[battle[player]-1].level[swap[player+2]%2] + 
											tux_move[tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].move[rand_val]].attack - 
											tux_mon[tux_trainer[player].mon[swap[player]%2]].defense *
											tux_trainer[player].level[swap[player]%2]) / 10;
									}
									else if ((tux_move[tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].move[rand_val]].type + 1) % 5 ==
										tux_mon[tux_trainer[player].mon[swap[player]%2]].type) // super effective
									{
										tux_trainer[battle[player]-1].damage = ((tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].strength *
											tux_trainer[battle[player]-1].level[swap[player+2]%2] + 
											tux_move[tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].move[rand_val]].attack - 
											tux_mon[tux_trainer[player].mon[swap[player]%2]].defense *
											tux_trainer[player].level[swap[player]%2]) * 5) / 2;
									}
									else // regular attack
									{
										tux_trainer[battle[player]-1].damage = (tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].strength *
											tux_trainer[battle[player]-1].level[swap[player+2]%2] + 
											tux_move[tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].move[rand_val]].attack - 
											tux_mon[tux_trainer[player].mon[swap[player]%2]].defense *
											tux_trainer[player].level[swap[player]%2]) / 5;
									}

									tux_trainer[battle[player]-1].damage += (signed int)((tux_random(battle[player]-1) - 128) / 32);

									if (tux_trainer[battle[player]-1].damage <= 0) tux_trainer[battle[player]-1].damage = 1;

									if (2 * tux_move[tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].move[rand_val]].accuracy -
										tux_mon[tux_trainer[player].mon[swap[player]%2]].agility *
										tux_trainer[player].level[swap[player]%2] -
										(signed int)(tux_random(player) / 16) <= 0)
									{
										tux_trainer[battle[player]-1].damage = 0; // avoided attack
									}

									if (tux_move[tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].move[rand_val]].critical >=
										(signed int)(tux_random(battle[player]-1))) // critical hit
									{
										tux_trainer[battle[player]-1].damage = (signed int)((tux_trainer[battle[player]-1].damage * 3) / 2);
									}

									tux_trainer[battle[player]-1].quickness = 
										tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].speed *
										tux_trainer[battle[player]-1].level[swap[player+2]%2] + 
										tux_move[tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].move[rand_val]].haste +
										(signed int)(tux_random(battle[player]-1) / 32);

									shout_text[player] = tux_move[tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].move[rand_val]].name;

									tux_trainer[player].timer = 0;
									tux_trainer[battle[player]-1].timer = 0;

									// pick by speed who goes first
									if (tux_trainer[player].quickness >= tux_trainer[battle[player]-1].quickness)
									{
										tux_trainer[player].order = 0;
										tux_trainer[battle[player]-1].order = 1;
									}
									else
									{
										tux_trainer[player].order = 1;
										tux_trainer[battle[player]-1].order = 0;
									}

									if (wait[player] == 6)
									{
										tux_trainer[player].order = 0;
										tux_trainer[battle[player]-1].order = 1;
									}

									if (swap[player] >= 2)
									{
										tux_trainer[player].order = 0;
										tux_trainer[battle[player]-1].order = 1;
									}

									if (leave[player] > 0)
									{
										tux_trainer[player].animation = 3;
										tux_trainer[player].order = 0;
										tux_trainer[battle[player]-1].animation = 0;
										tux_trainer[battle[player]-1].order = -1;
									}

									wait[player] = 0;

									active[player] = 1;
								}
							}
						}
					//}
				}
			}
					
			for (unsigned int sprite=2; sprite<tux_trainer_total; sprite++)
			{
				tux_trainer[sprite].ai_counter++;
				
				if (tux_trainer[sprite].ai_counter > sprite_speed)
				{
					tux_trainer[sprite].ai_counter = 0;
				
					if (tux_trainer[sprite].homex == 0 && tux_trainer[sprite].homey == 0)
					{
						// ignore
					}
					else
					{
						prex = tux_trainer[sprite].posx;
						prey = tux_trainer[sprite].posy;
						
						if (confirm[0] != sprite+1 && confirm[1] != sprite+1 && 
							battle[0] != sprite+1 && battle[1] != sprite+1)
						{
							if (tux_trainer[sprite].ai_direction == 0)
							{
								tux_trainer[sprite].posy -= 1;
							}
							else if (tux_trainer[sprite].ai_direction == 1)
							{
								tux_trainer[sprite].posy += 1;
							}
							else if (tux_trainer[sprite].ai_direction == 2)
							{
								tux_trainer[sprite].posx -= 1;
							}
							else if (tux_trainer[sprite].ai_direction == 3)
							{
								tux_trainer[sprite].posx += 1;
							}

							tux_trainer[sprite].frame += 1;

							if (tux_trainer[sprite].frame >= 8) tux_trainer[sprite].frame = 0;

							tux_trainer[sprite].direction = tux_trainer[sprite].ai_direction;
						}
						
						if (abs(tux_trainer[0].posx - tux_trainer[sprite].posx) <= 2 &&
							abs(tux_trainer[0].posy - tux_trainer[sprite].posy) <= 3 &&
							tux_trainer[0].map == tux_trainer[sprite].map)
						{
							tux_trainer[sprite].posx = prex;
							tux_trainer[sprite].posy = prey;
						}
						
						if (abs(tux_trainer[1].posx - tux_trainer[sprite].posx) <= 2 &&
							abs(tux_trainer[1].posy - tux_trainer[sprite].posy) <= 3 &&
							tux_trainer[1].map == tux_trainer[sprite].map)
						{
							tux_trainer[sprite].posx = prex;
							tux_trainer[sprite].posy = prey;
						}
						
						if ((tux_map_pointer[tux_trainer[sprite].map][((tux_trainer[sprite].posy+5)/4) *
								tux_map_width[tux_trainer[sprite].map] + 
							((tux_trainer[sprite].posx+1)/4)] >= 0x80) &&
							(tux_map_pointer[tux_trainer[sprite].map][((tux_trainer[sprite].posy+5)/4) * 
								tux_map_width[tux_trainer[sprite].map] + 
							((tux_trainer[sprite].posx+2)/4)] >= 0x80))
						{
							tux_trainer[sprite].posx = prex;
							tux_trainer[sprite].posy = prey;
						}
						
						tux_trainer[sprite].ai_distance++;
						
						if (tux_trainer[sprite].ai_distance > 10)
						{
							tux_trainer[sprite].ai_distance = 0;
							
							rand_val = tux_random(sprite);
						
							if (rand_val < 0x40)
							{
								tux_trainer[sprite].ai_direction = 0;
							}
							else if (rand_val < 0x80)
							{
								tux_trainer[sprite].ai_direction = 1;
							}
							else if (rand_val < 0xC0)
							{
								tux_trainer[sprite].ai_direction = 2;
							}
							else
							{
								tux_trainer[sprite].ai_direction = 3;
							}
						}
						
						if (tux_trainer[sprite].posy > tux_trainer[sprite].homey + 3)
						{
							tux_trainer[sprite].ai_direction = 0;
						}
						if (tux_trainer[sprite].posy < tux_trainer[sprite].homey - 3)
						{
							tux_trainer[sprite].ai_direction = 1;
						}
						if (tux_trainer[sprite].posx > tux_trainer[sprite].homex + 3)
						{
							tux_trainer[sprite].ai_direction = 2;
						}
						if (tux_trainer[sprite].posx < tux_trainer[sprite].homex - 3)
						{
							tux_trainer[sprite].ai_direction = 3;
						}
					}
				}
			}
		}
		
		drawing++;
		
		if (drawing >= draw_speed)
		{
			drawing = 0;
			
			if (game[0] == 0 && game[1] == 0)
			{
				// do nothing
			}
			else if (game[0] > 0 && game[1] == 0)
			{
				TetraLoop(0x01, 0x00);
			}
			else if (game[0] == 0 && game[1] > 0)
			{
				TetraLoop(0x00, 0x01);
			}
			else if (game[0] > 0 && game[1] > 0)
			{
				TetraLoop(0x01, 0x01);
			}
			
			for (unsigned int player=0; player<2; player++)
			{
				if (game[player] > 0)
				{		
					continue;
				}
				
				if (tux_trainer[player].experience[0] >= tux_trainer[player].level[0] && 
					tux_trainer[player].level[0] > 0 && leveling[player] == 0)
				{
					leveling[player] = level_speed;
				}
				else if (tux_trainer[player].experience[1] >= tux_trainer[player].level[1] &&
					tux_trainer[player].level[1] > 0 && leveling[player] == 0)
				{
					leveling[player] = level_speed;
				}
				
				if (leveling[player] > 0)
				{
					leveling[player] = leveling[player] - 1;
					
					tux_draw_clear(0x1111);
					
					for (unsigned int i=40; i<120; i++)
					{
						for (unsigned int j=0; j<40; j++)
						{
							if ((i+j) % 2 == 0) buffer[(i)*40+(j+0)] = 0xE1E1;
							else buffer[(i)*40+(j+0)] = 0x1E1E;
						}
					}
					
					for (unsigned int i=0; i<2; i++)
					{
						if (tux_trainer[player].experience[i] >= tux_trainer[player].level[i] && 
							tux_trainer[player].level[i] > 0)
						{
							
							for (unsigned int j=0; j<8; j++)
							{
								tux_draw_character(12+2*j, 24, 0xFFFF, tux_mon[tux_trainer[player].mon[i]].name[j]); // old one
							}

							tux_draw_mon(tux_mon[tux_trainer[player].mon[i]].pointer, 0, 12, 12); // old one

							tux_draw_character(12, 128, 0xFFFF, 'L');
							tux_draw_character(14, 128, 0xFFFF, 'V');
							tux_draw_character(16, 128, 0xFFFF, 'L');
							tux_draw_decimal(18, 128, 0xFFFF, tux_trainer[player].level[i] + 1);

							if (leveling[player] == 0)
							{
								tux_trainer[player].experience[i] = tux_trainer[player].experience[i] - tux_trainer[player].level[i];
								tux_trainer[player].level[i] = tux_trainer[player].level[i] + 1;
							}
							
							break;
						}
					}
				}
				else if (battle[player] == 0)
				{
					tux_draw_clear(0x1111);

					tux_draw_map(tux_map_pointer[tux_trainer[player].map], tileset_one,
						1, tux_trainer[player].map, tux_map_width[tux_trainer[player].map], tux_map_length[tux_trainer[player].map], 
						tux_trainer[player].posx-cenx, tux_trainer[player].posy-ceny);

					for (unsigned int sprite=0; sprite<tux_trainer_total; sprite++)
					{
						tux_trainer[sprite].layer = 0x0000;
					}

					for (unsigned int sprite=0; sprite<tux_trainer_total; sprite++)
					{
						miny = 0xFFFF;
						minv = 0xFFFF;

						for (unsigned int current=0; current<tux_trainer_total; current++)
						{
							if (tux_trainer[current].map == tux_trainer[player].map)
							{
								if (tux_trainer[current].layer == 0x0000)
								{
									if (tux_trainer[current].posy < miny)
									{
										miny = tux_trainer[current].posy;
										minv = current;
									}
								}
							}
						}

						if (minv != 0xFFFF)
						{
							tux_trainer[minv].layer = 0x0001;

							if (tux_trainer[minv].map == tux_trainer[player].map)
							{
								tux_draw_sprite(tux_trainer[minv].pointer, 
									tux_trainer[minv].frame/2, 
									tux_trainer[minv].direction,
									tux_trainer[minv].posx-tux_trainer[player].posx+cenx, 
									tux_trainer[minv].posy-tux_trainer[player].posy+ceny);
							}
						}
					}
					
					if (confirm[player] > 0)
					{
						for (unsigned int i=0; i<32; i++)
						{
							for (unsigned int j=0; j<40; j++)
							{
								buffer[(i+128)*40+j] = 0x1111;
							}
						}
						
						for (unsigned int i=0; i<4; i++)
						{
							for (unsigned int j=0; j<16; j++)
							{
								tux_draw_character(4+j*2, 128+i*8, 0xFFFF, tux_trainer[confirm[player]-1].text[i*16+j]);
							}	
						}
					}
					else if (menu[player] > 0)
					{
						for (unsigned int i=0; i<160; i++)
						{
							for (unsigned int j=0; j<18; j++)
							{
								if (i < 88)
								{
									buffer[(i)*40+(j+0)] = 0x1111;
								}
								else
								{
									if ((i+j) % 2 == 0) buffer[(i)*40+(j+0)] = 0xE1E1;
									else buffer[(i)*40+(j+0)] = 0x1E1E;
								}

								buffer[(i)*40+(j+22)] = 0x1111;
							}
						}

						for (unsigned int i=0; i<8; i++)
						{
							tux_draw_character(2+2*i, 0, 0xFFFF, tux_trainer[player].text[i]);
						}

						for (unsigned int i=0; i<8; i++)
						{
							tux_draw_character(2+2*i, 16, 0xFFFF, tux_mon[tux_trainer[player].mon[0]].name[i]);
						}

						if (tux_trainer[player].level[1] > 0)
						{
							for (unsigned int i=0; i<8; i++)
							{
								tux_draw_character(2+2*i, 24, 0xFFFF, tux_mon[tux_trainer[player].mon[1]].name[i]);
							}
						}

						for (unsigned int i=0; i<3; i++)
						{
							for (unsigned int j=0; j<8; j++)
							{
								if (tux_trainer[player].level[i+2] > 0)
								{
									tux_draw_character(2+2*j, 40+8*i, 0xFFFF, tux_mon[tux_trainer[player].mon[i+2]].name[j]);
								}
							}
						}

						if (tux_trainer[player].level[5] > 0)
						{
							for (unsigned int i=0; i<8; i++)
							{
								tux_draw_character(2+2*i, 72, 0xFFFF, tux_mon[tux_trainer[player].mon[5]].name[i]);
							}
						}

						temp_val = 0;

						if (select[player] == 0) // trainer
						{
							tux_draw_character(0, 0, 0xFFFF, '>');

							tux_draw_trainer(tux_trainer[player].pointer, 1, 23);
							
							temp_val = 1;
						}
						else if (select[player] == 1) // mon #1
						{
							tux_draw_character(0, 16, 0xFFFF, '>');

							tux_draw_mon(tux_mon[tux_trainer[player].mon[0]].pointer, 0, 1, 23);

							temp_val = 2;
						}
						else if (select[player] == 2) // mon #2
						{
							tux_draw_character(0, 24, 0xFFFF, '>');

							if (tux_trainer[player].level[1] > 0)
							{
								tux_draw_mon(tux_mon[tux_trainer[player].mon[1]].pointer, 0, 1, 23);

								temp_val = 2;
							}
						}
						else if (select[player] > 2 && select[player] <= 5) // box
						{
							tux_draw_character(0, 40+8*(select[player]-3), 0xFFFF, '>');

							if (tux_trainer[player].level[select[player]-1] > 0)
							{
								tux_draw_mon(tux_mon[tux_trainer[player].mon[select[player]-1]].pointer, 0, 1, 23);

								temp_val = select[player] + 1;
							}
						}
						else if (select[player] == 6) // last in box
						{
							tux_draw_character(0, 72, 0xFFFF, '>');

							if (tux_trainer[player].level[select[player]-1] > 0)
							{
								tux_draw_mon(tux_mon[tux_trainer[player].mon[select[player]-1]].pointer, 0, 1, 23);

								temp_val = 7;
							}
						}

						if (temp_val == 1)
						{
							if (tux_trainer[player].quest[0] > 0)
							{
								tux_draw_character(22, 0, 0xFFFF, 'X');
							}

							tux_draw_character(26, 8, 0xFFFF, 'E');
							tux_draw_character(28, 8, 0xFFFF, 'A');
							tux_draw_character(30, 8, 0xFFFF, 'R');
							tux_draw_character(32, 8, 0xFFFF, 'N');

							tux_draw_character(24, 16, 0xFFFF, 'S');
							tux_draw_character(26, 16, 0xFFFF, 'I');
							tux_draw_character(28, 16, 0xFFFF, 'L');
							tux_draw_character(30, 16, 0xFFFF, 'V');
							tux_draw_character(32, 16, 0xFFFF, 'E');
							tux_draw_character(34, 16, 0xFFFF, 'R');

							tux_draw_character(24, 24, 0xFFFF, 'B');
							tux_draw_character(26, 24, 0xFFFF, 'A');
							tux_draw_character(28, 24, 0xFFFF, 'D');
							tux_draw_character(30, 24, 0xFFFF, 'G');
							tux_draw_character(32, 24, 0xFFFF, 'E');

							if (tux_trainer[player].quest[1] > 0)
							{
								tux_draw_character(22, 40, 0xFFFF, 'X');
							}

							tux_draw_character(26, 40, 0xFFFF, 'E');
							tux_draw_character(28, 40, 0xFFFF, 'A');
							tux_draw_character(30, 40, 0xFFFF, 'R');
							tux_draw_character(32, 40, 0xFFFF, 'N');

							tux_draw_character(24, 48, 0xFFFF, 'G');
							tux_draw_character(26, 48, 0xFFFF, 'O');
							tux_draw_character(28, 48, 0xFFFF, 'L');
							tux_draw_character(30, 48, 0xFFFF, 'D');

							tux_draw_character(24, 56, 0xFFFF, 'B');
							tux_draw_character(26, 56, 0xFFFF, 'A');
							tux_draw_character(28, 56, 0xFFFF, 'D');
							tux_draw_character(30, 56, 0xFFFF, 'G');
							tux_draw_character(32, 56, 0xFFFF, 'E');

							if (tux_trainer[player].quest[2] > 0)
							{
								tux_draw_character(22, 72, 0xFFFF, 'X');
							}

							tux_draw_character(26, 72, 0xFFFF, 'C');
							tux_draw_character(28, 72, 0xFFFF, 'A');
							tux_draw_character(30, 72, 0xFFFF, 'T');
							tux_draw_character(32, 72, 0xFFFF, 'C');
							tux_draw_character(34, 72, 0xFFFF, 'H');

							tux_draw_character(24, 80, 0xFFFF, 'T');
							tux_draw_character(26, 80, 0xFFFF, 'H');
							tux_draw_character(28, 80, 0xFFFF, 'E');
							tux_draw_character(30, 80, 0xFFFF, ' ');
							tux_draw_character(32, 80, 0xFFFF, 'M');
							tux_draw_character(34, 80, 0xFFFF, 'O');
							tux_draw_character(36, 80, 0xFFFF, 'N');

							tux_draw_character(24, 88, 0xFFFF, 'L');
							tux_draw_character(26, 88, 0xFFFF, 'E');
							tux_draw_character(28, 88, 0xFFFF, 'G');
							tux_draw_character(30, 88, 0xFFFF, 'E');
							tux_draw_character(32, 88, 0xFFFF, 'N');
							tux_draw_character(34, 88, 0xFFFF, 'D');

							if (tux_trainer[player].quest[3] > 0)
							{
								tux_draw_character(22, 104, 0xFFFF, 'X');
							}

							tux_draw_character(26, 104, 0xFFFF, 'B');
							tux_draw_character(28, 104, 0xFFFF, 'E');
							tux_draw_character(30, 104, 0xFFFF, 'C');
							tux_draw_character(32, 104, 0xFFFF, 'O');
							tux_draw_character(34, 104, 0xFFFF, 'M');
							tux_draw_character(36, 104, 0xFFFF, 'E');

							tux_draw_character(24, 112, 0xFFFF, 'T');
							tux_draw_character(26, 112, 0xFFFF, 'H');
							tux_draw_character(28, 112, 0xFFFF, 'E');
							tux_draw_character(30, 112, 0xFFFF, ' ');
							tux_draw_character(32, 112, 0xFFFF, 'M');
							tux_draw_character(34, 112, 0xFFFF, 'O');
							tux_draw_character(36, 112, 0xFFFF, 'N');

							tux_draw_character(24, 120, 0xFFFF, 'C');
							tux_draw_character(26, 120, 0xFFFF, 'H');
							tux_draw_character(28, 120, 0xFFFF, 'A');
							tux_draw_character(30, 120, 0xFFFF, 'M');
							tux_draw_character(32, 120, 0xFFFF, 'P');
							tux_draw_character(34, 120, 0xFFFF, 'I');
							tux_draw_character(36, 120, 0xFFFF, 'O');
							tux_draw_character(38, 120, 0xFFFF, 'N');
						}
						else if (temp_val > 1)
						{
							// also need to add 'type' to mon

							tux_draw_character(22, 0, 0xFFFF, 'L');
							tux_draw_character(24, 0, 0xFFFF, 'V');
							tux_draw_character(26, 0, 0xFFFF, 'L');
							tux_draw_decimal(30, 0, 0xFFFF, (unsigned int)tux_trainer[player].level[temp_val-2]);

							tux_draw_character(22, 8, 0xFFFF, 'E');
							tux_draw_character(24, 8, 0xFFFF, 'X');
							tux_draw_character(26, 8, 0xFFFF, 'P');
							tux_draw_decimal(30, 8, 0xFFFF, (unsigned int)tux_trainer[player].experience[temp_val-2]);

							tux_draw_character(22, 24, 0xFFFF, 'H');
							tux_draw_character(24, 24, 0xFFFF, 'P');
							tux_draw_decimal(30, 24, 0xFFFF, (unsigned int)(tux_mon[tux_trainer[player].mon[temp_val-2]].max_health *
								tux_trainer[player].level[temp_val-2]));

							tux_draw_character(22, 40, 0xFFFF, 'S');
							tux_draw_character(24, 40, 0xFFFF, 'T');
							tux_draw_character(26, 40, 0xFFFF, 'R');
							tux_draw_decimal(30, 40, 0xFFFF, (unsigned int)(tux_mon[tux_trainer[player].mon[temp_val-2]].strength *
								tux_trainer[player].level[temp_val-2]));

							tux_draw_character(22, 48, 0xFFFF, 'D');
							tux_draw_character(24, 48, 0xFFFF, 'E');
							tux_draw_character(26, 48, 0xFFFF, 'F');
							tux_draw_decimal(30, 48, 0xFFFF, (unsigned int)(tux_mon[tux_trainer[player].mon[temp_val-2]].defense *
								tux_trainer[player].level[temp_val-2]));

							tux_draw_character(22, 56, 0xFFFF, 'S');
							tux_draw_character(24, 56, 0xFFFF, 'P');
							tux_draw_character(26, 56, 0xFFFF, 'D');
							tux_draw_decimal(30, 56, 0xFFFF, (unsigned int)(tux_mon[tux_trainer[player].mon[temp_val-2]].speed *
								tux_trainer[player].level[temp_val-2]));

							tux_draw_character(22, 64, 0xFFFF, 'A');
							tux_draw_character(24, 64, 0xFFFF, 'G');
							tux_draw_character(26, 64, 0xFFFF, 'L');
							tux_draw_decimal(30, 64, 0xFFFF, (unsigned int)(tux_mon[tux_trainer[player].mon[temp_val-2]].agility *
								tux_trainer[player].level[temp_val-2]));

							// add 'type' to moves

							for (unsigned int j=0; j<8; j++)
							{
								tux_draw_character(24+2*j, 80, 0xFFFF, 
									tux_move[tux_mon[tux_trainer[player].mon[temp_val-2]].move[0]].name[j]);
							}

							for (unsigned int j=0; j<8; j++)
							{
								tux_draw_character(24+2*j, 88, 0xFFFF, 
									tux_move[tux_mon[tux_trainer[player].mon[temp_val-2]].move[1]].name[j]);
							}

							if (tux_trainer[player].level[temp_val-2] >= 10)
							{
								for (unsigned int j=0; j<8; j++)
								{
									tux_draw_character(24+2*j, 96, 0xFFFF, 
										tux_move[tux_mon[tux_trainer[player].mon[temp_val-2]].move[2]].name[j]);
								}
							}

							if (tux_trainer[player].level[temp_val-2] >= 20)
							{
								for (unsigned int j=0; j<8; j++)
								{
									tux_draw_character(24+2*j, 104, 0xFFFF, 
										tux_move[tux_mon[tux_trainer[player].mon[temp_val-2]].move[3]].name[j]);
								}
							}
						}
					}
				}
				else
				{
					if (player == 0 && battle[0] == 2)
					{
						if (tux_trainer[0].animation > 0 && tux_trainer[0].order == 0 && 
							tux_trainer[1].animation > 0 && tux_trainer[1].order == 0)
						{
							temp_anim[1] = tux_trainer[1].animation;
							temp_timer[1] = tux_trainer[1].timer;
							
							tux_draw_battle_anim(tux_mon[tux_trainer[0].mon[swap[0]%2]].pointer, 
								tux_mon[tux_trainer[1].mon[swap[1]%2]].pointer, 
								tux_trainer[1].pointer,
								&tux_trainer[0].animation, &tux_trainer[0].timer, 
								&tux_trainer[1].animation, &tux_trainer[1].timer,
								shout_text[player], battle_speed);
							
							tux_trainer[1].animation = temp_anim[1];
							tux_trainer[1].timer = temp_timer[1];
							
							if (tux_trainer[0].animation == 0)
							{
								tux_trainer[0].order = -1;
							
								tux_trainer[1].health[swap[1]%2] -= tux_trainer[0].damage;
								if (tux_trainer[1].health[swap[1]%2] <= 0)
								{
									tux_trainer[1].animation = 3;
									tux_trainer[1].timer = 0;
									tux_trainer[1].order = 0;
									tux_trainer[1].damage = 0;
									leave[1] = 1;
									
									shout_text[0] = "DEFEATED";
								}
							}
						}
						else if (tux_trainer[0].animation > 0 && tux_trainer[0].order == 0)
						{
							tux_draw_battle_anim(tux_mon[tux_trainer[0].mon[swap[0]%2]].pointer, 
								tux_mon[tux_trainer[1].mon[swap[1]%2]].pointer, 
								tux_trainer[1].pointer,
								&tux_trainer[0].animation, &tux_trainer[0].timer, 
								0, 0,
								shout_text[player], battle_speed);
							
							if (tux_trainer[0].animation == 0)
							{
								tux_trainer[0].order = -1;
								if (tux_trainer[1].order > 0) tux_trainer[1].order = 0;
							
								tux_trainer[1].health[swap[1]%2] -= tux_trainer[0].damage;
								if (tux_trainer[1].health[swap[1]%2] <= 0)
								{
									tux_trainer[1].animation = 3;
									tux_trainer[1].timer = 0;
									tux_trainer[1].order = 0;
									tux_trainer[1].damage = 0;
									leave[1] = 1;
									
									shout_text[0] = "DEFEATED";
								}
							}
						}
						else if (tux_trainer[1].animation > 0 && tux_trainer[1].order == 0)
						{
							temp_anim[1] = tux_trainer[1].animation;
							temp_timer[1] = tux_trainer[1].timer;
							
							tux_draw_battle_anim(tux_mon[tux_trainer[0].mon[swap[0]%2]].pointer, 
								tux_mon[tux_trainer[1].mon[swap[1]%2]].pointer, 
								tux_trainer[1].pointer,
								0, 0, 
								&tux_trainer[1].animation, &tux_trainer[1].timer,
								shout_text[player], battle_speed);
							
							tux_trainer[1].animation = temp_anim[1];
							tux_trainer[1].timer = temp_timer[1];
						}
						else
						{
							tux_draw_battle_anim(tux_mon[tux_trainer[0].mon[swap[0]%2]].pointer, 
								tux_mon[tux_trainer[1].mon[swap[1]%2]].pointer, 
								tux_trainer[1].pointer,
								0, 0, 
								0, 0,
								shout_text[player], battle_speed);
						}
					}
					else if (player == 1 && battle[1] == 1)
					{
						if (tux_trainer[0].animation > 0 && tux_trainer[0].order == 0 &&
							tux_trainer[1].animation > 0 && tux_trainer[1].order == 0)
						{
							temp_anim[0] = tux_trainer[0].animation;
							temp_timer[0] = tux_trainer[0].timer;
							
							tux_draw_battle_anim(tux_mon[tux_trainer[1].mon[swap[1]%2]].pointer, 
								tux_mon[tux_trainer[0].mon[swap[0]%2]].pointer, 
								tux_trainer[0].pointer,
								&tux_trainer[1].animation, &tux_trainer[1].timer, 
								&tux_trainer[0].animation, &tux_trainer[0].timer,
								shout_text[player], battle_speed);
							
							tux_trainer[0].animation = temp_anim[0];
							tux_trainer[0].timer = temp_timer[0];
							
							if (tux_trainer[1].animation == 0)
							{
								tux_trainer[1].order = -1;
							
								tux_trainer[0].health[swap[0]%2] -= tux_trainer[1].damage;
								if (tux_trainer[0].health[swap[0]%2] <= 0)
								{
									tux_trainer[0].animation = 3;
									tux_trainer[0].timer = 0;
									tux_trainer[0].order = 0;
									tux_trainer[0].damage = 0;
									leave[0] = 1;
									
									shout_text[1] = "DEFEATED";
								}
							}
						}
						else if (tux_trainer[0].animation > 0 && tux_trainer[0].order == 0)
						{
							temp_anim[0] = tux_trainer[0].animation;
							temp_timer[0] = tux_trainer[0].timer;
							
							tux_draw_battle_anim(tux_mon[tux_trainer[1].mon[swap[1]%2]].pointer, 
								tux_mon[tux_trainer[0].mon[swap[0]%2]].pointer, 
								tux_trainer[0].pointer,
								0, 0,
								&tux_trainer[0].animation, &tux_trainer[0].timer,
								shout_text[player], battle_speed);
							
							tux_trainer[0].animation = temp_anim[0];
							tux_trainer[0].timer = temp_timer[0];
						}
						else if (tux_trainer[1].animation > 0 && tux_trainer[1].order == 0)
						{
							tux_draw_battle_anim(tux_mon[tux_trainer[1].mon[swap[1]%2]].pointer, 
								tux_mon[tux_trainer[0].mon[swap[0]%2]].pointer, 
								tux_trainer[0].pointer,
								&tux_trainer[1].animation, &tux_trainer[1].timer, 
								0, 0,
								shout_text[player], battle_speed);
							
							if (tux_trainer[1].animation == 0)
							{
								tux_trainer[1].order = -1;
								if (tux_trainer[0].order > 0) tux_trainer[0].order = 0;
							
								tux_trainer[0].health[swap[0]%2] -= tux_trainer[1].damage;
								if (tux_trainer[0].health[swap[0]%2] <= 0)
								{
									tux_trainer[0].animation = 3;
									tux_trainer[0].timer = 0;
									tux_trainer[0].order = 0;
									tux_trainer[0].damage = 0;
									leave[0] = 1;
									
									shout_text[1] = "DEFEATED";
								}
							}
						}
						else
						{
							tux_draw_battle_anim(tux_mon[tux_trainer[1].mon[swap[1]%2]].pointer, 
								tux_mon[tux_trainer[0].mon[swap[0]%2]].pointer, 
								tux_trainer[0].pointer,
								0, 0,
								0, 0,
								shout_text[player], battle_speed);
						}
					}
					else if (battle[player] > 2)
					{
						if (tux_trainer[player].animation > 0 && tux_trainer[player].order == 0 && 
							tux_trainer[battle[player]-1].animation > 0 && tux_trainer[battle[player]-1].order == 0)
						{
							tux_draw_battle_anim(tux_mon[tux_trainer[player].mon[swap[player]%2]].pointer, 
								tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].pointer, 
								tux_trainer[battle[player]-1].pointer,
								&tux_trainer[player].animation, &tux_trainer[player].timer, 
								&tux_trainer[battle[player]-1].animation, &tux_trainer[battle[player]-1].timer,
								shout_text[player], battle_speed);
							
							if (tux_trainer[player].animation == 0)
							{
								tux_trainer[player].order = -1;
								
								tux_trainer[battle[player]-1].health[swap[player+2]%2] -= tux_trainer[player].damage;
								if (tux_trainer[battle[player]-1].health[swap[player+2]%2] <= 0)
								{
									tux_trainer[battle[player]-1].animation = 3;
									tux_trainer[battle[player]-1].timer = 0;
									tux_trainer[battle[player]-1].order = 0;
									tux_trainer[battle[player]-1].damage = 0;
									leave[player] = 1;
									
									shout_text[player] = "DEFEATED";
								}
							}
								
							if (tux_trainer[battle[player]-1].animation == 0)
							{
								tux_trainer[battle[player]-1].order = -1;
								
								tux_trainer[player].health[swap[player]%2] -= tux_trainer[battle[player]-1].damage;
								if (tux_trainer[player].health[swap[player]%2] <= 0)
								{
									tux_trainer[player].animation = 3;
									tux_trainer[player].timer = 0;
									tux_trainer[player].order = 0;
									tux_trainer[player].damage = 0;
									leave[player] = 1;
								}
							}
						}
						else if (tux_trainer[player].animation > 0 && tux_trainer[player].order == 0)
						{	
							temp_anim[player] = tux_trainer[player].animation;
							
							tux_draw_battle_anim(tux_mon[tux_trainer[player].mon[swap[player]%2]].pointer, 
								tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].pointer, 
								tux_trainer[battle[player]-1].pointer,
								&tux_trainer[player].animation, &tux_trainer[player].timer, 
								0, 0,
								shout_text[player], battle_speed);
							
							if (tux_trainer[player].animation == 0)
							{	
								if (temp_anim[player] == 8) // catch
								{
									if (battle[player] == 3 || battle[player] == 4) // wild mon
									{
										if (tux_random(player) >= tux_trainer[battle[player]-1].level[0] * 5 +
											tux_trainer[battle[player]-1].health[0])
										{
											for (unsigned int i=1; i<6; i++)
											{
												if (tux_trainer[player].level[i] > 0 && i < 5) continue;
												
												tux_trainer[player].mon[i] = tux_trainer[player+2].mon[0];
												tux_trainer[player].level[i] = tux_trainer[player+2].level[0];
												tux_trainer[player].experience[i] = 0;

												tux_trainer[player].damage = 0;
												tux_trainer[battle[player]-1].health[swap[player+2]%2] = 0;

												break;
											}
										}
									}
								}
								
								tux_trainer[player].order = -1;
								if (tux_trainer[battle[player]-1].order > 0) tux_trainer[battle[player]-1].order = 0;
								
								tux_trainer[battle[player]-1].health[swap[player+2]%2] -= tux_trainer[player].damage;
								if (tux_trainer[battle[player]-1].health[swap[player+2]%2] <= 0)
								{
									tux_trainer[battle[player]-1].animation = 3;
									tux_trainer[battle[player]-1].timer = 0;
									tux_trainer[battle[player]-1].order = 0;
									tux_trainer[battle[player]-1].damage = 0;
									leave[player] = 1;
									
									if (temp_anim[player] == 8)
									{
										shout_text[player] = "CAUGHT  ";
									}
									else
									{
										shout_text[player] = "DEFEATED";
									}
								}
							}
						}
						else if (tux_trainer[battle[player]-1].animation > 0 && tux_trainer[battle[player]-1].order == 0)
						{
							tux_draw_battle_anim(tux_mon[tux_trainer[player].mon[swap[player]%2]].pointer, 
								tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].pointer, 
								tux_trainer[battle[player]-1].pointer,
								0, 0, 
								&tux_trainer[battle[player]-1].animation, &tux_trainer[battle[player]-1].timer,
								shout_text[player], battle_speed);
							
							if (tux_trainer[battle[player]-1].animation == 0)
							{
								tux_trainer[battle[player]-1].order = -1;
								if (tux_trainer[player].order > 0) tux_trainer[player].order = 0;
								
								tux_trainer[player].health[swap[player]%2] -= tux_trainer[battle[player]-1].damage;
								if (tux_trainer[player].health[swap[player]%2] <= 0)
								{
									tux_trainer[player].animation = 3;
									tux_trainer[player].timer = 0;
									tux_trainer[player].order = 0;
									tux_trainer[player].damage = 0;
									leave[player] = 1;
								}
							}
						}
						else
						{
							tux_draw_battle_anim(tux_mon[tux_trainer[player].mon[swap[player]%2]].pointer, 
								tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].pointer, 
								tux_trainer[battle[player]-1].pointer,
								0, 0, 
								0, 0,
								shout_text[player], battle_speed);
						}
					}
					
					if (tux_trainer[player].animation == 3 && leave[player] == 1)
					{
						if ((swap[player] == 0 && tux_trainer[player].health[1] > 0) ||
							(swap[player] == 1 && tux_trainer[player].health[0] > 0))
						{
							leave[player] = 0;
						
							swap[player] += 2;
							
							tux_trainer[player].animation = 2;
							tux_trainer[player].damage = 0;
								
							if ((player == 0 && battle[0] == 2) ||
								(player == 1 && battle[1] == 1))
							{
								if (player == 0)
								{
									if (swap[0] == 2) shout_text[1] = tux_mon[tux_trainer[0].mon[1]].name;
									else if (swap[0] == 3) shout_text[1] = tux_mon[tux_trainer[0].mon[0]].name;
								}
								else if (player == 1)
								{
									if (swap[1] == 2) shout_text[0] = tux_mon[tux_trainer[1].mon[1]].name;
									else if (swap[1] == 3) shout_text[0] = tux_mon[tux_trainer[1].mon[0]].name;
								}
							}
						}
					}
					
					if (battle[player] > 2 && tux_trainer[battle[player]-1].animation == 3 && leave[player] == 1)
					{
						if ((swap[player+2] == 0 && tux_trainer[battle[player]-1].health[1] > 0) ||
							(swap[player+2] == 1 && tux_trainer[battle[player]-1].health[0] > 0))
						{
							leave[player] = 0;
						
							swap[player+2] += 2;
							
							tux_trainer[battle[player]-1].animation = 2;
							tux_trainer[battle[player]-1].damage = 0;
								
							if (swap[player+2] == 2) shout_text[player] = tux_mon[tux_trainer[battle[player]-1].mon[1]].name;
							else if (swap[player+2] == 3) shout_text[player] = tux_mon[tux_trainer[battle[player]-1].mon[0]].name;
						}
					}
					
					if (tux_trainer[player].animation == 2 && tux_trainer[player].timer == 200) // switch
					{
						if (swap[player] == 2) swap[player] = 1;
						else if (swap[player] == 3) swap[player] = 0;
						else if (swap[player] == 4) swap[player] = 0;
						else if (swap[player] == 5) swap[player] = 1;
					}
					
					if (battle[player] > 2 && tux_trainer[battle[player]-1].animation == 2 && tux_trainer[battle[player]-1].timer == 200) // switch
					{
						if (swap[player+2] == 2) swap[player+2] = 1;
						else if (swap[player+2] == 3) swap[player+2] = 0;
						else if (swap[player+2] == 4) swap[player+2] = 0;
						else if (swap[player+2] == 5) swap[player+2] = 1;
					}
					
					if ((player == 0 && battle[0] == 2) ||
						(player == 1 && battle[1] == 1))
					{
						if (tux_trainer[0].animation == 0 && tux_trainer[0].order == -1 &&
							tux_trainer[1].animation == 0 && tux_trainer[1].order == -1)
						{
							if (leave[0] > 0 || leave[1] > 0)
							{
								leave[0] = 0;
								leave[1] = 0;
								
								if (tux_trainer[0].health[0] <= 0 && tux_trainer[0].health[1] <= 0)
								{
									if (tux_trainer[1].level[0] > 0)
									{
										tux_trainer[1].experience[0] += (tux_trainer[0].level[0] + tux_trainer[0].level[1]);
									}
									
									if (tux_trainer[1].level[1] > 0)
									{
										tux_trainer[1].experience[1] += (tux_trainer[0].level[0] + tux_trainer[0].level[1]);
									}
								}
								else if (tux_trainer[1].health[0] <= 0 && tux_trainer[1].health[1] <= 0)
								{
									if (tux_trainer[0].level[0] > 0)
									{
										tux_trainer[0].experience[0] += (tux_trainer[1].level[0] + tux_trainer[1].level[1]);
									}
									
									if (tux_trainer[0].level[1] > 0)
									{
										tux_trainer[0].experience[1] += (tux_trainer[1].level[0] + tux_trainer[1].level[1]);
									}
								}
								
								battle[0] = 0;
								battle[1] = 0;
							}
							
							active[0] = 0;
							active[1] = 0;
						}
					}
					else
					{
						if (tux_trainer[player].animation == 0 && tux_trainer[player].order == -1 &&
							tux_trainer[battle[player]-1].animation == 0 && tux_trainer[battle[player]-1].order == -1)
						{
							if (leave[player] > 0)
							{
								leave[player] = 0;
								
								if (tux_trainer[battle[player]-1].health[0] <= 0 && tux_trainer[battle[player]-1].health[1] <= 0)
								{
									if (tux_trainer[player].level[0] > 0)
									{
										tux_trainer[player].experience[0] += 
											(tux_trainer[battle[player]-1].level[0] + tux_trainer[battle[player]-1].level[1]);
									}
									
									if (tux_trainer[player].level[1] > 0)
									{
										tux_trainer[player].experience[1] += 
											(tux_trainer[battle[player]-1].level[0] + tux_trainer[battle[player]-1].level[1]);
									}
								}
								
								battle[player] = 0;
							}
							
							active[player] = 0;
						}
					}
					
					// tux_draw_battle_health() must come before tux_draw_battle_menu()
					// comment out the active[player] == 0 if you want the health to always be displayed
					//if (active[player] == 0)
					//{
						if (player == 0 && battle[0] == 2)
						{
							tux_draw_battle_health(0x1111, 0x5555, 0x9999,
								(signed int)((tux_trainer[0].health[swap[0]%2] * 100) /
									tux_mon[tux_trainer[0].mon[swap[0]%2]].max_health),
								(signed int)((tux_trainer[1].health[swap[1]%2] * 100) /
									tux_mon[tux_trainer[1].mon[swap[1]%2]].max_health));
						}
						else if (player == 1 && battle[1] == 1)
						{
							tux_draw_battle_health(0x1111, 0x5555, 0x9999,
								(signed int)((tux_trainer[1].health[swap[1]%2] * 100) /
									tux_mon[tux_trainer[1].mon[swap[1]%2]].max_health),
								(signed int)((tux_trainer[0].health[swap[0]%2] * 100) /
									tux_mon[tux_trainer[0].mon[swap[0]%2]].max_health));
						}
						else if (battle[player] > 2)
						{
							tux_draw_battle_health(0x1111, 0x5555, 0x9999,
								(signed int)((tux_trainer[player].health[swap[player]%2] * 100) /
									tux_mon[tux_trainer[player].mon[swap[player]%2]].max_health),
								(signed int)((tux_trainer[battle[player]-1].health[swap[player+2]%2] * 100) /
									tux_mon[tux_trainer[battle[player]-1].mon[swap[player+2]%2]].max_health));
						}
					//}
					
					if (active[player] == 0)
					{
						if (battle[player] > 2 && battle[player] <= 4)
						{
							if (tux_trainer[player].level[swap[player]%2] < 10)
							{
								tux_draw_battle_menu(select[player],
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[0]].name,
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[1]].name,
									"        ",
									"        ",
									"CATCH   ");
							}
							else if (tux_trainer[player].level[swap[player]%2] < 20)
							{
								tux_draw_battle_menu(select[player],
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[0]].name,
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[1]].name,
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[2]].name,
									"        ",
									"CATCH   ");
							}
							else
							{
								tux_draw_battle_menu(select[player],
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[0]].name,
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[1]].name,
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[2]].name,
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[3]].name,
									"CATCH   ");
							}
						}
						else if (battle[player] > 0)
						{
							if (tux_trainer[player].level[swap[player]%2] < 10)
							{
								tux_draw_battle_menu(select[player],
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[0]].name,
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[1]].name,
									"        ",
									"        ",
									"SKIP    ");
							}
							else if (tux_trainer[player].level[swap[player]%2] < 20)
							{
								tux_draw_battle_menu(select[player],
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[0]].name,
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[1]].name,
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[2]].name,
									"        ",
									"SKIP    ");
							}
							else
							{
								tux_draw_battle_menu(select[player],
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[0]].name,
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[1]].name,
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[2]].name,
									tux_move[tux_mon[tux_trainer[player].mon[swap[player]%2]].move[3]].name,
									"SKIP    ");
							}
						}
					}
					else if (tux_trainer[player].animation == 1 && tux_trainer[player].timer < 400)
					{
						if (tux_trainer[player].timer < 200) tux_draw_player(tux_trainer[player].pointer, 0, 8);
						else tux_draw_player(tux_trainer[player].pointer, 20 - (signed int)(tux_trainer[player].timer/10), 8);
					}
				}
				
				tux_draw_copy(player+1);
			}
		}
	}
	

	while (1) { }
}


void Buttons()
{
    for (unsigned int i=0; i<240; i++)
	{
		for (unsigned int j=0; j<80; j++)
		{
			screen[i * 80 + j] = 0x0000;
		}
	}
  
    // show button press demo, or comment out
    while (1)
    {	
		if (PORTAbits.RA0 == 0) screen[22 * 80 + 20] = 0xFFFF;
		else screen[22 * 80 + 20] = 0xA5A5;
		
		if (PORTAbits.RA1 == 0) screen[26 * 80 + 20] = 0xFFFF;
		else screen[26 * 80 + 20] = 0xA5A5;
		
		if (PORTBbits.RB0 == 0) screen[24 * 80 + 18] = 0xFFFF;
		else screen[24 * 80 + 18] = 0xA5A5;
		
		if (PORTBbits.RB1 == 0) screen[24 * 80 + 22] = 0xFFFF;
		else screen[24 * 80 + 22] = 0xA5A5;
		
		
		if (PORTAbits.RA4 == 0) screen[22 * 80 + 40] = 0xFFFF;
		else screen[22 * 80 + 40] = 0xA5A5;
		
		if (PORTCbits.RC1 == 0) screen[26 * 80 + 40] = 0xFFFF;
		else screen[26 * 80 + 40] = 0xA5A5;
		
		if (PORTBbits.RB4 == 0) screen[24 * 80 + 38] = 0xFFFF;
		else screen[24 * 80 + 38] = 0xA5A5;
		
		if (PORTCbits.RC0 == 0) screen[24 * 80 + 42] = 0xFFFF;
		else screen[24 * 80 + 42] = 0xA5A5;
    }
	
}

void BadApple()
{ 
    // Bad Apple Code
  
	int test = 0;
	
	for (int i=0; i<5; i++)
	{
		test = sdcard_initialize();
		
		if (test == 1) break;
	}

	
	if (test == 1)
	{
		// move on
	}
	else
	{
		// lock up
		while (1)
		{
			for (unsigned int i=0; i<240; i++)
			{
				for (unsigned int j=0; j<80; j++)
				{
					screen[i * 80 + j] = 0x0000;
				}
			}
			
			for (unsigned int i=0; i<65000; i++) {
			  for (unsigned int j=0; j<5; j++) { } }
		
			for (unsigned int i=0; i<240; i++)
			{
				for (unsigned int j=0; j<80; j++)
				{
					screen[i * 80 + j] = 0xFFFF;
				}
			}
			
			for (unsigned int i=0; i<65000; i++) {
			  for (unsigned int j=0; j<5; j++) { } }
		}
	}  
  
	unsigned int address_high = 0x0000, address_low = 0x0000;

	unsigned int x = 0x0000;
	unsigned int y = 0x0000;
	unsigned int value = 0x0000;
	
	
	while (1) 
	{
		x = 0x0000;
		y = 0x0000;

		for (unsigned int j=0; j<2; j++)
		{
			sdcard_readinit(address_high, (unsigned int)(address_low + (j * 2)));

			for (unsigned int l=0; l<50; l++)
			{	
				for (unsigned int i=0; i<10; i++) // packet of 512 bytes
				{					
					// get value from SDcard
					value = sdcard_receivebyte();

					for (unsigned int k=0; k<8; k++)
					{
						if ((value & 0x0001) == 0x0001)
						{
							screen[y * 80 + x] = 0xFFFF;
							screen[(y+1) * 80 + x] = 0xFFFF;
						}
						else
						{
							screen[y * 80 + x] = 0x0000;
							screen[(y+1) * 80 + x] = 0x0000;
						}

						value = (unsigned int)(value >> 1);

						x++;
					}
				}

				y += 2;
				x = 0;
			}

			for (unsigned int i=0; i<12; i++)
			{
				sdcard_receivebyte(); // audio data (terrible quality)
			}

			sdcard_readfinal();
		}

		address_low += 0x0004;

		if (address_low == 0x0000) address_high++; 
		
		for (unsigned int i=0; i<48000; i++) { } // delay to get better frame rate
	}
	// End of Bad Apple Code
}


// connect to PC using:
// sudo picocom /dev/ttyACM0
void Serial()
{
	string(0x0000, 0x0000, "Use: picocom /dev/ttyACM0\\");
	
    // sets UART to appropriate pins (might need to flip??)
	__builtin_write_OSCCONL(OSCCON & ~(1<<6));
	//RPOR0 = 0x0100;
	RPOR6 = 0x0100; // TX
	//RPINR18 = 0x0022;
	RPINR18 = 0x0038; // RX
	__builtin_write_OSCCONL(OSCCON | (1<<6));
	
	// internal weak pull-downs
	//CNPDB = 0x000C;

	U1BRG = 0x0186; // 390 -> 9600 baud
	
	U1MODEbits.STSEL = 0; // 1-Stop bit
	U1MODEbits.PDSEL = 0; // No Parity, 8-Data bits
	U1MODEbits.ABAUD = 0; // Auto-Baud disabled
	U1MODEbits.BRGH = 0; // Standard-Speed mode
	
	//U1MODEbits.URXINV = 1; // reverse polarity
	//U1STAbits.UTXINV = 1; // reverse polarity
	
	U1STAbits.UTXISEL0 = 0; // Interrupt after one TX character is transmitted
	U1STAbits.UTXISEL1 = 0;
	
	U1STAbits.URXISEL = 0; // interrupt after one RX character is received
	
	U1MODEbits.UARTEN = 1; // enable the UART (just RX?)
	U1STAbits.UTXEN = 1; // and specifically enable the TX
	
	// you can enable interrupts here if you want
	
	char data = 0x00;
	
	unsigned int x = 0x0000;
	unsigned int y = 0x0008;
	
	while (1)
	{
		// check for errors
		if(U1STAbits.FERR == 1)
		{
			continue;
		}
		
		// clear overrun error
		if(U1STAbits.OERR == 1)
		{
			U1STAbits.OERR = 0;
			continue;
		}

		// get data
		if(U1STAbits.URXDA == 1)
		{
			data = U1RXREG; // get character
			
			U1TXREG = data; // echo character received
			
			//hex(76, 0, data);
			
			if (data == 0x0D) // carriage return
			{
				x = 0;
				y += 8;
				
				if (y >= 200)
				{
					y = 192;
					
					for (unsigned int i=0; i<240-8; i++)
					{
						for (unsigned int j=0; j<80; j++)
						{
							// this assembly code allows me to read from the lower screen data!!!
							asm("push DSRPAG");
							asm("push DSWPAG");

							asm("movpag #0x001, DSRPAG");
							asm("movpag #0x001, DSWPAG");
							
							screen[i * 80 + j] = screen[(i + 8) * 80 + j];
							
							asm("pop DSWPAG");
							asm("pop DSRPAG"); 
						}
					}
					
					for (unsigned int i=240-8; i<240; i++)
					{
						for (unsigned int j=0; j<80; j++)
						{
							screen[i * 80 + j] = 0x0000;
						}
					}
				}
				
				while (U1STAbits.UTXBF == 1) { } // wait for clear buffer
				U1TXREG = '\n'; // send carriage return
			}
			else // otherwise
			{
				character(x, y, data);
				
				x += 2;
				
				if (x >= 80) x = 78;
			}
			
		}
	}
	
	
}

const __prog__ unsigned char __attribute__((space(prog))) lcd_splash[1024] =
{
	0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
	0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
	0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x41, 0xD1, 0xF9,
	0xFD, 0x7D, 0x39, 0x19, 0x19, 0x39, 0x31, 0x31, 0x71, 0x61, 0xE1, 0xC1, 0x81, 0x81, 0x01, 0x01,
	0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x81, 0x81, 0xF1, 0xF9, 0xB9, 0x31, 0x11, 0x31,
	0x61, 0xC1, 0xC1, 0x81, 0x01, 0x01, 0x81, 0x81, 0x81, 0x81, 0x81, 0xC1, 0xC1, 0xC1, 0xC1, 0x81,
	0x81, 0x81, 0x81, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
	0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x80, 0xC0, 0xC0, 0xC0, 0x60, 0x60, 0x20, 0x60, 0xF9,
	0xFF, 0xF8, 0xF8, 0xF0, 0xF0, 0xF0, 0xE0, 0x20, 0x60, 0xC0, 0xC0, 0x80, 0x01, 0x21, 0x23, 0x26,
	0x34, 0x30, 0x30, 0x18, 0x08, 0x7C, 0x0E, 0x07, 0x01, 0x00, 0x00, 0x01, 0x03, 0x07, 0x04, 0x00,
	0x00, 0x10, 0x31, 0x23, 0x2F, 0x3F, 0x03, 0x0F, 0x1F, 0x7F, 0xFE, 0xFC, 0xF0, 0xE0, 0x80, 0x01,
	0x01, 0x01, 0x03, 0x03, 0x03, 0x07, 0x0E, 0x1E, 0x1C, 0x78, 0xF0, 0xE0, 0xC0, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0xC0, 0x00, 0x10, 0x18, 0x18, 0x0C, 0x8C,
	0xD6, 0x1E, 0x0E, 0x06, 0x03, 0x00, 0x00, 0x00, 0x08, 0x3E, 0x3F, 0x7F, 0x7F, 0x3F, 0x1E, 0x01,
	0x01, 0xC3, 0x83, 0x83, 0x83, 0x83, 0x01, 0x00, 0x00, 0x00, 0x01, 0x03, 0x06, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x80, 0x80, 0xC0, 0xC0, 0x80,
	0x00, 0x00, 0x00, 0x00, 0xFE, 0xE7, 0x00, 0x00, 0x00, 0x00, 0x00, 0xC3, 0xE7, 0xFF, 0xFF, 0xFE,
	0xFC, 0xF8, 0xF0, 0xF0, 0xE0, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x07, 0x7F, 0xFC, 0xE0,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x80, 0xE0, 0xF8, 0xFC, 0xFF, 0x87, 0x80, 0xC0, 0x60, 0x70, 0x38, 0x1E, 0x67,
	0xFC, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x70, 0x70, 0x00,
	0x18, 0x3F, 0x7F, 0xFF, 0xF1, 0xE0, 0x41, 0x21, 0x33, 0x1B, 0x0F, 0x06, 0x02, 0x00, 0x00, 0x00,
	0x00, 0x60, 0x30, 0x18, 0x0C, 0x06, 0x06, 0x03, 0x03, 0x01, 0x01, 0x01, 0x01, 0xC3, 0xFF, 0x3F,
	0x0E, 0x04, 0x00, 0x00, 0x01, 0x3F, 0xF0, 0x80, 0x00, 0x00, 0x00, 0x0F, 0x1F, 0x3F, 0x3F, 0x77,
	0xFF, 0xF7, 0xFF, 0xFF, 0xFF, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xE0, 0xFF, 0x7F,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x10, 0x1C, 0x1E, 0x0F, 0x0F, 0x07, 0x07, 0x07, 0x03, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x03, 0x0F, 0x3C, 0xF0, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x70, 0xFC, 0xFC, 0xFC, 0xFC,
	0xF8, 0x70, 0x80, 0xE1, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xE0, 0xE0, 0x70, 0x7C, 0x4E, 0x60, 0x60,
	0x40, 0x40, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0x80, 0x90, 0x18, 0x0C, 0x06, 0x03, 0x01, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x33, 0x97, 0xF0, 0x70, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x80, 0x80, 0xE0, 0xF0, 0x38, 0x1E, 0x0F, 0x03, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0xFC, 0xFF, 0x00, 0x00, 0x02, 0x06, 0x3C, 0xFC, 0x0C, 0x0C, 0x0C, 0x35, 0xE7, 0xC6,
	0x06, 0x06, 0x00, 0x07, 0x07, 0x07, 0x07, 0x07, 0x03, 0x1B, 0x75, 0xE4, 0x8C, 0x0C, 0x1C, 0x18,
	0x18, 0x18, 0x3E, 0x1F, 0x00, 0x00, 0x00, 0x01, 0x01, 0x03, 0x03, 0x02, 0x02, 0x76, 0xF8, 0xFE,
	0x73, 0x60, 0x30, 0x38, 0x1C, 0x0E, 0x0F, 0x0B, 0x19, 0x18, 0x10, 0x10, 0x10, 0x10, 0x18, 0x18,
	0x1C, 0x0F, 0x0F, 0x0F, 0x0F, 0x06, 0x07, 0x03, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x01, 0x1F, 0x7C, 0x80, 0xC0, 0xE0, 0xF8, 0xFE, 0xFF, 0xF0, 0x00, 0x00, 0x01, 0x07,
	0x3E, 0xF8, 0xE0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x07, 0x1F, 0x7C, 0xF0,
	0xE0, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x01, 0x07, 0x1F, 0x7F, 0xFF, 0xFF, 0x1F, 0x01, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x07, 0x1F, 0x7C, 0x60, 0x20, 0x30, 0x00, 0x00, 0x18, 0x18, 0x08, 0x0C, 0x0C, 0x06,
	0x07, 0x07, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

const __prog__ unsigned int __attribute__((space(prog))) lcd_splash_dup[2048] =
{

  	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0000, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0x0000, 0x0000, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0x0000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x000F, 0xF000, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0x00F0, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0x00FF, 0xFFFF, 0x0000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0x000F, 0xFFFF, 0xFFF0, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0x0FFF, 0xFFFF, 0xFF00, 0x00FF, 0xFFFF, 0xFFFF, 0x0000, 0x0FFF, 0xF000, 0xFF00, 0x0000, 0x0000, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0FFF, 0xFFFF, 0xFFFF, 0x000F, 0xFFFF, 0xFFF0, 0x0FF0, 0x00FF, 0xFF00, 0x0000, 0x00FF, 0xFFF0, 0x0000, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0FFF, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0xFF00, 0xFFFF, 0x00FF, 0xFFF0, 0x0000, 0x000F, 0xFFFF, 0xFF00, 0x0000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0FFF, 0xF000, 0xFFFF, 0xF00F, 0xFFFF, 0x00F0, 0x0000, 0xFFFF, 0xFFFF, 0xF000, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0x00F0, 0x0000, 0xFFFF, 0xFFFF, 0xFF00, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0000, 0x00FF, 0xFFFF, 0xFFFF, 0x0000, 0xF0FF, 0xFFFF, 0xFFFF, 0xF00F, 0xF0FF, 0x0000, 0x0FFF, 0xFFFF, 0xFFF0, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0000, 0x0000, 0x0000, 0x0FFF, 0xF000, 0x000F, 0xF0FF, 0xFFFF, 0xFFFF, 0xFF00, 0x00FF, 0xF000, 0x00FF, 0xFFFF, 0xFFFF, 0xF000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0000, 0x0F00, 0x0000, 0x000F, 0x000F, 0xFFFF, 0xFFFF, 0xF0FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0x00FF, 0xFFFF, 0xFFFF, 0xF000, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0x000F, 0xFFF0, 0x0000, 0x000F, 0xF000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0x000F, 0xFFFF, 0xFFFF, 0xFF00, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0FFF, 0xFF00, 0x00F0, 0x0000, 0x000F, 0xFF00, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF0FF, 0xFFF0, 0x000F, 0xFFFF, 0xFFFF, 0xFFF0, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0000, 0x0FFF, 0xF000, 0x000F, 0xF000, 0x00FF, 0xFFF0, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFF0, 0x0000, 0xFFFF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0x0000, 0xFFFF, 0xF000, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFFF, 0x0000, 0x0FFF, 0xFFFF, 0xFFFF, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0000, 0xF00F, 0xFFFF, 0x0000, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0FFF, 0xFFFF, 0xF000, 0x00FF, 0xFFFF, 0xFFFF, 0xF00F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x00FF, 0x00FF, 0xFFFF, 0xF000, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0FFF, 0xFFFF, 0xF000, 0x0000, 0xFFFF, 0xFFFF, 0xF00F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFFF, 0x0000, 0x0000, 0x0FFF, 0xFFFF, 0xF000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF0FF, 0xFFFF, 0x0FFF, 0xFFFF, 0xFFF0, 0x0FFF, 0xF0FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF00F, 0xFFFF, 0x00FF, 0xFFF0, 0x0000, 0x0000, 0x00FF, 0xFFFF, 0xF000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFF0, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0x0000, 0xFFFF, 0x00FF, 0xFFF0, 0x0000, 0x0000, 0x00FF, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0FFF, 0xFFF0, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0x0F00, 0x000F, 0xFFFF, 0xFFFF, 0xFFF0, 0x0000, 0x0000, 0xFFFF, 0x00FF, 0xFFF0, 0x0000, 0x0000, 0x00FF, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0FFF, 0xFF00, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0xFFFF, 0x0000, 0x0FFF, 0xFFFF, 0xF000, 0x0FFF, 0xF000, 0x0FFF, 0xF0FF, 0xFFF0, 0x0000, 0x0000, 0x00FF, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0x0FFF, 0xFF00, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0x000F, 0xFFFF, 0xFF00, 0x00FF, 0xF0FF, 0xFFF0, 0x0000, 0x0000, 0x00FF, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0xFFFF, 0xF00F, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0000, 0xFFFF, 0xF00F, 0xFFFF, 0xFFF0, 0x0FFF, 0xFFFF, 0xFF00, 0x0FFF, 0xF0FF, 0xFFF0, 0x000F, 0x0F00, 0x00FF, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0xFFFF, 0x000F, 0x0FFF, 0xFFFF, 0xFFFF, 0xF00F, 0x0000, 0x0FFF, 0x00FF, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0xF00F, 0xFFFF, 0x0000, 0x0000, 0x0FFF, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0000, 0xFFF0, 0x00F0, 0x0FFF, 0xFFFF, 0xFFFF, 0xF00F, 0xF000, 0x00F0, 0x0FFF, 0xFFFF, 0xF00F, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0xF00F, 0xFFFF, 0xF000, 0x0000, 0x0FFF, 0xFFFF, 0xF000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0000, 0xFF00, 0x0FF0, 0x0FFF, 0xFFFF, 0xFFFF, 0xF00F, 0xFF00, 0x000F, 0xFFFF, 0xFFFF, 0xF0FF, 0xFFFF, 0xFFFF, 0xF00F, 0xFFFF, 0xFF0F, 0xFFFF, 0xFFF0, 0x0000, 0x0FFF, 0xFFFF, 0xF000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0000, 0x000F, 0xFFFF, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF00F, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0x0000, 0x0FFF, 0xFFFF, 0xF00F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0000, 0x00FF, 0xFFFF, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0xF000, 0x0FFF, 0xFFFF, 0xF00F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0x0000, 0x0FFF, 0xFFFF, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF0FF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0FFF, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0xF000, 0x0FFF, 0xFFFF, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0x0000, 0xFFFF, 0xFFFF, 0xF00F, 0xFFFF, 0xFFFF, 0x0000, 0xFFFF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0xFFF0, 0xFFFF, 0xFFFF, 0xF000, 0x0FFF, 0xFFFF, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0x0FFF, 0xFFFF, 0xFFFF, 0xF00F, 0xFFFF, 0xFFFF, 0x0000, 0x0FFF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFFF, 0xFFFF, 0xF00F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0x0FFF, 0xFFF0, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0xFFF0, 0x0000, 0x00FF, 0x0000, 0x0FF0, 0x0FFF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFFF, 0xFFFF, 0xFF00, 0x00FF, 0xFFFF, 0xF000, 0x0FFF, 0xFF00, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0xFFF0, 0x0000, 0x00F0, 0x0000, 0x0000, 0x0F00, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF0F, 0x00FF, 0xFFFF, 0xF000, 0x0FFF, 0xF000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0xFFFF, 0xFFF0, 0x0000, 0x00F0, 0x0000, 0x0000, 0x0000, 0x0000, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFFF, 0xF000, 0x0FFF, 0xF00F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0FFF, 0xFFFF, 0x0000, 0x0F00, 0x0000, 0x000F, 0xFFFF, 0xFF00, 0x0000, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0FFF, 0xFFFF, 0xF000, 0x0FF0, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0xFFFF, 0xFFFF, 0xF00F, 0xFFF0, 0x0000, 0x000F, 0xFFFF, 0xFFF0, 0xFFF0, 0x000F, 0xFFFF, 0x0FFF, 0xFF00, 0x0FFF, 0xFFFF, 0xF000, 0x0F00, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0xFF00, 0xFFFF, 0xFF00, 0x00F0, 0x0000, 0x00FF, 0xFFFF, 0xFF00, 0xFFFF, 0xF000, 0x00F0, 0x0FFF, 0xF000, 0xFFFF, 0xFFFF, 0xF000, 0x0000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0xFFF0, 0x0000, 0x0000, 0x00F0, 0x0000, 0xFF00, 0x000F, 0xFF00, 0xFFFF, 0xFFFF, 0xF0F0, 0xFFFF, 0x000F, 0xFFFF, 0xFFFF, 0x0000, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0x0000, 0x0FFF, 0xFFFF, 0xFFFF, 0xF0FF, 0x0000, 0x0000, 0xFFFF, 0xFFFF, 0xFF00, 0xFFF0, 0x0000, 0x00FF, 0xFF00, 0x0000, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0x00FF, 0xF0FF, 0xFFFF, 0xFFFF, 0xF00F, 0xFF00, 0x0000, 0xFFFF, 0xFFFF, 0xF000, 0x0F00, 0x0FFF, 0x0000, 0x0000, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0x00FF, 0xF00F, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0xFF0F, 0xFFFF, 0xFFFF, 0xF000, 0x0000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0xF0FF, 0xFF00, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0xF0FF, 0xFF00, 0xFFFF, 0xFFFF, 0xFFF0, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0xFFFF, 0xFF0F, 0xFF00, 0xFFFF, 0xFFFF, 0xFFF0, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0xFFFF, 0xF00F, 0xFFF0, 0x0FFF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0FFF, 0xF00F, 0xFFF0, 0x0FFF, 0xFFFF, 0xFFFF, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0FFF, 0x000F, 0xFFFF, 0x00FF, 0xFFFF, 0xFFFF, 0xF00F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x0FFF, 0x0000, 0xFFFF, 0x00FF, 0xFFFF, 0xFFFF, 0xF000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0FF0, 0x0000, 0xFFFF, 0x000F, 0xFFFF, 0xFFFF, 0xFF00, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0F00, 0x0000, 0xFFFF, 0xF00F, 0xFFFF, 0xFFFF, 0xFF00, 0x0FFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0x0000, 0xFFFF, 0xF00F, 0xFFFF, 0xFFFF, 0xFFF0, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x0000, 0x0000, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0x000F, 0xFFFF, 0xFF00, 0xFFFF, 0xFFFF, 0xFFF0, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xF000, 0x000F, 0xFFFF, 0xFF00, 0x0FFF, 0xFFFF, 0xF000, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0x000F, 0xFFFF, 0xFFF0, 0x0FFF, 0xFF00, 0x000F, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFF00, 0x000F, 0xFFFF, 0xFFF0, 0x0FF0, 0xFF00, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x00FF, 0xFFFF, 0xFFFF, 0x0000, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFF0, 0x00FF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0x00FF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	
};

void lcd_delay()
{
	for (unsigned int i=0; i<100; i++) { }
}

void lcd_pins()
{
    PORTAbits.RA7 = 0; // A0
	PORTCbits.RC2 = 1; // CS
	PORTCbits.RC8 = 0; // SI
	PORTCbits.RC9 = 0; // CLK
  
    TRISA = 0xFF03;
    TRISC = 0x00FB;
	
	//lcd_delay();
}

void lcd_enable()
{
	PORTCbits.RC2 = 0;
	//lcd_delay();
}

void lcd_disable()
{
    PORTCbits.RC2 = 1;
	//lcd_delay();
}

void lcd_send_byte(unsigned char value)
{
	unsigned int temp = value;
  
	for (unsigned int i=0; i<8; i++)
	{
		temp = (temp & 0x00FF);
		
		if (temp >= 0x0080)
		{
			PORTCbits.RC8 = 1;
		}
		else
		{
			PORTCbits.RC8 = 0;
		}
		
		//lcd_delay();
		
		temp = (unsigned int)(temp << 1);
		
		PORTCbits.RC9 = 1;
		
		//lcd_delay();
		//lcd_delay();
		
		PORTCbits.RC9 = 0;
		
		//lcd_delay();
	}
}

void lcd_send_command(unsigned char value)
{
	PORTAbits.RA7 = 0;
	
	//lcd_delay();
	
	lcd_send_byte(value);
}

void lcd_send_data(unsigned char value)
{
	PORTAbits.RA7 = 1;
	
	//lcd_delay();
	
	lcd_send_byte(value);
}

void LCD()
{
	lcd_pins();
  
	lcd_enable();
	lcd_send_command(0x40);
	lcd_send_command(0xA1);
	lcd_send_command(0xC0);
	lcd_send_command(0xA6);
	lcd_send_command(0xA2);
	lcd_send_command(0x2F);
	lcd_send_command(0xF8);
	lcd_send_command(0x00);
	lcd_send_command(0x27);
	lcd_send_command(0x81);
	lcd_send_command(0x10);
	lcd_send_command(0xAC);
	lcd_send_command(0x00);
	lcd_send_command(0xA4);
	lcd_send_command(0xAF);
	lcd_disable();
	
	
	unsigned int pos = 0x0000;
	
	for (unsigned int page = 0; page < 16; page++)
	{
		lcd_enable();

		lcd_send_command(0x10);
		lcd_send_command(0x00);
		lcd_send_command((unsigned char)(0xB0 + page));

		for (unsigned int i=0; i<128; i++)
		{
			lcd_send_data(lcd_splash[pos]);
			pos++;
		}

		lcd_disable();
	}
	
	// just displaying the duplicate on the monitor
	// need to make a routine to do it automatically
	for (unsigned int i=0; i<64; i++)
	{
		for (unsigned int j=0; j<32; j++)
		{
			screen[(i * 80) + j] = lcd_splash_dup[(i * 32) + j];
		}
	}
	
	while (1) { }
}


int16_t main(void)
{	
	assemblyMain();
	
	// change pins accordingly
	ANSELA = 0x0000;
	LATA = 0x0000;
	TRISA = 0xFFF3;
	ANSELB = 0x0000;
	LATB = 0x000C;
	TRISB = 0x00FF;
	ANSELC = 0x0000;
	LATC = 0xFFFF;
	TRISC = 0xFFFF;
	
	// internal weak pull-up (around 7K to 39K???)
	CNPUB = 0x0080;
	
	// internal weak pull-downs
	CNPDB = 0x000C;
  
	// The code below takes a 10 MHz external oscillator,
	// and uses the PLL to make an internal 120 MHz clock,
	// and thus 60 MIPS!!!
	
	// Make sure the CONFIG bits are set correctly:
	// FNOSC = FRC
	// IESO = OFF
	// FCKSM = CSECMD
	// OSCIOFNC = ON
	// POSCMD = EC
	
	// Configure PLL prescaler, PLL postscaler, PLL divisor
	PLLFBD = 46; // M = 48
	CLKDIVbits.PLLPOST = 0; // N2 = 2
	CLKDIVbits.PLLPRE = 0; // N1 = 2

	
	// Initiate Clock Switch to Primary Oscillator with PLL (NOSC = 0b011)
	__builtin_write_OSCCONH(0x03);
	__builtin_write_OSCCONL(OSCCON | 0x01);
	
	// Wait for Clock Switch to occur
	while (OSCCONbits.COSC != 0b011) { }
	
	// Wait for PLL to lock
	while (OSCCONbits.LOCK != 1) { }
	
	// With an external 10 MHz clock, this PIC24 *should*
	// now be running internally at 120 MHz, thus 60 MIPS!!!
	
	
	// sets Output Compare to appropriate pins
	__builtin_write_OSCCONL(OSCCON & ~(1<<6));
	RPOR3 = 0x1213; // audio channels on OC3 and OC4
	RPOR4 = 0x1011; // v-sync and h-sync to OC1 and OC2
	__builtin_write_OSCCONL(OSCCON | (1<<6));
	
	
	// Timer2 is used with Output Compare for V-SYNC signal
	OC1CON1 = 0; // clear output compare bits
	OC1CON2 = 0; // clear output compare bits
	OC1CON1bits.OCTSEL = 0x00; // uses Timer2
	OC1R = 0x0000; // v-sync rise
	OC1RS = 0x0062; // v-sync fall
	T2CON = 0; // set timer
	T2CONbits.T32 = 0; // both timers are 16-bit
	TMR2 = 0; // zero counter
	T2CONbits.TCKPS = 0x02; // prescale of 1:64 selected
	PR2 = 0x3CB6; // v-reset (minus one!)
	OC1CON2bits.SYNCSEL = 0x0C; // uses Timer2
	OC1CON1bits.OCM = 0x05; // double continuous pulse
	
	
	// Timer3 is used with Output Compare for H-SYNC signal
	OC2CON1 = 0; // clear output compare bits
	OC2CON2 = 0; // clear output compare bits
	OC2CON1bits.OCTSEL = 0x01; // uses Timer3
	OC2R = 0x04EC; // h-sync rise
	OC2RS = 0x05AC; // h-sync fall
	T3CON = 0; // reset timer
	TMR3 = 0x0003; // zero counter
	PR3 = 0x062F; // h-reset (minus one!), 0x062F
	OC2CON2bits.SYNCSEL = 0x0D; // uses Timer3
	OC2CON1bits.OCM = 0x05; // double continuous pulse
	
	
	// Timer4 is used with Output Compare for AUDIO-A signal
	OC3CON1 = 0; // clear output compare bits
	OC3CON2 = 0; // clear output compare bits
	OC3CON1bits.OCTSEL = 0x02; // uses Timer4
	OC3R = 1; // toggle
	T4CON = 0; // set timer
	TMR4 = 0; // zero counter
	T4CONbits.TCKPS = 0x01; // prescale of 1:8 selected
	PR4 = 7000; // reset
	OC3CON2bits.SYNCSEL = 0x0E; // uses Timer4
	OC3CON1bits.OCM = 0x03; // single continuous pulse
	
	
	// Timer5 is used with Output Compare for AUDIO-B signal
	OC4CON1 = 0; // clear output compare bits
	OC4CON2 = 0; // clear output compare bits
	OC4CON1bits.OCTSEL = 0x03; // uses Timer5
	OC4R = 1; // toggle
	T5CON = 0; // set timer
	TMR5 = 0; // zero counter
	T5CONbits.TCKPS = 0x01; // prescale of 1:8 selected
	PR5 = 3000; // reset
	OC4CON2bits.SYNCSEL = 0x0F; // uses Timer5
	OC4CON1bits.OCM = 0x03; // single continuous pulse
	
	
	// Timer1 used for interrupts to race-the-beam
	T1CONbits.TON = 0; // turn timer off
	T1CONbits.TCS = 0; // use internal instructions
	T1CONbits.TGATE = 0; // disable gated mode
	T1CONbits.TCKPS = 0x00; // no prescalar
	TMR1 = 0x0006; // timer counter
	PR1 = 0x062F; // timer period on last line of v-blank (minus one!)
	IPC0bits.T1IP = 0x01; // interrupt priority
	IFS0bits.T1IF = 0; // interrupt flag
	IEC0bits.T1IE = 1; // enable interrupt
	
	
	
	// turn on interrupts globally here!
	SRbits.IPL = 0x00;
	CORCONbits.IPL3 = 0;
	INTCON1 = 0;
	INTCON2 = 0;
	INTCON3 = 0;
	INTCON4 = 0;
	INTTREG = 0x0000;
	INTCON2bits.GIE = 1; 
	
	asm("mov.w #0x003F, w0"); // line to start drawing minus one, normally 0x003F meaning 64-1, but 0x000F for 16-1
	asm("mov.w w0, 0x10B0");
	
	asm("mov.w #0x0180, w0"); // line to stop drawing, normally 0x0180 meaning 384, but 0x01E0 for 480
	asm("mov.w w0, 0x10B2");

	asm("mov.w #0x0000, w0"); // high sound counter
	asm("mov.w w0, 0x10B4");
	
	asm("mov.w #0x0000, w0"); // low sound counter
	asm("mov.w w0, 0x10B6");
	
	asm("mov.w #0x0000, w0"); // high sound duration
	asm("mov.w w0, 0x10B8");
	
	asm("mov.w #0x0000, w0"); // low sound duration
	asm("mov.w w0, 0x10BA");
	
	asm("mov.w #0x5200, w0"); // screen location
	asm("mov.w w0, 0x10BC");
	
	asm("mov.w #0x0259, w0"); // line 601
	asm("mov.w w0, 0x10BE");
	
	asm("mov.w #0x8000, w1"); // bit 15
	

	asm("mov.w 0x0110, w0");
	asm("ior.w w0, w1, w0");
	asm("mov.w w0, 0x0110"); // timer 2 on (v-sync)
	
	asm("mov.w 0x0112, w0");
	asm("ior.w w0, w1, w0");
	asm("mov.w w0, 0x0112"); // timer 3 on (h-sync)
	
	asm("mov.w 0x0104, w0");
	asm("ior.w w0, w1, w0");
	asm("mov.w w0, 0x0104"); // timer 1 on (interrupt)
	
#ifdef TESTING_MACRO
	
	//LCD();
	
	//Serial();
	
	//Tetra();
	
	//BadApple();
	
	//Music();

	//Buttons();
	
	TuxemonDemo(); 
#endif
	
	while (1) { }
}
